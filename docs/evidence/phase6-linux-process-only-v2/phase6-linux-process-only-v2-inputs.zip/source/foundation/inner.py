"""One private, non-performance Phase 6 Linux functional cohort."""
import importlib.util
import json
import os
from pathlib import Path
import select
import signal
import subprocess
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parent))
from x11_target import X11, boundary, require

OUT = Path('/output')


def save(name, value):
    path = OUT / name
    with path.open('w', encoding='utf8') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())


def process_identity(pid):
    fields = Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()
    return {'pid': pid, 'state': fields[0], 'parent': int(fields[1]), 'started': int(fields[19])}


def process_ticket(pid):
    before = process_identity(pid)
    fd = os.pidfd_open(pid)
    try:
        require(process_identity(pid)['started'] == before['started'], 'PID identity changed while opening pidfd')
    except BaseException:
        os.close(fd)
        raise
    return {'identity': before, 'fd': fd}


def exited(ticket):
    return bool(select.select([ticket['fd']], [], [], 0)[0])


def wait(label, observe, timeout=5):
    deadline = time.monotonic() + timeout
    while True:
        value = observe()
        if value:
            return value
        require(time.monotonic() < deadline, label + ' timed out')
        time.sleep(.025)


def load_original_driver():
    spec = importlib.util.spec_from_file_location('original_native_capture', '/fixture-bin/native_capture.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module.Driver


class Target:
    def __init__(self):
        self.log = (OUT / 'target.stderr.log').open('xb')
        self.raw = (OUT / 'target.stdout.jsonl').open('x', encoding='utf8')
        self.process = subprocess.Popen([sys.executable, '-s', '-B', '/fixture-bin/x11_target.py', '--target'],
            stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=self.log, text=True, bufsize=1)
        self.ticket = process_ticket(self.process.pid)
        self.sequence = 0
        self.ready = self.read()
        require(self.ready.get('ready') and self.ready['pid'] == self.process.pid, 'target ready identity mismatch')

    def read(self):
        require(select.select([self.process.stdout], [], [], 3)[0], 'target reply timeout')
        line = self.process.stdout.readline(16385)
        require(line and len(line) <= 16384, 'target EOF/oversize')
        self.raw.write(line)
        self.raw.flush()
        return json.loads(line)

    def request(self, operation):
        self.sequence += 1
        self.process.stdin.write(json.dumps({'id': self.sequence, 'operation': operation}) + '\n')
        self.process.stdin.flush()
        reply = self.read()
        require(reply['id'] == self.sequence, 'target response correlation mismatch')
        return reply

    def close(self):
        self.request('stop')
        code = self.process.wait(timeout=5)
        require(code == 0 and exited(self.ticket), 'target did not exit normally')
        self.log.close()
        self.raw.flush()
        os.fsync(self.raw.fileno())
        self.raw.close()
        return {'exit_code': code, 'pidfd_exited': True, 'forced': False}


def main():
    config = json.loads(Path('/fixture-bin/runtime.json').read_text())
    private = boundary(config)
    sys.path.insert(0, '/fixture-bin/canonical')
    import credential_launcher
    report = {'status': 'running', 'kind': 'phase6_linux_reconstructed_functional',
              'source_revision': config['expected']['source_revision'], 'private_namespaces': private,
              'credential_boundary': credential_launcher.probe_boundary(), 'performance_eligible': False,
              'first_interactive_frame': None, 'ime_dpi_multimonitor': None, 'phases': [], 'cleanup': {}}
    # SS owns its private HOME. Product state uses the original separate fixture profile.
    private_bus = os.environ['DBUS_SESSION_BUS_ADDRESS']
    require(private_bus.startswith('unix:path=/q/dezirclip-private-ss-'), 'private SS bus missing')
    os.environ.update(config['product_environment'])
    os.environ['DBUS_SESSION_BUS_ADDRESS'] = private_bus
    report['product_environment'] = config['product_environment']
    driver = target = x = wm = None
    tickets, logs = [], []
    raw = (OUT / 'native-observations.jsonl').open('x', encoding='utf8')

    def stage(name, **value):
        report['phases'].append({'name': name, 'monotonic_ns': time.monotonic_ns(), **value})
        save('functional.json', report)

    def observation():
        value = x.observe()
        raw.write(json.dumps(value) + '\n')
        raw.flush()
        require(raw.tell() < 16 * 1024 * 1024, 'observation size limit reached')
        return value

    def has_focus(value, window):
        return value['active'] == window and window in value['focus_chain']

    def activate(role='target'):
        result = target.request(role)
        window = result['windows'][role]
        def focused():
            value = observation()
            return value if has_focus(value, window) else None
        wait('synthetic target focus', focused)
        return window

    try:
        stdout = (OUT / 'wm.stdout.log').open('xb')
        stderr = (OUT / 'wm.stderr.log').open('xb')
        logs.extend([stdout, stderr])
        wm = subprocess.Popen(['/usr/bin/marco', '--sm-disable', '--no-composite', '--no-keybindings'], stdout=stdout, stderr=stderr)
        wm_ticket = process_ticket(wm.pid)
        tickets.append(wm_ticket)
        x = X11(config)
        wait('private EWMH window manager', lambda: x.property(x.root, '_NET_SUPPORTING_WM_CHECK'))
        stage('real-ewmh-wm', pid=wm.pid)
        metadata = subprocess.run(['/fixture-bin/dzc-surface', '--build-info'], capture_output=True, timeout=15)
        (OUT / 'surface-build-info.stdout').write_bytes(metadata.stdout)
        (OUT / 'surface-build-info.stderr').write_bytes(metadata.stderr)
        require(metadata.returncode == 0, 'actual helper build-info failed')
        helper_info = json.loads(metadata.stdout)
        for key, expected in config['expected'].items():
            require(helper_info[key] == expected, 'helper identity differs: ' + key)
        require(helper_info['mygo_version'] == 'v0.6.4' and helper_info['mygo_source_revision'] == '6255ea40139d06e0762a7c4a32626148ba410478', 'unverified MyGo dependency')
        stage('actual-native-surface-identity', info=helper_info)
        driver = load_original_driver()(OUT, '/fixture-bin/dezirclip')
        driver.__enter__()
        desktop_info = driver.invoke('get_build_info')
        for key in ('component_version', 'source_revision', 'source_state', 'build_id', 'target'):
            require(desktop_info[key] == config['expected'][key], 'Desktop identity differs: ' + key)
        candidates = []
        for path in Path('/proc').iterdir():
            if path.name.isdigit():
                try:
                    if os.readlink(path / 'exe') == '/fixture-bin/dezirclip':
                        candidates.append(int(path.name))
                except OSError:
                    pass
        require(len(candidates) == 1, 'exactly one actual Desktop expected')
        desktop_pid = candidates[0]
        desktop_ticket = process_ticket(desktop_pid)
        tickets.append(desktop_ticket)
        stage('actual-desktop-identity', info=desktop_info, process=desktop_ticket['identity'])
        data_path = driver.invoke('get_data_path')
        require(data_path == '/output/profile/data/io.github.qiyuanhuakai.dezirclip', 'product profile escaped private data path')
        stage('actual-private-data-path', path=data_path)
        driver.invoke('focus_clipboard_window')
        driver.invoke('set_idle_destroy_enabled', {'enabled': False})
        driver.invoke('set_persistence', {'enabled': True})
        driver.invoke('set_delete_after_paste', {'enabled': False})
        for key, value in [('app.quick_paste_hotkey', 'Ctrl+Alt+Shift+F10'), ('app.quick_paste_enabled', 'true'), ('app.language', 'en')]:
            driver.invoke('save_setting', {'key': key, 'value': value})
        ids = [driver.invoke('add_manual_item', {'content': content, 'contentType': 'text', 'tags': [],
               'expectedPrivacyEpoch': None, 'confirmPersistence': False}) for content in config['dataset']]
        require(len(set(ids)) == 10, 'synthetic rows were not ten distinct Host records')
        host_before = driver.invoke('get_clipboard_host_status')
        require(host_before['mode'] == 'embedded' and host_before['capture_owner'], 'Embedded capture owner required')
        stage('real-host-seed-ten', ids=ids, host=host_before)
        target = Target()
        tickets.append(target.ticket)
        driver.invoke('save_setting', {'key': 'app.quick_paste_renderer', 'value': 'mygo'})
        driver.invoke('hide_window_cmd')

        def show(previous=None, hotkey=False):
            activate()
            if hotkey:
                x.chord(['Control_L', 'Alt_L', 'Shift_L', 'F10'])
            else:
                driver.invoke('show_quick_paste')
            def presented():
                status, native = driver.invoke('get_quick_paste_surface_status'), observation()
                pid = status.get('managed_pid')
                matches = [window for window in native['windows'] if window['pids'] == [pid] and window['viewable']]
                if not status['visible'] or len(matches) != 1 or not has_focus(native, matches[0]['xid']):
                    return None
                window = matches[0]
                require((window['rect']['width'], window['rect']['height']) == (480, 360), 'native panel geometry differs')
                result = {'status': status, 'identity': process_identity(pid), 'xid': window['xid'], 'native': native}
                if previous:
                    require(result['identity']['pid'] == previous['identity']['pid'] and result['identity']['started'] == previous['identity']['started'], 'warm show replaced helper process')
                    require(result['xid'] == previous['xid'] and status['session_id'] == previous['status']['session_id'], 'warm show replaced panel/session')
                return result
            return wait('native panel visible and focused', presented)

        first = show()
        helper_ticket = process_ticket(first['identity']['pid'])
        tickets.append(helper_ticket)
        stage('first-native-show', result=first)

        def hidden(require_target=False):
            status, native = driver.invoke('get_quick_paste_surface_status'), observation()
            if status['visible'] or any(window['pids'] == [first['identity']['pid']] and window['viewable'] for window in native['windows']):
                return None
            if require_target and not has_focus(native, target.ready['windows']['target']):
                return None
            return {'status': status, 'native': native}

        x.chord(['Escape'])
        stage('escape-restores-target', result=wait('Esc and original target focus', lambda: hidden(True)))
        require(target.request('state')['text'] == '', 'cancel pasted into target')
        stage('real-registered-hotkey-native-show-reuses-helper', result=show(first, hotkey=True))
        x.chord(['Escape'])
        stage('real-registered-hotkey-escape-restores-target', result=wait('real hotkey Esc restores target', lambda: hidden(True)))
        stage('warm-show-reuses-helper', result=show(first))
        x.chord(['Control_L', 'a'])
        x.text('dzcp6noresults')
        time.sleep(.06)
        early = x.chord(['Return'])
        time.sleep(.12)
        empty = target.request('state')
        require(empty['text'] == '' and not empty['pending'], 'early Enter pasted an old selection')
        stage('early-enter-no-old-paste', input=early, target=empty, query='dzcp6noresults', limitation='No input-processing/frame timing claim')
        x.chord(['Control_L', 'a'])
        x.text('dzcp6needle7')
        time.sleep(.7)
        paste_input = x.chord(['Return'])
        def exact_paste():
            value = target.request('state')
            return value if value['text'] == config['dataset'][7] and not value['pending'] else None
        pasted = wait('exact full-text native paste', exact_paste)
        require(len(config['dataset'][7]) > 0, 'empty expected paste forbidden')
        stage('actual-host-to-synthetic-target-paste', target=pasted, input=paste_input, result=wait('paste hide/focus', lambda: hidden(True)), conservative_settle_seconds=.7)
        show(first)
        alternate = activate('alternate')
        wait('external blur hide', hidden)
        time.sleep(.25)
        blur = observation()
        require(has_focus(blur, alternate), 'blur stole external focus')
        stage('external-blur-does-not-restore-helper', native=blur)
        target.request('clear')
        show(first)
        before = driver.invoke('get_clipboard_host_status')
        driver.invoke('set_privacy_session', {'enabled': True, 'durationMs': None})
        after = driver.invoke('get_clipboard_host_status')
        require(before['state']['service_instance_id'] == after['state']['service_instance_id'] and after['state']['privacy_epoch'] > before['state']['privacy_epoch'], 'actual privacy epoch did not advance')
        revoked = wait('privacy revokes old display', hidden)
        activate()
        x.chord(['Return'])
        time.sleep(.3)
        require(target.request('state')['text'] == '', 'revoked display pasted stale selection')
        driver.invoke('set_privacy_session', {'enabled': False, 'durationMs': None})
        stage('real-epoch-revokes-old-display', before=before['state'], after=after['state'], result=revoked)
        before_stop = show()
        stop_ticket = process_ticket(before_stop['identity']['pid'])
        tickets.append(stop_ticket)
        require(not exited(stop_ticket), 'renderer switch requires an actually live helper')
        driver.invoke('save_setting', {'key': 'app.quick_paste_renderer', 'value': 'tauri'})
        wait('original helper actual exit', lambda: exited(stop_ticket))
        require(driver.invoke('get_quick_paste_surface_status')['managed_pid'] is None, 'helper metadata remains after stop')
        stage('switch-confirmed-old-helper-exit', original_process=stop_ticket['identity'], before=before_stop, pidfd_exit_observed=True)
        activate()
        x.chord(['Control_L', 'Alt_L', 'Shift_L', 'F10'])
        def tauri_presented():
            visible = driver.invoke('is_quick_paste_visible')
            native = observation()
            matches = [window for window in native['windows'] if window['pids'] == [desktop_pid] and window['viewable'] and
                       window['rect']['width'] == 480 and window['rect']['height'] == 360 and has_focus(native, window['xid'])]
            return native if visible and len(matches) == 1 else None
        stage('actual-tauri-renderer-fallback', result=wait('actual Tauri fallback', tauri_presented))
        driver.invoke('hide_quick_paste')
        driver.invoke('save_setting', {'key': 'app.quick_paste_enabled', 'value': 'false'})
        disabled = driver.invoke('get_quick_paste_surface_status')
        require(not disabled['visible'] and disabled['managed_pid'] is None, 'disabled helper remained active')
        after_owner = driver.invoke('get_clipboard_host_status')
        require(after_owner['mode'] == 'embedded' and after_owner['capture_owner'] and after_owner['state']['service_instance_id'] == host_before['state']['service_instance_id'], 'capture ownership changed during Surface cohort')
        history = driver.invoke('get_clipboard_history', {'limit': 150, 'offset': 0, 'contentType': None})
        require({item['id'] for item in history} == set(ids) and len(history) == 10, 'Surface cohort duplicated or removed a fixture record')
        stage('disabled-no-managed-helper', status=disabled, capture_owner=after_owner, retained_ids=ids)
        report['status'] = 'passed'
    except BaseException as error:
        report.update(status='failed', first_error={'type': type(error).__name__, 'message': str(error)})
    finally:
        errors = []
        if target:
            try:
                report['cleanup']['target'] = target.close()
            except BaseException as error:
                errors.append('target: ' + str(error))
        if driver:
            try:
                original_driver_process = driver.process
                require(original_driver_process is not None, 'original WebKit driver handle missing')
                driver_ticket = process_ticket(original_driver_process.pid)
                tickets.append(driver_ticket)
                driver.close()
                driver_code = original_driver_process.poll()
                report['cleanup']['webdriver'] = {'identity': driver_ticket['identity'], 'exit_code': driver_code,
                    'pidfd_exited': exited(driver_ticket), 'forced': driver_code == -signal.SIGKILL}
                require(driver_code in (0, -signal.SIGTERM) and exited(driver_ticket), 'WebKit driver required forced cleanup or did not exit')
                if 'desktop_ticket' in locals():
                    wait('Desktop pidfd exit', lambda: exited(desktop_ticket), 8)
                    report['cleanup']['desktop_pidfd_exit'] = True
            except BaseException as error:
                errors.append('Desktop: ' + str(error))
        if wm:
            if wm.poll() is None:
                wm.terminate()
            try:
                report['cleanup']['wm_exit_code'] = wm.wait(timeout=5)
                require(wm.returncode == 0 and exited(wm_ticket), 'WM failed orderly exit')
            except BaseException as error:
                errors.append('WM: ' + str(error))
        if x:
            x.close()
        for ticket in tickets:
            os.close(ticket['fd'])
        for stream in logs:
            stream.close()
        raw.flush()
        os.fsync(raw.fileno())
        raw.close()
        report['cleanup']['errors'] = errors
        if errors:
            report['status'] = 'failed'
        save('functional.json', report)
    require(report['status'] == 'passed' and len(report['phases']) == 17, 'private functional cohort failed; original logs retained')


if __name__ == '__main__':
    require(len(sys.argv) == 2 and sys.argv[1] == '--inside', 'private internal entry only')
    main()

"""x86_64 QA-only seccomp boundary; leaves product credential providers unchanged."""
import ctypes,errno,hashlib,json,os,struct,sys
from pathlib import Path
SYSCALLS={'add_key':248,'request_key':249,'keyctl':250}
INSTRUCTIONS=((0x20,0,0,4),(0x15,1,0,0xc000003e),(0x06,0,0,0x80000000),
              (0x20,0,0,0),(0x54,0,0,0xbfffffff),(0x15,3,0,248),
              (0x15,2,0,249),(0x15,1,0,250),(0x06,0,0,0x7fff0000),(0x06,0,0,0x00050001))
def build_filter():return b''.join(struct.pack('<HBBI',*row) for row in INSTRUCTIONS)
def filter_sha256():return hashlib.sha256(build_filter()).hexdigest()
def require(ok,message):
    if not ok:raise RuntimeError(message)
def probe(filter_path,expected_sha256):
    require(sys.platform=='linux' and os.uname().machine=='x86_64' and ctypes.sizeof(ctypes.c_void_p)==8,'native x86_64 Linux required')
    root=Path(os.environ.get('DZC_QA_FIXTURE_ROOT','/not-a-fixture'))
    require(str(root).startswith('/q/dezirclip-private-ss-') and (root/'.dzc-private-ss-qa-v1').read_text()=='synthetic-fixture-only\n','private SS fixture marker required')
    require(os.environ.get('HOME')==str(root/'home') and os.environ.get('DBUS_SESSION_BUS_ADDRESS')=='unix:path='+str(root/'runtime/bus'),'private HOME/DBus required')
    data=Path(filter_path).read_bytes();actual=hashlib.sha256(data).hexdigest()
    require(actual==expected_sha256==filter_sha256(),'canonical seccomp filter bytes differ')
    status=Path('/proc/self/status').read_text()
    require('Seccomp:\t2' in status,'seccomp filter is not active')
    libc=ctypes.CDLL(None,use_errno=True);libc.syscall.restype=ctypes.c_long
    blocked=[]
    # Safe-invalid arguments remain non-mutating even if the filter is missing.
    for name,args in [('add_key',[0,0,0,0,0]),('request_key',[0,0,0,0]),('keyctl',[-1,0,0,0,0])]:
        ctypes.set_errno(0);result=libc.syscall(ctypes.c_long(SYSCALLS[name]),*(ctypes.c_long(v) for v in args));error=ctypes.get_errno()
        require(result==-1 and error==errno.EPERM,name+' must fail with EPERM before argument validation')
        blocked.append({'name':name,'number':SYSCALLS[name],'result':result,'errno':error,'arguments':'safe invalid; no credential read/link/create'})
    require(libc.syscall(ctypes.c_long(39))==os.getpid(),'ordinary getpid syscall failed')
    return {'status':'passed','denied':blocked,'allowed_getpid':os.getpid(),'filter_sha256':actual,'seccomp_status':[s for s in status.splitlines() if s.startswith(('Seccomp:','Seccomp_filters:','NoNewPrivs:'))]}
def pure_validate():
    def evaluate(arch,number):
        registers={0:number,4:arch};value=0;index=0
        while index<len(INSTRUCTIONS):
            op,jt,jf,k=INSTRUCTIONS[index]
            if op==0x20:value=registers[k]
            elif op==0x54:value&=k
            elif op==0x15:index+=jt if value==k else jf
            elif op==0x06:return k
            else:raise RuntimeError('unexpected instruction')
            index+=1
        raise RuntimeError('filter does not terminate')
    cases=[]
    for number in (248,249,250,0x40000000|248,0x40000000|249,0x40000000|250):
        require(evaluate(0xc000003e,number)==0x00050001,'credential syscall not denied');cases.append(number)
    require(evaluate(0xc000003e,39)==0x7fff0000,'getpid denied')
    require(evaluate(0x40000003,248)==0x80000000,'foreign architecture not rejected')
    require(len(build_filter())==80,'unexpected instruction encoding')
    return {'status':'passed','pure_cases':9,'denied_numbers':cases,'filter_sha256':filter_sha256()}
if __name__=='__main__':
    if len(sys.argv)==1:print(json.dumps(pure_validate()))
    elif len(sys.argv)==3 and sys.argv[1]=='--write':
        with Path(sys.argv[2]).open('xb') as target:target.write(build_filter())
        print(json.dumps({'path':sys.argv[2],'sha256':filter_sha256()}))
    elif len(sys.argv)==4 and sys.argv[1]=='--probe':print(json.dumps(probe(sys.argv[2],sys.argv[3])))
    else:raise RuntimeError('use no arguments for pure checks, --write NEW_PATH, or --probe FILTER_PATH EXPECTED_SHA')

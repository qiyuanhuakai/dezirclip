"""Install the immutable x86_64 QA credential filter in this child, then exec a controller."""
import ctypes,errno,hashlib,json,os,sys
from pathlib import Path
import credential_guard
CANONICAL_MODULE_SHA='0d5cd12943814fcd52238db3953499869334a6360aad17c60bcb5596bd2cea2f'
FILTER_SHA='426b69b2f07c9bb6a71c0327d9b4f76eabc5752f2276fa11a9937d264ae739cd'
def require(ok,message):
    if not ok:raise RuntimeError(message)
def digest(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def require_native():require(sys.platform=='linux' and os.uname().machine=='x86_64' and ctypes.sizeof(ctypes.c_void_p)==8,'native x86_64 Linux only')
def probe_boundary():
    require_native();status=Path('/proc/self/status').read_text()
    require('NoNewPrivs:\t1' in status and 'Seccomp:\t2' in status,'inherited boundary missing')
    libc=ctypes.CDLL(None,use_errno=True);libc.syscall.restype=ctypes.c_long
    results=[]
    # Invalid arguments cannot read, link or create credentials even without a filter.
    for name,number,args in [('add_key',248,[0,0,0,0,0]),('request_key',249,[0,0,0,0]),('keyctl',250,[-1,0,0,0,0])]:
        ctypes.set_errno(0);result=libc.syscall(ctypes.c_long(number),*(ctypes.c_long(v) for v in args));error=ctypes.get_errno()
        require(result==-1 and error==errno.EPERM,name+' not denied with EPERM')
        results.append({'name':name,'number':number,'result':result,'errno':error,'arguments':'safe invalid, non-mutating'})
    require(libc.syscall(ctypes.c_long(39))==os.getpid(),'getpid failed')
    return {'status':'passed','architecture':'native x86_64','actual_calls':results,'allowed_getpid':os.getpid(),'proc_status':[v for v in status.splitlines() if v.startswith(('NoNewPrivs:','Seccomp:','Seccomp_filters:'))],'actual_x32_or_foreign_abi_execution':False}
def install_boundary():
    require_native();module=Path(credential_guard.__file__).resolve()
    require(digest(module)==CANONICAL_MODULE_SHA,'canonical module changed')
    data=credential_guard.build_filter();require(hashlib.sha256(data).hexdigest()==FILTER_SHA,'canonical filter changed')
    class SockFilter(ctypes.Structure):_fields_=[('code',ctypes.c_ushort),('jt',ctypes.c_ubyte),('jf',ctypes.c_ubyte),('k',ctypes.c_uint32)]
    class SockProgram(ctypes.Structure):_fields_=[('length',ctypes.c_ushort),('filter',ctypes.POINTER(SockFilter))]
    require(ctypes.sizeof(SockFilter)==8,'unexpected BPF layout')
    array=(SockFilter*(len(data)//8)).from_buffer_copy(data);program=SockProgram(len(array),array)
    libc=ctypes.CDLL(None,use_errno=True);libc.prctl.restype=ctypes.c_int;libc.prctl.argtypes=[ctypes.c_int,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_ulong,ctypes.c_ulong]
    require(libc.prctl(38,1,0,0,0)==0,'PR_SET_NO_NEW_PRIVS failed')
    require(libc.prctl(22,2,ctypes.addressof(program),0,0)==0,'PR_SET_SECCOMP failed errno='+str(ctypes.get_errno()))
    return probe_boundary()
def main():
    require(len(sys.argv)>=5 and sys.argv[1]=='--proof' and sys.argv[3]=='--','use --proof NEW_JSON -- COMMAND [ARGS]')
    path=Path(sys.argv[2]);command=sys.argv[4:]
    require(path.parent.is_dir() and not path.exists(),'new proof under an existing owned directory required')
    require(Path(command[0]).is_absolute() and Path(command[0]).is_file(),'explicit absolute executable required')
    report={'status':'prepared','scope':'QA x86_64 process credential-syscall boundary only; no product runtime result','canonical_module_sha256':CANONICAL_MODULE_SHA,'bpf_sha256':FILTER_SHA,'launcher_sha256':digest(__file__),'command':command,'pid':os.getpid()}
    with path.open('x') as output:
        try:report['native_probe']=install_boundary();report['status']='boundary_installed_and_native_probe_passed'
        except BaseException as error:report.update(status='failed',error=repr(error));raise
        finally:output.write(json.dumps(report,indent=2)+'\n');output.flush();os.fsync(output.fileno())
    os.execvpe(command[0],command,os.environ.copy())
if __name__=='__main__':main()

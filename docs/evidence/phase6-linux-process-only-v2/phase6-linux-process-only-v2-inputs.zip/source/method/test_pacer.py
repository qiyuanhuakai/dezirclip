import copy
import importlib.util
from pathlib import Path
import unittest

SPEC = importlib.util.spec_from_file_location('pacer', Path(__file__).with_name('pacer.py'))
PACER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(PACER)
STEP = 250_000_000


class Clock:
    def __init__(self):
        self.value = 2 ** 54 + 123
        self.early = False

    def now(self):
        return self.value

    def sleep(self, seconds):
        duration = max(1, round(seconds * 1_000_000_000))
        self.value += max(1, duration // 2) if self.early else duration


class PacingTests(unittest.TestCase):
    def execute(self, count=4, capture_cost=0, encode_cost=0, write_cost=0, log_cost=0,
                early=False, invalid_capture=False, deadline_cost=10_000_000_000, fail_stage=None):
        clock, progress, samples, logs = Clock(), {}, [], []
        clock.early = early

        def advance(cost, stage):
            clock.value += cost
            if fail_stage == stage:
                raise OSError('synthetic ' + stage + ' failure')

        def capture(index, start):
            advance(capture_cost, 'capture')
            return None if invalid_capture else {'index': index, 'source_start_ns': start}

        def encode(sample):
            advance(encode_cost, 'encode')
            return copy.deepcopy(sample)

        def write(sample):
            advance(write_cost, 'write')
            samples.append(sample)

        def log(tick):
            advance(log_cost, 'log')
            logs.append(copy.deepcopy(tick))

        error = None
        try:
            PACER.counted_snapshots(progress, count, STEP, clock.value + deadline_cost,
                                    clock.now, clock.sleep, capture, encode, write, log)
        except BaseException as caught:
            error = caught
        return progress, samples, logs, error

    def test_full_count_and_tail_use_real_integer_times_above_float_precision(self):
        progress, samples, logs, error = self.execute(count=960, deadline_cost=300_000_000_000)
        self.assertIsNone(error)
        self.assertEqual((progress['capture_calls'], len(samples), len(logs)), (960, 960, 960))
        self.assertEqual(progress['tail_reached_ns'] - progress['started_ns'], 240_000_000_000)
        self.assertEqual(samples[-1]['source_start_ns'] - samples[0]['source_start_ns'], 239_750_000_000)
        self.assertEqual(progress['status'], 'passed')

    def test_249_250_251_and_700ms_capture_do_not_catch_up_or_discard(self):
        for cost in (249_000_000, 250_000_000, 251_000_000, 700_000_000):
            with self.subTest(cost=cost):
                progress, samples, _, error = self.execute(capture_cost=cost)
                self.assertIsNone(error)
                self.assertEqual((progress['capture_calls'], len(samples)), (4, 4))
                clocks = progress['clocks']
                for left, right in zip(clocks, clocks[1:]):
                    self.assertEqual(right['due_ns'], left['actual_start_ns'] + STEP)
                    self.assertEqual(right['actual_start_ns'] - left['actual_start_ns'], max(STEP, cost))

    def test_serialization_sample_write_and_clock_log_delay_the_next_real_start(self):
        for stage in ('encode_cost', 'write_cost', 'log_cost'):
            with self.subTest(stage=stage):
                progress, samples, _, error = self.execute(**{stage: 700_000_000})
                self.assertIsNone(error)
                self.assertEqual(progress['clocks'][1]['late_ns'], 450_000_000)
                self.assertEqual(samples[1]['source_start_ns'] - samples[0]['source_start_ns'], 700_000_000)

    def test_early_sleep_returns_cannot_cause_early_observations(self):
        progress, samples, _, error = self.execute(early=True)
        self.assertIsNone(error)
        self.assertTrue(all(tick['actual_start_ns'] >= tick['due_ns'] for tick in progress['clocks']))
        self.assertTrue(all(right['source_start_ns'] - left['source_start_ns'] >= STEP for left, right in zip(samples, samples[1:])))

    def test_tail_is_based_on_actual_last_start_after_lateness(self):
        progress, _, _, error = self.execute(capture_cost=300_000_000)
        self.assertIsNone(error)
        last = progress['clocks'][-1]
        self.assertEqual(progress['tail_due_ns'], last['actual_start_ns'] + STEP)
        self.assertGreaterEqual(progress['tail_reached_ns'], progress['tail_due_ns'])

    def test_bad_or_failed_capture_is_not_replaced_with_another_observation(self):
        for options in ({'invalid_capture': True}, {'fail_stage': 'capture'}):
            with self.subTest(options=options):
                progress, samples, _, error = self.execute(**options)
                self.assertIsNotNone(error)
                self.assertEqual((progress['capture_calls'], len(samples)), (1, 0))
                self.assertEqual(progress['status'], 'failed')

    def test_storage_and_encoding_failures_retain_partial_state_without_retry(self):
        for stage in ('encode', 'write', 'log'):
            with self.subTest(stage=stage):
                progress, _, _, error = self.execute(fail_stage=stage)
                self.assertIsInstance(error, OSError)
                self.assertEqual(progress['capture_calls'], 1)
                self.assertEqual(progress['status'], 'failed')

    def test_deadline_during_capture_or_storage_stops_before_another_capture(self):
        for options in ({'capture_cost': 700_000_000}, {'write_cost': 700_000_000}, {'log_cost': 700_000_000}):
            with self.subTest(options=options):
                progress, _, _, error = self.execute(deadline_cost=600_000_000, **options)
                self.assertIsInstance(error, RuntimeError)
                self.assertEqual(progress['capture_calls'], 1)
                self.assertEqual(progress['status'], 'failed')

    def test_clock_backwards_or_wrong_domain_type_stops_without_capture(self):
        for readings in ([1000, 999], [1000, 1.25], [1000, True]):
            stream, progress, calls = iter(readings), {}, []
            with self.subTest(readings=readings), self.assertRaises(RuntimeError):
                PACER.counted_snapshots(progress, 2, STEP, 10_000, lambda: next(stream),
                                        lambda value: None, lambda *args: calls.append(args), str, lambda value: None, lambda value: None)
            self.assertEqual(calls, [])

    def test_stalled_sleep_clock_stops_without_busy_loop(self):
        progress, calls = {}, []
        with self.assertRaisesRegex(RuntimeError, 'did not advance'):
            PACER.counted_snapshots(progress, 2, STEP, 10_000_000_000, lambda: 1000,
                                    lambda value: None, lambda *args: calls.append(args) or {}, str, lambda value: None, lambda value: None)
        self.assertEqual(len(calls), 1)

    def test_deadline_from_another_time_domain_never_starts_a_capture(self):
        calls, progress = [], {}
        with self.assertRaisesRegex(RuntimeError, 'clock domain'):
            PACER.counted_snapshots(progress, 2, STEP, 1_700_000_000_000_000_000, lambda: 123_456_789,
                                    lambda value: None, lambda *args: calls.append(args), str, lambda value: None, lambda value: None)
        self.assertEqual(calls, [])

    def test_final_tail_deadline_retains_the_one_observation_and_stops(self):
        progress, samples, logs, error = self.execute(count=1, deadline_cost=100_000_000)
        self.assertIsInstance(error, RuntimeError)
        self.assertEqual((progress['capture_calls'], len(samples), len(logs)), (1, 1, 1))
        self.assertEqual(progress['status'], 'failed')

    def test_counter_rate_uses_integer_difference_and_reports_only_read_window_uncertainty(self):
        base = 2 ** 54 + 123
        result = PACER.counter_rate_interval([base, base + 10], [base + 100, base + 110], 1, 100)
        self.assertEqual((result['interval_min_ns'], result['interval_max_ns'], result['twice_nominal_interval_ns']), (90, 110, 200))
        self.assertLess(result['read_window_normalization_percent_range'][0], result['nominal_percent_one_core'])
        self.assertGreater(result['read_window_normalization_percent_range'][1], result['nominal_percent_one_core'])
        for first, last, delta in (([100, 110], [110, 120], 1), ([100, 90], [200, 210], 1), ([100, 110], [200, 210], -1)):
            self.assertIsNone(PACER.counter_rate_interval(first, last, delta, 100))
        self.assertIsNone(PACER.counter_rate_interval(None, [200, 210], 1, 100))
        self.assertIsNone(PACER.counter_rate_interval([100, 110], [1_700_000_000_000_000_000, 1_700_000_000_000_000_010], 1, 100))


if __name__ == '__main__':
    unittest.main()

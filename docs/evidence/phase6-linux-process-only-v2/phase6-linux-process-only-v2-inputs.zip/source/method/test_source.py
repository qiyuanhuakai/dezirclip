import ast
import copy
import hashlib
import json
from pathlib import Path
import unittest

HERE = Path(__file__).resolve().parent
PARENT = HERE.parent / 'phase6-linux-performance-observer-v6-5d6-20261030'


def functions(path):
    return {node.name: node for node in ast.parse(path.read_text()).body if isinstance(node, ast.FunctionDef)}


class FrozenSourceTests(unittest.TestCase):
    def test_integrated_clock_functions_are_exactly_the_tested_pure_module(self):
        reference, integrated = functions(HERE / 'pacer.py'), functions(HERE / 'inner.py')
        for name in reference:
            self.assertEqual(ast.dump(reference[name]), ast.dump(integrated[name]))

    def test_all_original_global_native_and_transport_functions_are_unchanged(self):
        old, current = functions(PARENT / 'inner.py'), functions(HERE / 'inner.py')
        self.assertEqual(set(current) - set(old), {'counted_snapshots', 'counter_rate_interval'})
        for name in set(old) - {'main'}:
            self.assertEqual(ast.dump(old[name]), ast.dump(current[name]))

    def test_main_changes_only_clock_origin_and_nested_resource_collector(self):
        old, current = functions(PARENT / 'inner.py')['main'], functions(HERE / 'inner.py')['main']
        def strip(node):
            result = copy.deepcopy(node)
            result.body = [item for item in result.body if not (
                isinstance(item, ast.Assign) and any(isinstance(target, ast.Name) and target.id in {
                    'arm_clock_started_ns', 'arm_clock_deadline_ns'} for target in item.targets))]
            for item in ast.walk(result):
                if isinstance(item, ast.FunctionDef) and item.name == 'resources':
                    item.body = [ast.Pass()]
            return ast.dump(result)
        self.assertEqual(strip(old), strip(current))

    def test_outer_diff_is_only_predeclared_sampling_policy(self):
        source = (PARENT / 'outer.py').read_text()
        original = "{'order': ['tauri', 'mygo', 'mygo', 'tauri'], 'warmup': 5, 'samples': 30,\n        'latency_poll_seconds': .01, 'resource_settle_seconds': 30, 'resource_sample_seconds': 240,\n        'resource_interval_seconds': .25}"
        plan = json.loads((HERE / 'comparison-count-v1.plan.json').read_text())
        self.assertEqual(source.count(original), 1)
        self.assertEqual((HERE / 'outer.py').read_text(), source.replace(original, repr(plan['comparison'])))
        self.assertIn('time.monotonic() + 1260', source)
        self.assertIn("NS = ('user', 'mnt', 'pid', 'ipc', 'uts', 'net')", source)

    def test_target_credential_prerequisite_and_all_pending_inputs_remain_frozen(self):
        plan = json.loads((HERE / 'comparison-count-v1.plan.json').read_text())
        self.assertIs(plan['root_go'], False)
        self.assertIs(plan['performance_eligible'], False)
        for name in ('x11_target.py', 'paste_prerequisite.py'):
            self.assertEqual((HERE / name).read_bytes(), (PARENT / name).read_bytes())
        for name, expected in plan['fixture_sources'].items():
            self.assertEqual(hashlib.sha256((HERE / name).read_bytes()).hexdigest(), expected)
        self.assertEqual([arm['renderer'] for arm in plan['arms']], ['tauri', 'mygo', 'mygo', 'tauri'])
        for arm in plan['arms']:
            pending = json.loads((HERE / (arm['run_name'] + '.pending.json')).read_text())
            self.assertIs(pending['root_go'], False)
            self.assertIs(pending['performance_eligible'], False)
            self.assertEqual(pending['comparison'], plan['comparison'])
            self.assertEqual(pending['inputs'], plan['inputs'])
            self.assertEqual(pending['fixture_sources'], plan['fixture_sources'])


if __name__ == '__main__':
    unittest.main()

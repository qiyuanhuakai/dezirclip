"""Standard-library synthetic-only tests; never call the actual reader CLI or fixture."""
import ast
import copy
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest import mock

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('independent_process_only_reader', HERE / 'review_arm.py')
reader = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reader)


def resource_fixture(panel_pid=69):
    main = {'pid': 68, 'started': 100, 'xid': 8388623}
    panel = {'pid': panel_pid, 'started': 100 if panel_pid == 68 else 101, 'xid': 20971523, 'session_id': None if panel_pid == 68 else 'a' * 32}
    start = 1000000000000
    samples, clocks, saved = [], [], []
    for index in range(1, 961):
        now = start + (index - 1) * 250000000
        clock = {'index': index, 'due_ns': now, 'actual_start_ns': now, 'late_ns': 0,
                 'capture_end_ns': now + 100, 'serialization_end_ns': now + 200,
                 'sample_write_end_ns': now + 300, 'clock_log_end_ns': now + 400}
        members = []
        for pid, parent, started, ticks, pss, clean, dirty in [(68, 1, 100, 10 + index, 100, 30, 40), (69, 68, 101, 5 + index, 50, 10, 20)]:
            members.append({'pid': pid, 'parent': parent, 'started': started, 'cpu_ticks': ticks,
                            'memory_kib': {'Pss': pss, 'Rss': pss * 2, 'Private_Clean': clean, 'Private_Dirty': dirty},
                            'observer_method': reader.METHOD, 'thread_context_switch_collection': reader.COLLECTION, 'threads': None})
        samples.append({'snapshot_index': index, 'monotonic_ns': now, 'observer_cost_ns': 90,
                        'cpu_counter_read_window_ns': [now + 10, now + 20],
                        'sampling_clock': {k: clock[k] for k in ('index', 'due_ns', 'actual_start_ns', 'late_ns', 'capture_end_ns')},
                        'members': members, 'pss_kib': 150, 'uss_kib': 100,
                        'cpu_ticks': sum(m['cpu_ticks'] for m in members), 'context_switches': None,
                        'observer_method': reader.METHOD, 'thread_context_switch_collection': reader.COLLECTION,
                        'original_identities_before': {'main': main.copy(), 'panel': panel.copy()},
                        'original_identities_after': {'main': main.copy(), 'panel': panel.copy()}})
        saved.append(clock)
        clocks.append({k: v for k, v in clock.items() if k != 'clock_log_end_ns'})
    progress = {'kind': 'event-anchored-count-v1', 'status': 'passed', 'requested_count': 960,
                'capture_calls': 960, 'samples_written': 960, 'interval_ns': 250000000,
                'started_ns': start, 'deadline_ns': start + 1260000000000,
                'tail_due_ns': start + 960 * 250000000, 'tail_reached_ns': start + 960 * 250000000,
                'files_flushed_ns': start + 960 * 250000000 + 100, 'clocks': saved}
    metric = {'sample_count': 960, 'sampling_protocol': 'event-anchored-count-v1',
              'observer_method': reader.METHOD, 'thread_context_switch_collection': reader.COLLECTION,
              'stable_thread_membership': None, 'observed_thread_context_switch_delta': None, 'wakeup_count': None,
              'actual_elapsed_seconds': (progress['files_flushed_ns'] - start) / 1e9,
              'sample_span_seconds': (samples[-1]['monotonic_ns'] - samples[0]['monotonic_ns']) / 1e9,
              'pss_kib': reader.summary([150] * 960), 'uss_kib': reader.summary([100] * 960),
              'observer_cost_ms': reader.summary([.00009] * 960), 'late_ms': reader.summary([0.0] * 960),
              'serialization_cost_ms': reader.summary([.0001] * 960),
              'sample_write_cost_ms': reader.summary([.0001] * 960), 'clock_log_cost_ms': reader.summary([.0001] * 960),
              'observation_intervals_ms': reader.summary([250.0] * 959), 'stable_process_membership': True,
              'cpu_clock_ticks_per_second': 100}
    first, last = samples[0]['cpu_counter_read_window_ns'], samples[-1]['cpu_counter_read_window_ns']
    delta = samples[-1]['cpu_ticks'] - samples[0]['cpu_ticks']
    low, high, twice = last[0] - first[1], last[1] - first[0], sum(last) - sum(first)
    metric['cpu_counter_normalization'] = {'counter_delta_ticks': delta, 'interval_min_ns': low,
        'interval_max_ns': high, 'twice_nominal_interval_ns': twice,
        'nominal_percent_one_core': delta * 200000000000.0 / (100 * twice),
        'read_window_normalization_percent_range': [delta * 100000000000.0 / (100 * high), delta * 100000000000.0 / (100 * low)]}
    metric['cpu_percent_one_core'] = metric['cpu_counter_normalization']['nominal_percent_one_core']
    return samples, clocks, progress, metric, main, panel


def native_fixture(renderer='mygo'):
    samples, clocks, progress, metric, main, panel = resource_fixture(68 if renderer == 'tauri' else 69)
    native, qualifications, replies, shows = [], [], [], []
    target = 18874369
    tags = ['first-hotkey', *[f'warmup-{i}' for i in range(1, 6)], *[f'samples-{i}' for i in range(1, 31)], 'exact-paste-verification', 'resource-visible']

    def observation(ns, tag, visible=True):
        active = panel['xid'] if visible else target
        return {'tag': tag, 'monotonic_ns': ns, 'active': active, 'focus_chain': [active], 'x_errors': 0,
                'windows': [{'xid': main['xid'], 'pids': [main['pid']], 'viewable': False, 'rect': {'width': 800, 'height': 600}},
                            {'xid': panel['xid'], 'pids': [panel['pid']], 'viewable': visible, 'rect': {'width': 480, 'height': 360}}]}
    for index, tag in enumerate(tags):
        now = 1000000000 + index * 10000000
        raw = observation(now + 100, tag)
        native.append(raw)
        show = {**panel, 'native_observed_ns': now + 120, 'activation_proxy_ms': .00012,
                'input': {'input_start_ns': now, 'input_synced_ns': now + 50, 'keys': ['Control_L', 'Alt_L', 'Shift_L', 'F10']},
                'native': {k: v for k, v in raw.items() if k != 'tag'}}
        shows.append(show)
        endpoint = {k: show[k] for k in ('pid', 'started', 'xid', 'native_observed_ns')}
        before, after = observation(now + 200, 'qualification-' + tag + '-before'), observation(now + 900, 'qualification-' + tag + '-after')
        native.extend([before, after])
        final = {'renderer': renderer, 'managed_pid': panel['pid'] if renderer == 'mygo' else None,
                 'session_id': panel['session_id'], 'visible': True, 'last_error': None}
        deadline = (now + 120) / 1e9 + 5
        observation_row = {'before_native_ns': now + 200, 'after_native_ns': now + 900,
                           'before_identities': {'main': main.copy(), 'panel': panel.copy()},
                           'after_identities': {'main': main.copy(), 'panel': panel.copy()},
                           'status': final.copy(), 'tauri_visible': True}
        commands = ['get_quick_paste_surface_status', 'is_quick_paste_visible'] if renderer == 'tauri' else ['get_quick_paste_surface_status']
        for offset, command in enumerate(commands):
            value = True if command == 'is_quick_paste_visible' else final.copy()
            request = now + 300 + offset * 100
            replies.append({'tag': tag, 'original_endpoint': endpoint.copy(), 'http_status': 200,
                'request_started_ns': request, 'response_finished_ns': request + 50,
                'remaining_budget_ms': (deadline - request / 1e9) * 1000, 'wire_bytes': 200,
                'actual_response': {'value': {'ok': True, 'value': value}}, 'reply': value, 'command': command})
        qualifications.append({'tag': tag, 'qualified': True, 'native_proxy_endpoint_unchanged': True,
            'original_endpoint': endpoint, 'native_proxy_endpoint_ns': now + 120,
            'qualification_completed_ns': now + 1000, 'original_deadline_monotonic': deadline,
            'reply_records': len(commands), 'status_reads': 1, 'observations': [observation_row], 'final_status': final})
    resources = {'visible': copy.deepcopy(samples), 'hidden': copy.deepcopy(samples)}
    for state in resources:
        shift = 0 if state == 'visible' else 500000000000
        for row in resources[state]:
            ns = row['monotonic_ns'] + shift
            row['monotonic_ns'] = ns
            row['cpu_counter_read_window_ns'] = [ns + 10, ns + 20]
            native.append(observation(ns + 1, 'resource-' + state, state == 'visible'))
    dataset = [f'phase6 record {i:02} dzcp6needle{i} synthetic payload' for i in range(10)]
    report = {'original_main': main, 'first_hotkey': shows[0], 'warmup': shows[1:6], 'samples': shows[6:36],
              'warm_activation_proxy_ms': reader.summary([v['activation_proxy_ms'] for v in shows[6:36]]),
              'retained_ids': list(range(1, 11)), 'capture_owner': {'mode': 'embedded', 'capture_owner': True},
              'actual_paste': {'text': dataset[7], 'pending': False, 'windows': {'target': target}},
              'first_hotkey_context': {'application_already_started': True, 'not_application_cold_start': True},
              'show_qualifications': qualifications}
    return report, native, replies, {'renderer': renderer, 'dataset': dataset}, resources


class ResourceContracts(unittest.TestCase):
    def setUp(self):
        self.values = resource_fixture()

    def check(self):
        reader.check_resource(*self.values)

    def test_complete_960_math_clocks_and_null_thread_schema(self):
        self.check()

    def test_each_missing_row_clock_or_attempt_is_fatal(self):
        for side in (0, 1):
            v = resource_fixture()
            v[side].pop()
            with self.assertRaises(ValueError): reader.check_resource(*v)
        for key in ('capture_calls', 'samples_written', 'requested_count'):
            v = resource_fixture(); v[2][key] -= 1
            with self.assertRaises(ValueError): reader.check_resource(*v)

    def test_first_middle_last_clock_corruption_and_tail_are_fatal(self):
        for index in (0, 479, 959):
            v = resource_fixture(); v[2]['clocks'][index]['late_ns'] += 1
            with self.assertRaises(ValueError): reader.check_resource(*v)
        v = resource_fixture(); v[2]['tail_due_ns'] -= 1
        with self.assertRaises(ValueError): reader.check_resource(*v)

    def test_clock_overlap_bounds_and_full_deadline_are_fatal(self):
        for change in ('cpu', 'overlap', 'deadline', 'duration'):
            v = resource_fixture()
            if change == 'cpu': v[0][1]['cpu_counter_read_window_ns'][1] += 1000
            if change == 'overlap': v[2]['clocks'][0]['clock_log_end_ns'] = v[2]['clocks'][1]['actual_start_ns'] + 1
            if change == 'deadline': v[2]['deadline_ns'] += 1
            if change == 'duration': v[2]['files_flushed_ns'] = v[2]['tail_due_ns'] - 1
            with self.assertRaises(ValueError): reader.check_resource(*v)

    def test_thread_metrics_are_not_zero_false_or_empty(self):
        for key in ('stable_thread_membership', 'observed_thread_context_switch_delta', 'wakeup_count'):
            for wrong in (0, False, []):
                v = resource_fixture(); v[3][key] = wrong
                with self.assertRaises(ValueError): reader.check_resource(*v)
        for field in ('threads', 'context_switches'):
            v = resource_fixture()
            if field == 'threads': v[0][400]['members'][0][field] = []
            else: v[0][400][field] = 0
            with self.assertRaises(ValueError): reader.check_resource(*v)

    def test_original_PID_generation_missing_or_changed_is_fatal(self):
        for side in ('original_identities_before', 'original_identities_after'):
            v = resource_fixture(); v[0][480][side]['panel']['started'] += 1
            with self.assertRaises(ValueError): reader.check_resource(*v)
        v = resource_fixture(); v[0][480]['members'].pop()
        with self.assertRaises(ValueError): reader.check_resource(*v)

    def test_all_memory_and_process_counter_sums_are_recomputed(self):
        for key in ('pss_kib', 'uss_kib', 'cpu_ticks'):
            v = resource_fixture(); v[0][250][key] += 1
            with self.assertRaises(ValueError): reader.check_resource(*v)
        v = resource_fixture(); v[0][250]['members'][0]['memory_kib']['Private_Dirty'] = -1
        with self.assertRaises(ValueError): reader.check_resource(*v)

    def test_CPU_interval_percent_range_and_summaries_are_recomputed(self):
        for key in ('counter_delta_ticks', 'interval_min_ns', 'interval_max_ns', 'twice_nominal_interval_ns', 'nominal_percent_one_core'):
            v = resource_fixture(); v[3]['cpu_counter_normalization'][key] += 1
            with self.assertRaises(ValueError): reader.check_resource(*v)
        for key in ('pss_kib', 'uss_kib', 'observer_cost_ms', 'late_ms', 'serialization_cost_ms', 'sample_write_cost_ms', 'clock_log_cost_ms', 'observation_intervals_ms'):
            v = resource_fixture(); v[3][key]['p95'] += 1
            with self.assertRaises(ValueError): reader.check_resource(*v)

    def test_changing_membership_CPU_must_be_unknown(self):
        v = resource_fixture()
        v[0][-1]['members'].append({'pid': 70, 'started': 102, 'cpu_ticks': 0, 'memory_kib': {'Pss': 0, 'Rss': 0, 'Private_Clean': 0, 'Private_Dirty': 0}, 'observer_method': reader.METHOD, 'thread_context_switch_collection': reader.COLLECTION, 'threads': None})
        v[3]['stable_process_membership'] = False
        v[3]['cpu_counter_normalization'] = v[3]['cpu_percent_one_core'] = None
        reader.check_resource(*v)
        v[3]['cpu_percent_one_core'] = 0
        with self.assertRaises(ValueError): reader.check_resource(*v)


class NativeContracts(unittest.TestCase):
    def test_both_renderer_original_raw_qualifications_and_resources(self):
        for renderer in ('mygo', 'tauri'):
            reader.check_native(*native_fixture(renderer))

    def test_hidden_focus_wrong_window_and_raw_show_mismatch_are_fatal(self):
        for corruption in ('hidden', 'generation', 'raw_show', 'query_paste'):
            v = native_fixture()
            if corruption == 'hidden': v[1][-1]['active'] = 42
            if corruption == 'generation': v[0]['show_qualifications'][3]['observations'][0]['after_identities']['panel']['started'] += 1
            if corruption == 'raw_show': v[0]['samples'][10]['native']['active'] = 42
            if corruption == 'query_paste': v[0]['actual_paste']['text'] = v[3]['dataset'][6]
            with self.assertRaises(ValueError): reader.check_native(*v)

    def test_negative_proxy_or_inverted_input_sync_cannot_be_hidden_by_summary(self):
        for change in ('future_start', 'future_sync', 'bool_clock'):
            v = native_fixture()
            show = v[0]['samples'][10]
            if change == 'future_start': show['input']['input_start_ns'] = show['native_observed_ns'] + 1
            if change == 'future_sync': show['input']['input_synced_ns'] = show['native']['monotonic_ns'] + 1
            if change == 'bool_clock': show['input']['input_synced_ns'] = True
            show['activation_proxy_ms'] = (show['native_observed_ns'] - show['input']['input_start_ns']) / 1e6
            v[0]['warm_activation_proxy_ms'] = reader.summary([s['activation_proxy_ms'] for s in v[0]['samples']])
            with self.assertRaisesRegex(ValueError, 'causality'): reader.check_native(*v)

    def test_first_helper_unaccepted_status_is_replayed_without_fabricating_ready(self):
        first = {'pid': 69, 'session_id': 'a' * 32}
        pending = {'renderer': 'mygo', 'managed_pid': None, 'session_id': None, 'visible': False, 'last_error': None}
        ready = {'renderer': 'mygo', 'managed_pid': 69, 'session_id': 'a' * 32, 'visible': True, 'last_error': None}
        item = {'tag': 'first-hotkey', 'observations': [{'status': pending}, {'status': ready}], 'final_status': ready}
        wire = [{'command': 'get_quick_paste_surface_status', 'reply': state} for state in (pending, ready)]
        reader.check_qualification_states(item, wire, 'mygo', first)
        for change in ('wire', 'early_accept', 'session', 'error'):
            a, b = copy.deepcopy((item, wire))
            if change == 'wire': b[0]['reply'] = ready
            if change == 'early_accept': a['observations'][0]['status'] = ready; b[0]['reply'] = ready
            if change == 'session': a['observations'][1]['status']['session_id'] = 'b' * 32
            if change == 'error': a['observations'][0]['status']['last_error'] = ''
            with self.assertRaises(ValueError): reader.check_qualification_states(a, b, 'mygo', first)

    def test_reply_empty_error_deadline_wire_and_endpoint_tamper_are_fatal(self):
        for corruption in ('error', 'deadline', 'wire', 'endpoint', 'response', 'session'):
            v = native_fixture()
            if corruption == 'error': v[2][0]['error'] = ''
            if corruption == 'deadline': v[2][0]['response_finished_ns'] += 10**10
            if corruption == 'wire': v[2][0]['wire_bytes'] = 65537
            if corruption == 'endpoint': v[2][0]['original_endpoint']['pid'] += 1
            if corruption == 'response': v[2][0]['actual_response']['value']['ok'] = False
            if corruption == 'session': v[2][0]['reply']['session_id'] = 'wrong'
            with self.assertRaises(ValueError): reader.check_native(*v)

    def test_38exact_tags_counts_and_all_native_rows_required(self):
        for corruption in ('tag', 'reply', 'row', 'xerror'):
            v = native_fixture()
            if corruption == 'tag': v[0]['show_qualifications'][0]['tag'] = 'unknown'
            if corruption == 'reply': v[2].pop()
            if corruption == 'row': v[1].pop()
            if corruption == 'xerror': v[1][0]['x_errors'] = 1
            with self.assertRaises(ValueError): reader.check_native(*v)

    def test_six_namespace_and_credential_exact_denials(self):
        private = {n: n + ':[2]' for n in ('user', 'mnt', 'pid', 'ipc', 'uts', 'net')}
        host = {n: n + ':[1]' for n in private}
        reader.check_namespaces(private, private.copy(), host)
        for name in private:
            wrong = host.copy(); wrong[name] = private[name]
            with self.assertRaises(ValueError): reader.check_namespaces(private, private.copy(), wrong)
        probe = {'status': 'passed', 'architecture': 'native x86_64', 'allowed_getpid': 3,
                 'actual_x32_or_foreign_abi_execution': False, 'proc_status': ['NoNewPrivs:\t1', 'Seccomp:\t2'],
                 'actual_calls': [{'name': n, 'number': v, 'result': -1, 'errno': 1, 'arguments': 'safe invalid, non-mutating'} for n, v in [('add_key', 248), ('request_key', 249), ('keyctl', 250)]]}
        reader.check_credential(probe)
        probe['actual_calls'][1]['errno'] = 2
        with self.assertRaises(ValueError): reader.check_credential(probe)

    def test_original_failed_status_or_cleanup_never_becomes_pass(self):
        report = {'status': 'passed', 'cleanup': {'target': {'exit_code': 0, 'pidfd_exited': True, 'forced': False},
            'webdriver': {'exit_code': -15, 'pidfd_exited': True, 'forced': False}, 'desktop_pidfd_exit': True,
            'wm_exit_code': 0, 'errors': []}, 'paste_prerequisite': {'exit_code': 0, 'native_input_generated': False}}
        receipt = {'status': 'passed', 'exit_code': 0}
        keeper = {'status': 'passed', 'exit_code': 0, 'forced_cleanup': [], 'remaining': []}
        ss = {'status': 'passed', 'command_exit_code': 0, 'helper_unchanged': True, 'processes': [{'exit_code': 0, 'stopped': True}] * 2}
        reader.check_cleanup(receipt, report, keeper, ss)
        for corrupt in ('status', 'first_error', 'forced', 'keeper', 'ss'):
            a, b, c, d = copy.deepcopy((receipt, report, keeper, ss))
            if corrupt == 'status': a['exit_code'] = 1
            if corrupt == 'first_error': b['first_error'] = {'message': ''}
            if corrupt == 'forced': b['cleanup']['webdriver']['forced'] = True
            if corrupt == 'keeper': c['remaining'] = [68]
            if corrupt == 'ss': d['helper_unchanged'] = False
            with self.assertRaises(ValueError): reader.check_cleanup(a, b, c, d)

    def test_private_SS_and_pre_Desktop_tool_original_streams(self):
        with tempfile.TemporaryDirectory() as temp:
            raw = Path(temp).resolve(); (raw / 'functional').mkdir()
            for stream, data in [('stdout', b'xdotool version 3.20160805.1\n'), ('stderr', b'')]:
                (raw / ('functional/paste-tool-version.' + stream + '.log')).write_bytes(data)
            config = {'inputs': {'private_ss_helper': {'sha256': 'abc'}, 'paste_tool': {'sha256': 'def'}, 'paste_tool_proof': {'sha256': 'ghi'}}}
            command = ['/fixed/python', '-s', '-B', '/fixture-bin/inner.py', '--inside']
            keeper = {'command': ['/usr/bin/xvfb-run', '-f', '/q/phase6.xauthority', '-a', '-s', '-screen 0 1280x900x24 -noreset', *command]}
            ss = {'backend': 'explicit_secret_service', 'keyutils_constructed': False,
                  'system_keyring_isolation_claimed': False, 'helper': '/fixture-bin/private-ss-preseed',
                  'helper_sha256': 'abc', 'helper_sha256_after': 'abc', 'private_root': '/q/dezirclip-private-ss-synthetic',
                  'steps': [{'operation': 'seed', 'exit_code': 0}, {'operation': 'check', 'exit_code': 0}, {'operation': 'seed', 'exit_code': 1, 'stderr': '{"reason":"ExistingCredentialRefused"}'}], 'command': command}
            probe = {'tool': config['inputs']['paste_tool'], 'proof': config['inputs']['paste_tool_proof'],
                     'executable_run': True, 'command': ['/fixture-bin/xdotool', 'version'], 'started_ns': 1, 'finished_ns': 2, 'private_namespaces': {'test': 1}}
            for stream in ('stdout', 'stderr'):
                value = reader.record(raw / ('functional/paste-tool-version.' + stream + '.log'))
                probe[stream] = {k: value[k] for k in ('bytes', 'sha256')}
            report = {'paste_prerequisite': probe, 'private_namespaces': {'test': 1}}
            reader.check_private_proofs(report, keeper, ss, config, raw)
            for change in ('helper', 'root', 'negative', 'stream'):
                a, b = copy.deepcopy((report, ss))
                if change == 'helper': b['helper_sha256_after'] = 'different'
                if change == 'root': b['private_root'] = '/run/user/ambient'
                if change == 'negative': b['steps'][2]['stderr'] = '{"reason":"OtherFailure"}'
                if change == 'stream': a['paste_prerequisite']['stdout']['sha256'] = 'different'
                with self.assertRaises(ValueError): reader.check_private_proofs(a, keeper, b, config, raw)

    def test_host_nulls_private_cleanup_binding_and_display_limits(self):
        name = reader.ARMS[0]['run_name']
        windows = {stage: {'schema_version': 1, 'kind': 'phase6_windows_host_unverified', 'source_revision': reader.SOURCE,
            'arm': name, 'stage': stage, 'collection_status': 'unverified_no_local_WinAPI', 'known_compiler_names': None,
            'compiler_processes': None, 'native_names': None, 'host_idle': None, 'observation_performed': False,
            'quiet_window_certified': False} for stage in ('preflight', 'postflight')}
        linux = {'schema_version': 1, 'kind': 'phase6_linux_postflight_scoped_observation', 'source_revision': reader.SOURCE,
            'arm': name, 'host_observation': {'collection_status': 'observed_linux_proc_names_only', 'compiler_processes': [],
            'known_product_processes': [], 'host_idle': None, 'observed_display_services': [{'pid': 99, 'name': 'Xvfb', 'source_status': 'unverified', 'operated': False}]},
            'private_cleanup_binding': {'cleanup': {'test': True}, 'keeper': {'test': 1}, 'secret_service': {'test': 2}}}
        reader.check_host(windows, linux, name, {'test': True}, {'test': 1}, {'test': 2})
        for change in ('windows', 'display', 'compiler', 'binding'):
            a, b = copy.deepcopy((windows, linux))
            if change == 'windows': a['preflight']['compiler_processes'] = []
            if change == 'display': b['host_observation']['observed_display_services'][0]['operated'] = True
            if change == 'compiler': b['host_observation']['compiler_processes'] = [42]
            if change == 'binding': b['private_cleanup_binding']['keeper'] = {'test': 3}
            with self.assertRaises(ValueError): reader.check_host(a, b, name, {'test': True}, {'test': 1}, {'test': 2})

    def test_Root_original_PNG_view_bytes_query_and_content_must_all_match(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp).resolve(); raw = root / 'raw'; (raw / 'functional').mkdir(parents=True)
            cohort = root / 'cohort'; cohort.mkdir(); name = reader.ARMS[0]['run_name']
            png = b'\x89PNG\r\n\x1a\n' + b'\0' * 8 + (480).to_bytes(4, 'big') + (360).to_bytes(4, 'big')
            source = raw / 'functional/resource-visible-query.png'; source.write_bytes(png)
            copied = cohort / (name + '.setup.png'); copied.write_bytes(png)
            proof = {'source': reader.record(source), 'copy': reader.record(copied), 'sha256_verified_equal': True, 'postflight_linux_scope': {}}
            (cohort / (name + '.setup-copy-proof.json')).write_text(json.dumps(proof), encoding='utf-8')
            view = {'actual_view_completed': True, 'reviewer': 'Root', 'status': 'passed', 'arm': name, 'source_revision': reader.SOURCE,
                    'png_sha256': reader.record(source)['sha256'], 'exact_query': 'dzcp6needle7', 'visible_matching_rows': 1, 'full_visible_content': 'row7'}
            view_path = cohort / (name + '.root-png.json'); view_path.write_text(json.dumps(view), encoding='utf-8')
            report = {'resource_query_setup': {'query': 'dzcp6needle7', 'expected_content': 'row7', 'stored_rows': 10, 'expected_matching_rows': 1,
                      'setup_wait_seconds': .7, 'screenshot': {'sha256': view['png_sha256']}}}
            with mock.patch.object(reader, 'COHORT', cohort):
                reader.check_png(name, report, {'dataset': [''] * 7 + ['row7']}, raw)
                for key, value in [('actual_view_completed', False), ('full_visible_content', 'wrong'), ('exact_query', 'wrong'), ('png_sha256', '0' * 64)]:
                    wrong = {**view, key: value}; view_path.write_text(json.dumps(wrong), encoding='utf-8')
                    with self.assertRaises(ValueError): reader.check_png(name, report, {'dataset': [''] * 7 + ['row7']}, raw)


class FileAndContractTests(unittest.TestCase):
    def test_strict_JSON_finite_and_duplicate_keys(self):
        for data in (b'{"x":1,"x":2}', b'{"x":NaN}'):
            with self.assertRaises(ValueError): reader.parse(data)
        reader.equal(False, False)
        for actual, expected in ((0, None), ([], None), (0, False), (True, 1)):
            with self.assertRaises(ValueError): reader.equal(actual, expected)

    def test_bounded_file_hash_and_truncated_JSONL(self):
        with tempfile.TemporaryDirectory() as temp:
            p = Path(temp).resolve() / 'file'
            p.write_bytes(b'{"x":1}\n')
            reader.verify(reader.record(p), p)
            self.assertEqual(reader.rows(p), [{'x': 1}])
            with self.assertRaises(ValueError): reader.body(p, 1)
            p.write_bytes(b'{"x":1}')
            with self.assertRaises(ValueError): reader.rows(p)

    def test_file_read_drift_is_fatal(self):
        with tempfile.TemporaryDirectory() as temp:
            p = Path(temp).resolve() / 'file'; p.write_bytes(b'ab')
            original = Path.stat; calls = 0
            def drift(path, *args, **kwargs):
                nonlocal calls
                value = original(path, *args, **kwargs)
                if path == p and kwargs.get('follow_symlinks', True):
                    calls += 1
                    if calls >= 2:
                        class Changed:
                            st_dev = value.st_dev
                            st_ino = value.st_ino
                            st_size = value.st_size
                            st_mode = value.st_mode
                            st_mtime_ns = value.st_mtime_ns + 1
                        return Changed()
                return value
            with mock.patch.object(Path, 'stat', drift), self.assertRaises(ValueError): reader.body(p)

    def test_exclusive_terminal_publication_and_no_post_link_IO(self):
        with tempfile.TemporaryDirectory() as temp:
            p = Path(temp).resolve() / 'review.json'
            reader.publish(p, {'test': True})
            self.assertEqual(p.read_bytes(), p.with_suffix('.pending.json').read_bytes())
            with self.assertRaises(ValueError): reader.publish(p, {'test': True})
        tree = ast.parse((HERE / 'review_arm.py').read_text(encoding='utf-8'))
        function = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'publish')
        self.assertEqual(ast.unparse(function.body[-1]), 'os.link(pending, path)')

    def test_readback_or_link_failure_never_publishes_pass(self):
        with tempfile.TemporaryDirectory() as temp:
            for kind in ('readback', 'link'):
                p = Path(temp).resolve() / (kind + '.json')
                patch = mock.patch.object(reader, 'body', side_effect=OSError('readback')) if kind == 'readback' else mock.patch.object(reader.os, 'link', side_effect=OSError('link'))
                with patch, self.assertRaises(OSError): reader.publish(p, {'status': 'passed'})
                self.assertFalse(p.exists())

    def test_first_error_preserved_even_when_failure_audit_write_fails(self):
        with tempfile.TemporaryDirectory() as temp, mock.patch.object(reader, 'COHORT', Path(temp).resolve()), mock.patch.object(reader.sys, 'platform', 'linux'):
            with mock.patch.object(reader, 'inspect_arm', side_effect=ValueError('original first error')) as inspect:
                with mock.patch.object(reader, 'publish', side_effect=OSError('audit save')):
                    with self.assertRaisesRegex(ValueError, 'original first error'): reader.review_once(1, '0' * 64)
                inspect.assert_called_once()
            self.assertEqual(list(Path(temp).iterdir()), [])

    def test_failure_only_audit_cannot_produce_closed_success(self):
        with tempfile.TemporaryDirectory() as temp, mock.patch.object(reader, 'COHORT', Path(temp).resolve()), mock.patch.object(reader.sys, 'platform', 'linux'):
            with mock.patch.object(reader, 'inspect_arm', side_effect=ValueError('native failed')):
                with self.assertRaisesRegex(ValueError, 'native failed'): reader.review_once(1, '0' * 64)
            stem = reader.ARMS[0]['run_name']
            self.assertFalse((Path(temp) / (stem + '.independent-raw-review.json')).exists())
            failure = json.loads((Path(temp) / (stem + '.independent-raw-failure.json')).read_text(encoding='utf-8'))
            self.assertEqual(failure['status'], 'failed')
            self.assertFalse(failure['phase6_passed'])

    def test_existing_or_wrong_host_cannot_start_actual_inspection(self):
        with mock.patch.object(reader.sys, 'platform', 'win32'), mock.patch.object(reader, 'inspect_arm') as inspect:
            with self.assertRaises(ValueError): reader.review_once(1, '0' * 64)
            inspect.assert_not_called()
        for suffix in ('independent-raw-review.json', 'independent-raw-failure.json'):
            with tempfile.TemporaryDirectory() as temp, mock.patch.object(reader, 'COHORT', Path(temp).resolve()), mock.patch.object(reader.sys, 'platform', 'linux'), mock.patch.object(reader, 'inspect_arm') as inspect:
                (Path(temp) / (reader.ARMS[0]['run_name'] + '.' + suffix)).write_bytes(b'old')
                with self.assertRaises(ValueError): reader.review_once(1, '0' * 64)
                inspect.assert_not_called()

    def test_inspect_arm_keeps_original_run_name_through_packet_pin_loop(self):
        with tempfile.TemporaryDirectory() as temp:
            cohort = Path(temp).resolve()
            arm = reader.ARMS[0]
            manifest = {'schema_version': 1, 'kind': 'phase6_F2_process_only_integration_manifest',
                'source_revision': reader.SOURCE, 'observer_method': reader.METHOD,
                'thread_context_switch_collection': reader.COLLECTION,
                'policy': {'path': str(reader.INTEGRATION / 'source-plan.json'), 'sha256': reader.INTEGRATION_PINS['source-plan.json'][1]},
                'sources': {}, 'plan': {'path': str(cohort / 'comparison-count-v1.plan.json')},
                'preparation': {'path': str(cohort / 'preparation.json')}, 'pending': {}, 'prerequisites': {}, 'r3_schemas': {}}
            plan = {'observer_method': reader.METHOD, 'thread_context_switch_collection': reader.COLLECTION,
                    'arms': list(reader.ARMS), 'root_go': False, 'performance_eligible': False,
                    'expected': {'source_revision': reader.SOURCE}}
            expected = cohort / (arm['run_name'] + '.execution.json')
            class ExpectedExecutionReached(Exception): pass
            def fake_record(path):
                path = Path(path)
                if path == expected: raise ExpectedExecutionReached()
                if path.name == 'integration-manifest.json': return {'path': str(path), 'bytes': 1, 'sha256': '0' * 64}
                if path.name in reader.PACKET_PINS:
                    size, digest = reader.PACKET_PINS[path.name]
                    return {'path': str(path), 'bytes': size, 'sha256': digest}
                raise AssertionError('Unexpected fake file read: ' + str(path))
            def fake_read(path, *args):
                if Path(path).name == 'integration-manifest.json': return manifest
                if Path(path).name == 'comparison-count-v1.plan.json': return plan
                raise AssertionError('Unexpected fake JSON read')
            with mock.patch.object(reader, 'COHORT', cohort), mock.patch.object(reader, 'record', fake_record), mock.patch.object(reader, 'read', fake_read):
                with self.assertRaises(ExpectedExecutionReached): reader.inspect_arm(1, '0' * 64)
        tree = ast.parse((HERE / 'review_arm.py').read_text(encoding='utf-8'))
        inspect = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'inspect_arm')
        self.assertEqual(sum(isinstance(n, ast.Name) and isinstance(n.ctx, ast.Store) and n.id == 'name' for n in ast.walk(inspect)), 1)

    def test_source_policy_closed_schema_and_six_real_source_pins(self):
        policy = json.loads((reader.INTEGRATION / 'source-plan.json').read_text(encoding='utf-8'))
        contract = policy['independent_raw_review']
        self.assertEqual(reader.FIELDS, set(contract['closed_required_fields']))
        self.assertEqual(reader.CHECKS, set(contract['checks_all_genuinely_reviewed']))
        for name, pin in reader.INTEGRATION_PINS.items():
            actual = reader.record(reader.INTEGRATION / name)
            self.assertEqual((actual['bytes'], actual['sha256']), pin)
        for name, pin in reader.PACKET_PINS.items():
            actual = reader.record(reader.COHORT / name)
            self.assertEqual((actual['bytes'], actual['sha256']), pin)

    def test_no_native_imports_commands_or_assessor_result_execution(self):
        tree = ast.parse((HERE / 'review_arm.py').read_text(encoding='utf-8'))
        imports = {a.name.split('.')[0] for n in ast.walk(tree) if isinstance(n, (ast.Import, ast.ImportFrom)) for a in n.names}
        self.assertFalse(imports & {'subprocess', 'ctypes', 'socket', 'importlib', 'shutil'})
        call_names = {ast.unparse(n.func) for n in ast.walk(tree) if isinstance(n, ast.Call)}
        self.assertFalse(call_names & {'exec', 'eval', 'os.system', 'os.execv', 'os.execvpe', 'authorize', 'validate_outer'})
        inspect = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'inspect_arm')
        self.assertEqual(sum(isinstance(n, ast.Call) and ast.unparse(n.func) == 'source_snapshot' for n in ast.walk(inspect)), 2)
        self.assertEqual(sum(isinstance(n, ast.Call) and ast.unparse(n.func) == 'inventory' for n in ast.walk(inspect)), 2)
        for name in ('check_resource', 'check_native', 'check_credential', 'check_namespaces', 'check_cleanup', 'check_private_proofs', 'check_host', 'check_png', 'check_prerequisites'):
            self.assertTrue(any(isinstance(n, ast.Call) and ast.unparse(n.func) == name for n in ast.walk(inspect)), name)

    def test_reference_summary_and_nonthread_numeric_formulas_retained(self):
        reference_path = HERE.parents[3] / 'v02-phase6-results/dezirclip/docs/evidence/phase6-linux-count-v1/verify-linux-count-v1.py'
        reference = ast.parse(reference_path.read_text(encoding='utf-8'))
        current = ast.parse((HERE / 'review_arm.py').read_text(encoding='utf-8'))
        functions = lambda tree: {n.name: n for n in tree.body if isinstance(n, ast.FunctionDef)}
        old, new = functions(reference), functions(current)
        dump = lambda n: ast.dump(n, include_attributes=False)
        self.assertEqual(dump(old['summary']), dump(new['summary']))
        old_expressions = {dump(n) for n in ast.walk(old['check_resource']) if isinstance(n, (ast.BinOp, ast.Compare))}
        new_expressions = {dump(n) for n in ast.walk(new['check_resource']) if isinstance(n, (ast.BinOp, ast.Compare))}
        for expression in ('delta * 200000000000.0 / (hz * twice)', 'delta * 100000000000.0 / (hz * high)', 'delta * 100000000000.0 / (hz * low)', "saved['due_ns'] == (previous['actual_start_ns'] + 250000000 if previous else progress['started_ns'])", "saved['actual_start_ns'] <= saved['capture_end_ns'] <= saved['serialization_end_ns'] <= saved['sample_write_end_ns'] <= saved['clock_log_end_ns'] < progress['deadline_ns']"):
            node = ast.parse(expression, mode='eval').body
            self.assertIn(dump(node), old_expressions)
            self.assertIn(dump(node), new_expressions)


if __name__ == '__main__':
    unittest.main(verbosity=2)

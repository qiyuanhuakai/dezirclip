"""Independent, file-only review of a completed F2 process-only arm; no fixture entry calls."""
import argparse
import collections
import hashlib
import json
import math
import os
from pathlib import Path
import re
import stat
import struct
import sys

HERE = Path(__file__).resolve().parent
HARNESS = HERE.parent
COHORT = HARNESS / 'phase6-linux-count-process-only-v2-1fe685c-20261102'
INTEGRATION = HARNESS / 'phase6-linux-process-only-v2-integration-20261102'
NATIVE = HARNESS / 'phase6-linux-process-only-v2-method-20261102'
FOUNDATION = HARNESS / 'phase6-linux-recovery-20261028'
SOURCE = '1fe685c424602b2bc1892f1deb0794c2e0b90ad5'
RAW_BASE = Path('/home/qiyuaner/.cache/dezirclip-v02/phase6-performance-recovered') / SOURCE
METHOD = 'process-resource-only-v2'
COLLECTION = 'not_collected'
ARMS = tuple({'arm_index': i, 'renderer': r, 'run_name': f'process-v2-1fe685c-{i}-{r}'}
             for i, r in enumerate(('tauri', 'mygo', 'mygo', 'tauri'), 1))
INTEGRATION_PINS = {
    'authorize_arm.py': (31596, '708bda05e07289cfc782e642503f7b89320371008dd9d9e3e160e13e6a26ed3b'),
    'postflight_arm.py': (4807, 'c8c9554d2dcbf488c4bd81b83c50f089ee87da8586c56215ad809c355b096985'),
    'prepare_packet.py': (8789, 'bd37ca59f72c849a73bc90c7cf2a8ca09fc8f9049285a038c024fa6a0869c982'),
    'source-plan.json': (10326, 'fc29660de7f582e70d9d613ce09fe262d5a8b227ae87fdf378063150df195c7d'),
    'summarize_descriptive.py': (9777, 'be33ee777ed570f2458e3e6bb751e16d7dbfb492e25789b02c8adc2bf9463237'),
    'test_integration.py': (24872, '44025fb842e5893069768f27b08519cd965f6d7f92610928b72f2747e112954d')}
PREREQUISITE_PINS = {
    'input_provenance': (2305, '525509b44787603a99b751b2e3e460abe5e8463c149b0c59832039509c789ddd'),
    'original19_assessment': (30858, 'aa2f2c687080f511db6b51469439617715e392b0a1025938dfd938b5dee252f8'),
    'original19_independent_review': (49536, '101b62bed1a72fd34234bc666db101ae46ba9c3b4a9a2fd010d338899dccaed7'),
    'idle_R3_assessment': (41372, '9f8ea181fefb870be112c8787972479c838b17e749fff99c1e2587174df14871'),
    'idle_R3_independent_review': (51799, 'dd5816ed7a3196e3ae68c8ff81830292e8cc39b10cd6c39c1e3e5158237f19cf')}
R3_PHASES = ['real-ewmh-wm', 'actual-native-surface-identity', 'actual-desktop-identity',
             'actual-private-data-path', 'real-host-seed-ten', 'first-native-show', 'actual-initial-hide',
             'idle-before-real-registered-hotkey', 'same-original-helper-after-idle-hotkey',
             'idle-recovery-query-and-one-enter', 'idle-before-normal-disable',
             'normal-disable-confirms-original-helper-exit', 'owner-history-retained']
CHECKS = {'original_bytes', 'all_raw_evidence', 'input_and_source_identity', 'six_namespaces',
          'native_focus_and_paste', 'qualifications_and_replies', 'original_process_identities',
          'all_capture_rows_and_clocks', 'process_counter_math', 'thread_metrics_not_collected',
          'root_actual_png_view', 'private_pidfd_keeper_secret_service_cleanup', 'unverified_host_metadata_limits'}
FIELDS = {'kind', 'status', 'source_revision', 'observer_method', 'thread_context_switch_collection',
          'arm', 'renderer', 'arm_index', 'reviewer_role', 'independent_from_authorizer_and_assessor_author',
          'actual_original_raw_review_completed', 'whole_ABBA_complete', 'checks', 'root_assessment',
          'root_png_evidence', 'setup_copy_proof', 'assessor', 'integration_manifest', 'reviewer_reader',
          'execution', 'raw_evidence', 'whole_host_idle', 'quiet_window', 'performance_acceptance',
          'performance_eligible', 'phase6_passed', 'phase7_authorized', 'next_arm_authorized'}
MAX_FILE = 128 * 1024 * 1024
MAX_JSON = 4 * 1024 * 1024
PACKET_PINS = {'comparison-count-v1.plan.json': (15910, 'e4969e87289bc5438a15f5ffcbad2e403e51b6082da06d6bf084dda15e16a7d8'),
               'preparation.json': (23665, '37f09bbcb4949f616122a1b831f14ec127a37285e55248d645e702a9346d4961')}


def require(condition, message):
    if not condition:
        raise ValueError(message)


def summary(values):
    values = sorted(values)
    require(values and all(type(v) in (int, float) and math.isfinite(v) for v in values), 'Invalid numeric vector')
    return {'count': len(values), 'min': values[0], 'max': values[-1], 'mean': sum(values) / len(values),
            'p50': values[math.ceil(len(values) * .5) - 1], 'p95': values[math.ceil(len(values) * .95) - 1]}


def equal(actual, expected, path='value'):
    if isinstance(expected, dict):
        require(isinstance(actual, dict) and set(actual) == set(expected), path + ': object keys differ')
        for key in expected:
            equal(actual[key], expected[key], path + '.' + key)
    elif isinstance(expected, list):
        require(isinstance(actual, list) and len(actual) == len(expected), path + ': array differs')
        for index, value in enumerate(expected):
            equal(actual[index], value, path + '[' + str(index) + ']')
    elif type(expected) is int:
        require(type(actual) is int and actual == expected, path + ': integer differs')
    elif type(expected) is float:
        require(type(actual) in (int, float) and math.isfinite(actual) and math.isclose(actual, expected, rel_tol=1e-12, abs_tol=1e-9), path + ': number differs')
    else:
        require(type(actual) is type(expected) and actual == expected, path + ': value differs')


def body(path, limit=MAX_FILE):
    path = Path(path)
    require(path.is_absolute() and not any(p.is_symlink() for p in (path, *path.parents)), 'Absolute nonsymlink file required')
    before = path.stat()
    require(stat.S_ISREG(before.st_mode) and 0 <= before.st_size <= limit, 'Regular bounded file required')
    with path.open('rb') as stream:
        value = stream.read(limit + 1)
    after = path.stat()
    require(len(value) == before.st_size <= limit and
            (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) ==
            (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns), 'File drift during read')
    return value


def record(path):
    data = body(path)
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def parse(data):
    def unique(items):
        result = {}
        for key, value in items:
            require(key not in result, 'Duplicate JSON key')
            result[key] = value
        return result
    return json.loads(data, object_pairs_hook=unique,
                      parse_constant=lambda v: (_ for _ in ()).throw(ValueError('Nonfinite JSON: ' + v)))


def read(path, limit=MAX_JSON):
    return parse(body(path, limit))


def rows(path):
    data = body(path)
    require(data.endswith(b'\n'), 'Incomplete JSONL final line')
    values = [parse(line) for line in data.splitlines()]
    require(values and len(values) <= 100000, 'Empty or excessive JSONL')
    return values


def verify(reference, path=None):
    require(type(reference) is dict and set(reference) == {'path', 'bytes', 'sha256'}, 'Exact file reference required')
    require(type(reference['bytes']) is int and reference['bytes'] >= 0 and
            type(reference['sha256']) is str and re.fullmatch('[0-9a-f]{64}', reference['sha256']), 'Invalid file reference')
    if path is not None:
        require(reference['path'] == str(path), 'Unexpected original file path')
    equal(record(reference['path']), reference, 'original file')
    return reference


def method(value):
    require(value['observer_method'] == METHOD and value['thread_context_switch_collection'] == COLLECTION, 'Process-only method differs')


def scope(value):
    for key in ('performance_eligible', 'phase6_passed', 'phase7_authorized', 'next_arm_authorized'):
        require(value[key] is False, 'Unqualified acceptance claim: ' + key)
    for key in ('whole_host_idle', 'quiet_window', 'performance_acceptance'):
        require(value[key] is None, 'Unknown host/performance claim: ' + key)


def inventory(root):
    require(root.is_dir() and not root.is_symlink(), 'Original raw directory missing')
    result = {}
    for path in sorted(root.rglob('*')):
        require(len(result) < 4096, 'Raw inventory bound')
        mode = path.lstat().st_mode
        require(stat.S_ISDIR(mode) or stat.S_ISREG(mode), 'Nonregular raw object')
        if stat.S_ISREG(mode):
            result[path.relative_to(root).as_posix()] = record(path)
    require(sum(item['bytes'] for item in result.values()) <= 1024 * 1024 * 1024, 'Raw total bound')
    return result


def check_resource(rows, clocks, progress, metric, main, panel):
    require(all(type(progress[k]) is int for k in ('requested_count', 'capture_calls', 'samples_written', 'interval_ns', 'deadline_ns', 'started_ns', 'tail_due_ns', 'tail_reached_ns', 'files_flushed_ns')), 'Progress integers required')
    require(len(rows) == len(clocks) == len(progress['clocks']) == 960, 'Resource/clock count differs')
    require(progress['requested_count'] == progress['capture_calls'] == progress['samples_written'] == 960, 'Resource capture accounting differs')
    require(progress['kind'] == 'event-anchored-count-v1' and progress['status'] == 'passed' and metric['sampling_protocol'] == 'event-anchored-count-v1' and type(metric['sample_count']) is int and metric['sample_count'] == 960, 'Resource protocol differs')
    require(progress['interval_ns'] == 250000000 and 0 < progress['deadline_ns'] - progress['started_ns'] <= 1260000000000, 'Resource interval/deadline differs')
    method(metric)
    for key in ('stable_thread_membership', 'observed_thread_context_switch_delta', 'wakeup_count'):
        require(metric[key] is None, 'Uncollected thread metric must be null')
    families, previous = [], None
    clock_keys = {'index', 'due_ns', 'actual_start_ns', 'late_ns', 'capture_end_ns', 'serialization_end_ns', 'sample_write_end_ns', 'clock_log_end_ns'}
    for index, (row, clock, saved) in enumerate(zip(rows, clocks, progress['clocks']), 1):
        require(set(saved) == clock_keys and all(type(v) is int for v in saved.values()), 'Clock schema differs')
        equal(clock, {key: value for key, value in saved.items() if key != 'clock_log_end_ns'}, 'raw clock')
        equal(row['sampling_clock'], {key: saved[key] for key in ('index', 'due_ns', 'actual_start_ns', 'late_ns', 'capture_end_ns')})
        require(type(row['snapshot_index']) is int and type(row['monotonic_ns']) is int, 'Sample integer clock required')
        require(saved['index'] == row['snapshot_index'] == index and row['monotonic_ns'] == saved['actual_start_ns'], 'Sample index/time differs')
        require(saved['due_ns'] == (previous['actual_start_ns'] + 250000000 if previous else progress['started_ns']), 'Pacing differs')
        require(saved['late_ns'] == saved['actual_start_ns'] - saved['due_ns'] >= 0, 'Lateness differs')
        require(saved['actual_start_ns'] <= saved['capture_end_ns'] <= saved['serialization_end_ns'] <= saved['sample_write_end_ns'] <= saved['clock_log_end_ns'] < progress['deadline_ns'], 'Clock ordering differs')
        require(type(row['observer_cost_ns']) is int and 0 <= row['observer_cost_ns'] <= saved['capture_end_ns'] - saved['actual_start_ns'], 'Observer cost differs')
        bounds = row['cpu_counter_read_window_ns']
        require(len(bounds) == 2 and all(type(v) is int for v in bounds) and saved['actual_start_ns'] <= bounds[0] <= bounds[1] <= saved['capture_end_ns'], 'CPU read window differs')
        if previous:
            require(saved['actual_start_ns'] >= previous['clock_log_end_ns'], 'Capture overlaps prior clock write')
        previous = saved
        method(row)
        require(row['context_switches'] is None, 'Uncollected context switches must be null')
        members = row['members']
        require(type(members) is list and members and len({m['pid'] for m in members}) == len(members), 'Duplicate/empty process family')
        family = {(m['pid'], m['started']) for m in members}
        require({(main['pid'], main['started']), (panel['pid'], panel['started'])} <= family, 'Original process missing')
        for member in members:
            method(member)
            require(member['threads'] is None, 'Uncollected threads must be null')
            require(all(type(member[k]) is int and member[k] > 0 for k in ('pid', 'started')), 'Invalid process identity')
            require(type(member['cpu_ticks']) is int and member['cpu_ticks'] >= 0, 'Invalid CPU counter')
            memory = member['memory_kib']
            require({'Pss', 'Rss', 'Private_Clean', 'Private_Dirty'} <= set(memory) and all(type(v) is int and v >= 0 for v in memory.values()), 'Invalid memory counters')
        equal(row['pss_kib'], sum(m['memory_kib']['Pss'] for m in members), 'PSS sum')
        equal(row['uss_kib'], sum(sum(m['memory_kib'].get(k, 0) for k in ('Private_Clean', 'Private_Dirty', 'Private_Hugetlb')) for m in members), 'USS sum')
        equal(row['cpu_ticks'], sum(m['cpu_ticks'] for m in members), 'CPU sum')
        families.append(family)
        for side in ('original_identities_before', 'original_identities_after'):
            for role, identity in (('main', main), ('panel', panel)):
                require(all(row[side][role][k] == identity[k] for k in ('pid', 'started')), 'Retained identity differs')
    require(progress['tail_due_ns'] == previous['actual_start_ns'] + 250000000, 'Tail deadline differs')
    require(max(progress['tail_due_ns'], previous['clock_log_end_ns']) <= progress['tail_reached_ns'] <= progress['files_flushed_ns'] < progress['deadline_ns'], 'Tail/flush ordering differs')
    require(progress['files_flushed_ns'] - progress['started_ns'] >= 240000000000 and rows[-1]['monotonic_ns'] - rows[0]['monotonic_ns'] >= 239750000000, 'Capture duration differs')
    equal(metric['actual_elapsed_seconds'], (progress['files_flushed_ns'] - progress['started_ns']) / 1000000000.0)
    equal(metric['sample_span_seconds'], (rows[-1]['monotonic_ns'] - rows[0]['monotonic_ns']) / 1000000000.0)
    for key in ('pss_kib', 'uss_kib'):
        equal(metric[key], summary([row[key] for row in rows]), key)
    equal(metric['observer_cost_ms'], summary([row['observer_cost_ns'] / 1000000.0 for row in rows]))
    equal(metric['late_ms'], summary([clock['late_ns'] / 1000000.0 for clock in progress['clocks']]))
    for name, start, end in (('serialization_cost_ms', 'capture_end_ns', 'serialization_end_ns'), ('sample_write_cost_ms', 'serialization_end_ns', 'sample_write_end_ns'), ('clock_log_cost_ms', 'sample_write_end_ns', 'clock_log_end_ns')):
        equal(metric[name], summary([(c[end] - c[start]) / 1000000.0 for c in progress['clocks']]))
    equal(metric['observation_intervals_ms'], summary([(b['monotonic_ns'] - a['monotonic_ns']) / 1000000.0 for a, b in zip(rows, rows[1:])]))
    stable = all(family == families[0] for family in families)
    require(metric['stable_process_membership'] is stable, 'Process stability differs')
    if not stable:
        require(metric['cpu_counter_normalization'] is None and metric['cpu_percent_one_core'] is None, 'Changing process family CPU must be unknown')
        return
    first, last = rows[0]['cpu_counter_read_window_ns'], rows[-1]['cpu_counter_read_window_ns']
    delta, hz = rows[-1]['cpu_ticks'] - rows[0]['cpu_ticks'], metric['cpu_clock_ticks_per_second']
    low, high, twice = last[0] - first[1], last[1] - first[0], sum(last) - sum(first)
    require(delta >= 0 and type(hz) is int and hz > 0 and 0 < low <= twice / 2 <= high, 'CPU normalization invalid')
    cpu = metric['cpu_counter_normalization']
    for key, value in {'counter_delta_ticks': delta, 'interval_min_ns': low, 'interval_max_ns': high, 'twice_nominal_interval_ns': twice}.items():
        equal(cpu[key], value)
    equal(cpu['nominal_percent_one_core'], delta * 200000000000.0 / (hz * twice))
    equal(cpu['read_window_normalization_percent_range'], [delta * 100000000000.0 / (hz * high), delta * 100000000000.0 / (hz * low)])
    equal(metric['cpu_percent_one_core'], cpu['nominal_percent_one_core'])


def check_namespaces(report, keeper, host):
    names = {'user', 'mnt', 'pid', 'ipc', 'uts', 'net'}
    require(set(report) == set(keeper) == set(host) == names and report == keeper, 'Six namespace records differ')
    for name in names:
        require(all(type(v) is str and re.fullmatch(name + r':\[[0-9]+\]', v) for v in (report[name], host[name])) and report[name] != host[name], 'Namespace not private')


def check_credential(probe):
    require(probe['status'] == 'passed' and probe['architecture'] == 'native x86_64' and
            type(probe['allowed_getpid']) is int and probe['allowed_getpid'] > 0 and probe['actual_x32_or_foreign_abi_execution'] is False, 'Credential probe differs')
    calls = probe['actual_calls']
    require([(v['name'], v['number']) for v in calls] == [('add_key', 248), ('request_key', 249), ('keyctl', 250)], 'Credential syscall inventory differs')
    require(all(v['result'] == -1 and v['errno'] == 1 and v['arguments'] == 'safe invalid, non-mutating' for v in calls), 'Credential denial differs')
    require('NoNewPrivs:\t1' in probe['proc_status'] and 'Seccomp:\t2' in probe['proc_status'], 'Credential filter state missing')


def check_cleanup(receipt, report, keeper, ss):
    require(receipt['status'] == report['status'] == keeper['status'] == ss['status'] == 'passed', 'Original failed status retained')
    require(receipt['exit_code'] == keeper['exit_code'] == ss['command_exit_code'] == 0 and 'forced_outer_stop' not in receipt and report.get('first_error') is None, 'Original failure or forced stop retained')
    cleanup = report['cleanup']
    equal(cleanup['target'], {'exit_code': 0, 'pidfd_exited': True, 'forced': False})
    require(cleanup['webdriver']['exit_code'] == -15 and cleanup['webdriver']['pidfd_exited'] is True and cleanup['webdriver']['forced'] is False, 'Original driver cleanup differs')
    require(cleanup['desktop_pidfd_exit'] is True and cleanup['wm_exit_code'] == 0 and cleanup['errors'] == [] and keeper['forced_cleanup'] == [] and keeper['remaining'] == [], 'Original private cleanup incomplete')
    require(len(ss['processes']) == 2 and all(v['exit_code'] == 0 and v['stopped'] is True for v in ss['processes']) and ss['helper_unchanged'] is True, 'Private Secret Service cleanup differs')
    require(report['paste_prerequisite']['exit_code'] == 0 and report['paste_prerequisite']['native_input_generated'] is False, 'Pre-Desktop paste prerequisite differs')
    return cleanup


def check_private_proofs(report, keeper, ss, config, raw):
    require(ss['backend'] == 'explicit_secret_service' and ss['keyutils_constructed'] is False and
            ss['system_keyring_isolation_claimed'] is False and ss['helper'] == '/fixture-bin/private-ss-preseed' and
            ss['helper_sha256'] == ss['helper_sha256_after'] == config['inputs']['private_ss_helper']['sha256'], 'Private SS helper/backend differs')
    require(type(ss['private_root']) is str and re.fullmatch('/q/dezirclip-private-ss-[A-Za-z0-9_-]+', ss['private_root']), 'Private SS root differs')
    require([(v['operation'], v['exit_code']) for v in ss['steps']] == [('seed', 0), ('check', 0), ('seed', 1)] and
            parse(ss['steps'][2]['stderr'])['reason'] == 'ExistingCredentialRefused', 'Private SS positive/negative proof differs')
    require(ss['command'][-2:] == ['/fixture-bin/inner.py', '--inside'] and
            keeper['command'][:6] == ['/usr/bin/xvfb-run', '-f', '/q/phase6.xauthority', '-a', '-s', '-screen 0 1280x900x24 -noreset'] and
            keeper['command'][-len(ss['command']):] == ss['command'], 'Original private X11/inner command differs')
    probe = report['paste_prerequisite']
    require(probe['tool'] == config['inputs']['paste_tool'] and probe['proof'] == config['inputs']['paste_tool_proof'] and
            probe['executable_run'] is True and probe['command'] == ['/fixture-bin/xdotool', 'version'] and
            probe['started_ns'] <= probe['finished_ns'] and probe['private_namespaces'] == report['private_namespaces'], 'Original pre-Desktop paste dependency proof differs')
    for stream in ('stdout', 'stderr'):
        original = record(raw / ('functional/paste-tool-version.' + stream + '.log'))
        require(probe[stream] == {k: original[k] for k in ('bytes', 'sha256')} and original['bytes'] <= 4096, 'Original paste version stream differs')
    require(b'3.20160805.1' in body(raw / 'functional/paste-tool-version.stdout.log', 4096), 'Original paste dependency version absent')


def check_host(windows, linux, name, cleanup, keeper_ref, ss_ref):
    for stage, item in windows.items():
        require(set(item) == {'schema_version', 'kind', 'source_revision', 'arm', 'stage', 'collection_status', 'known_compiler_names', 'compiler_processes', 'native_names', 'host_idle', 'observation_performed', 'quiet_window_certified'}, 'Windows null schema differs')
        require(type(item['schema_version']) is int and item['schema_version'] == 1 and item['kind'] == 'phase6_windows_host_unverified' and item['source_revision'] == SOURCE and item['arm'] == name and item['stage'] == stage and item['collection_status'] == 'unverified_no_local_WinAPI', 'Windows context differs')
        require(item['observation_performed'] is False and item['quiet_window_certified'] is False and all(item[k] is None for k in ('known_compiler_names', 'compiler_processes', 'native_names', 'host_idle')), 'Windows unobserved must remain null')
    require(set(windows) == {'preflight', 'postflight'}, 'Both Windows unverified metadata required')
    require(set(linux) == {'schema_version', 'kind', 'source_revision', 'arm', 'host_observation', 'private_cleanup_binding'} and type(linux['schema_version']) is int and linux['schema_version'] == 1 and linux['kind'] == 'phase6_linux_postflight_scoped_observation' and linux['source_revision'] == SOURCE and linux['arm'] == name, 'Linux postflight schema/context differs')
    host = linux['host_observation']
    require(set(host) == {'collection_status', 'compiler_processes', 'known_product_processes', 'observed_display_services', 'host_idle'} and host['collection_status'] == 'observed_linux_proc_names_only' and host['compiler_processes'] == [] and host['known_product_processes'] == [] and host['host_idle'] is None, 'Linux scoped host observation differs')
    display = host['observed_display_services']
    require(type(display) is list and len(display) <= 64, 'Display record bound')
    seen = set()
    for item in display:
        require(set(item) == {'pid', 'name', 'source_status', 'operated'} and type(item['pid']) is int and 0 < item['pid'] < 2**31 and item['name'] in ('Xvfb', 'marco') and item['source_status'] == 'unverified' and item['operated'] is False and (item['pid'], item['name']) not in seen, 'Display attribution differs')
        seen.add((item['pid'], item['name']))
    equal(linux['private_cleanup_binding'], {'cleanup': cleanup, 'keeper': keeper_ref, 'secret_service': ss_ref})


def check_qualification_states(item, wire, renderer, first):
    expected_session = None if item['tag'] == 'first-hotkey' else first['session_id']
    count = 2 if renderer == 'tauri' else 1
    require(len(wire) == count * len(item['observations']), 'Original status/wire correlation count differs')
    for index, observed in enumerate(item['observations']):
        state = observed['status']
        require(type(state) is dict and set(state) == {'renderer', 'managed_pid', 'session_id', 'visible', 'last_error'} and
                state['renderer'] == renderer and type(state['visible']) is bool and state['last_error'] is None, 'Original status shape or activation error differs')
        command = wire[index * count]
        require(command['command'] == 'get_quick_paste_surface_status' and command['reply'] == state, 'Original status reply does not match its observation')
        if renderer == 'mygo':
            pid, session = state['managed_pid'], state['session_id']
            require(pid is None or type(pid) is int and pid == first['pid'], 'Managed PID changed')
            require(pid is not None or session is None, 'Unowned helper session')
            if pid is not None:
                require(type(session) is str and re.fullmatch('[0-9a-f]{32}', session), 'Original MyGo session malformed')
                if expected_session is None:
                    expected_session = session
            require(expected_session is None or session == expected_session, 'Original MyGo session changed')
            require(not state['visible'] or pid == first['pid'], 'Visible helper has no original managed PID')
            accepted = state['visible'] and pid == first['pid'] and expected_session is not None
        else:
            visible = wire[index * count + 1]
            require(state['managed_pid'] is None and state['session_id'] is None and visible['command'] == 'is_quick_paste_visible' and
                    type(visible['reply']) is bool and visible['reply'] is observed['tauri_visible'], 'Original Tauri visibility response differs')
            accepted = visible['reply']
        require(accepted is (index == len(item['observations']) - 1), 'Qualification did not stop at its original first accepted status')
    require(item['final_status'] == item['observations'][-1]['status'] and
            (renderer == 'tauri' or expected_session == first['session_id']), 'Final status/session differs from original replies')


def check_native(report, native, replies, config, resource_rows):
    main, first, renderer = report['original_main'], report['first_hotkey'], config['renderer']
    require((first['pid'] == main['pid']) == (renderer == 'tauri') and all(type(main[k]) is int and main[k] > 0 for k in ('pid', 'started', 'xid')), 'Main/panel identity differs')
    require((renderer == 'tauri' and first['session_id'] is None) or (renderer == 'mygo' and type(first['session_id']) is str and first['session_id']), 'Original renderer session differs')
    require(len(report['warmup']) == 5 and len(report['samples']) == 30, 'Warm/formal counts differ')
    require(all(v['x_errors'] == 0 for v in native), 'Native X error retained')
    native_index = {v['monotonic_ns']: v for v in native}
    require(len(native_index) == len(native), 'Duplicate native timestamps')
    context = report['first_hotkey_context']
    require(context['application_already_started'] is True and context['not_application_cold_start'] is True, 'Activation is not application cold start')
    for show in [first, *report['warmup'], *report['samples']]:
        require(all(show[k] == first[k] for k in ('pid', 'started', 'xid', 'session_id')), 'Original warm process/window/session changed')
        require(show['input']['keys'] == ['Control_L', 'Alt_L', 'Shift_L', 'F10'] and show['native']['active'] == first['xid'] and first['xid'] in show['native']['focus_chain'], 'Real hotkey/native focus differs')
        require(all(type(v) is int for v in (show['input']['input_start_ns'], show['input']['input_synced_ns'], show['native']['monotonic_ns'], show['native_observed_ns'])) and
                0 < show['input']['input_start_ns'] <= show['input']['input_synced_ns'] <= show['native']['monotonic_ns'] <= show['native_observed_ns'], 'Native activation input/observation causality differs')
        original_native = native_index[show['native']['monotonic_ns']]
        require({k: v for k, v in original_native.items() if k != 'tag'} == show['native'] and show['native']['monotonic_ns'] <= show['native_observed_ns'], 'Timed show must bind original raw native observation')
        equal(show['activation_proxy_ms'], (show['native_observed_ns'] - show['input']['input_start_ns']) / 1000000.0)
    equal(report['warm_activation_proxy_ms'], summary([v['activation_proxy_ms'] for v in report['samples']]))
    require(report['retained_ids'] == list(range(1, 11)) and report['capture_owner']['mode'] == 'embedded' and report['capture_owner']['capture_owner'] is True, 'History/capture owner differs')
    require(report['actual_paste']['text'] == config['dataset'][7] and report['actual_paste']['pending'] is False, 'Exact complete row7 paste missing')
    target = report['actual_paste']['windows']['target']
    qualifications = report['show_qualifications']
    tags = ['first-hotkey', *[f'warmup-{i}' for i in range(1, 6)], *[f'samples-{i}' for i in range(1, 31)], 'exact-paste-verification', 'resource-visible']
    require([v['tag'] for v in qualifications] == tags, 'Exact 38 qualification order differs')
    counts = collections.Counter(v['tag'] for v in replies)
    by_tag = {v['tag']: v for v in qualifications}
    timed = dict(zip(tags[:36], [first, *report['warmup'], *report['samples']]))
    for item in qualifications:
        endpoint = item['original_endpoint']
        require(item['qualified'] is True and item['native_proxy_endpoint_unchanged'] is True and all(endpoint[k] == first[k] for k in ('pid', 'started', 'xid')), 'Qualification original endpoint differs')
        require(item['native_proxy_endpoint_ns'] == endpoint['native_observed_ns'] <= item['qualification_completed_ns'] and item['qualification_completed_ns'] / 1e9 < item['original_deadline_monotonic'], 'Qualification deadline differs')
        require(item['reply_records'] == counts[item['tag']] == item['status_reads'] * (2 if renderer == 'tauri' else 1) and item['status_reads'] == len(item['observations']) >= 1, 'Qualification reply counts differ')
        if item['tag'] in timed:
            require(timed[item['tag']]['native_observed_ns'] == endpoint['native_observed_ns'], 'Timed native endpoint moved')
        final = item['final_status']
        require((renderer == 'mygo' and final['managed_pid'] == first['pid'] and final['session_id'] == first['session_id'] and final['visible'] is True) or (renderer == 'tauri' and final['renderer'] == 'tauri' and final['managed_pid'] is None and final['session_id'] is None), 'Qualified renderer status differs')
        for observation in item['observations']:
            if renderer == 'tauri':
                require(observation['tauri_visible'] is True and observation['status'] == final, 'Tauri visibility qualification differs')
            for side in ('before', 'after'):
                current = native_index[observation[side + '_native_ns']]
                require(current['active'] == first['xid'] and first['xid'] in current['focus_chain'], 'Qualification focus changed')
                windows = [v for v in current['windows'] if v['xid'] == first['xid']]
                require(len(windows) == 1 and windows[0]['pids'] == [first['pid']] and windows[0]['viewable'] is True, 'Qualification window changed')
                for role, original in (('main', main), ('panel', first)):
                    require(all(observation[side + '_identities'][role][k] == original[k] for k in ('pid', 'started')), 'Qualification process generation changed')
        check_qualification_states(item, [r for r in replies if r['tag'] == item['tag']], renderer, first)
    for reply in replies:
        item = by_tag[reply['tag']]
        require('error' not in reply and reply['http_status'] == 200 and reply['original_endpoint'] == item['original_endpoint'], 'Original qualification reply failed')
        require(item['native_proxy_endpoint_ns'] <= reply['request_started_ns'] <= reply['response_finished_ns'] <= item['qualification_completed_ns'] and reply['response_finished_ns'] / 1e9 < item['original_deadline_monotonic'], 'Reply outside original deadline')
        require(0 < reply['remaining_budget_ms'] <= 5000 and 0 <= reply['wire_bytes'] <= 65536 and abs(item['original_deadline_monotonic'] - (reply['request_started_ns'] / 1e9 + reply['remaining_budget_ms'] / 1000)) < .02, 'Reply quota/budget differs')
        require(reply['actual_response']['value']['ok'] is True and reply['actual_response']['value']['value'] == reply['reply'], 'Original wire response differs')
        require(reply['command'] in ('get_quick_paste_surface_status', 'is_quick_paste_visible'), 'Unexpected qualification command')
        if reply['command'] == 'is_quick_paste_visible':
            require(renderer == 'tauri' and reply['reply'] is True, 'Tauri visibility reply differs')
        elif renderer == 'tauri':
            require(reply['reply'] == item['final_status'], 'Tauri status reply differs')
    require(len(replies) == sum(v['reply_records'] for v in qualifications), 'Unqualified extra replies')
    for state, visible in (('visible', True), ('hidden', False)):
        samples = resource_rows[state]
        observations = [v for v in native if v['tag'] == 'resource-' + state and
                        samples[0]['monotonic_ns'] <= v['monotonic_ns'] <= samples[-1]['cpu_counter_read_window_ns'][1]]
        require(len(observations) == len(samples) == 960, 'Resource native/row count differs')
        for sample, observed in zip(samples, observations):
            require(sample['monotonic_ns'] <= observed['monotonic_ns'] <= sample['cpu_counter_read_window_ns'][0], 'Native observation outside capture')
            for original, shown in ((main, False), (first, visible)):
                windows = [w for w in observed['windows'] if w['xid'] == original['xid']]
                require(len(windows) == 1 and windows[0]['pids'] == [original['pid']] and windows[0]['viewable'] is shown, 'Resource original window state differs')
            window = next(w for w in observed['windows'] if w['xid'] == first['xid'])
            require(window['rect']['width'] == 480 and window['rect']['height'] == 360, 'Original panel geometry differs')
            focused = first['xid'] if visible else target
            require(observed['active'] == focused and focused in observed['focus_chain'], 'Resource foreground differs')


def source_snapshot(manifest, config):
    result = {}
    policy = read(INTEGRATION / 'source-plan.json')
    groups = {'method': (policy['method_pins'], COHORT), 'foundation': (policy['foundation_pins'], FOUNDATION), 'native': (policy['native_pins'], NATIVE)}
    require(set(manifest['sources']) == {'method', 'foundation', 'native', 'integration'}, 'Four source inventories required')
    for group, (pins, base) in groups.items():
        require(set(manifest['sources'][group]) == set(pins), 'Source role inventory differs')
        for name, pin in pins.items():
            ref = verify(manifest['sources'][group][name], base / name)
            require({k: ref[k] for k in ('bytes', 'sha256')} == pin, 'Pinned source differs')
            result[group + '/' + name] = ref
    require(set(manifest['sources']['integration']) == set(INTEGRATION_PINS), 'Six integration sources required')
    for name, (size, digest) in INTEGRATION_PINS.items():
        ref = verify(manifest['sources']['integration'][name], INTEGRATION / name)
        require((ref['bytes'], ref['sha256']) == (size, digest), 'Reviewed integration source changed')
        result['integration/' + name] = ref
    for name, native_name in [('assess_descriptive.py', 'assess_descriptive.py'), ('test_process_only.py', 'test_process_only.py'), ('process-only-method.plan.json', 'source-plan.json')]:
        ref = record(COHORT / name)
        require({k: ref[k] for k in ('bytes', 'sha256')} == policy['native_pins'][native_name], 'Packet method copy differs')
        result['copy/' + name] = ref
    for key in ('policy', 'plan', 'preparation'):
        result[key] = verify(manifest[key])
    result['baseline_prerequisite_policy'] = record(HARNESS / 'phase6-linux-count-prepare-1fe685c-20261102/source-plan.json')
    for key in ('pending', 'prerequisites'):
        for name, ref in manifest[key].items():
            result[key + '/' + name] = verify(ref)
    require(len(config['inputs']) == 11, 'Eleven actual input records required')
    for name, ref in config['inputs'].items():
        result['input/' + name] = verify(ref)
    return result


def check_prerequisites(manifest, config):
    baseline_path = HARNESS / 'phase6-linux-count-prepare-1fe685c-20261102/source-plan.json'
    require(record(baseline_path)['sha256'] == 'cc3922225451d5c1ae742e10ce8b364890b78104a2a3266eb487bc7ff0915c82', 'Original prerequisite policy differs')
    baseline = read(baseline_path)
    require(config['expected'] == baseline['expected'] and set(manifest['prerequisites']) == set(PREREQUISITE_PINS), 'Original expected identity/prerequisite roles differ')
    four = {k: config['inputs'][k] for k in ('desktop', 'helper', 'desktop_proof', 'helper_proof')}
    for name, pin in PREREQUISITE_PINS.items():
        ref = verify(manifest['prerequisites'][name])
        require((ref['bytes'], ref['sha256']) == pin, 'Completed original prerequisite bytes differ')
        value = read(ref['path'])
        if name == 'input_provenance':
            require(value['expected'] == config['expected'] and value['inputs'] == four, 'Original supplier pair differs')
            continue
        stages = 13 if name.startswith('idle_') else 19
        require(value['source_revision'] == SOURCE and value['status'] == 'passed' and type(value['actual_stages']) is int and value['actual_stages'] == stages, 'Original actual prerequisite context differs')
        key = ('runtime_input_pair' if name == 'idle_R3_assessment' else
               'input_pair_and_dependencies' if name == 'original19_assessment' else 'original_inputs')
        require({k: value[key][k] for k in four} == four, 'Original prerequisite product/proof binding differs')
        if stages == 19:
            require(value['phase_names'] == baseline['actual19_phase_names'], 'Original actual19 order differs')
        else:
            role = 'root' if name.endswith('_assessment') else 'peer'
            kind = ('phase6-linux-F2-focused-idle-R3-completed-assessment' if role == 'root' else
                    'phase6-linux-F2-focused-idle-R3-independent-review')
            require(manifest['r3_schemas'][role] == {'kind': kind, 'inputs_key': key} and value['kind'] == kind, 'Actual R3 schema differs')
            phases = [v['name'] for v in value['phases']] if role == 'root' else value['phase_names']
            require(phases == R3_PHASES, 'Original actual13 order differs')


def check_png(name, report, config, raw):
    setup = report['resource_query_setup']
    require(setup['query'] == 'dzcp6needle7' and setup['expected_content'] == config['dataset'][7] and setup['stored_rows'] == 10 and setup['expected_matching_rows'] == 1 and setup['setup_wait_seconds'] == .7, 'Resource query setup differs')
    source = record(raw / 'functional/resource-visible-query.png')
    copy = record(COHORT / (name + '.setup.png'))
    proof_path = COHORT / (name + '.setup-copy-proof.json')
    proof = read(proof_path, 65536)
    require(not (set(proof) & {'postflight_linux_owned_native', 'whole_host_idle', 'quiet_window_certified'}), 'Legacy host claims forbidden')
    require(proof['source'] == source and proof['copy'] == copy and source['sha256'] == copy['sha256'] == setup['screenshot']['sha256'] and proof['sha256_verified_equal'] is True, 'Original screenshot copy differs')
    pixels = body(raw / 'functional/resource-visible-query.png', 8 * 1024 * 1024)
    require(pixels[:8] == b'\x89PNG\r\n\x1a\n' and len(pixels) >= 24 and struct.unpack('>II', pixels[16:24]) == (480, 360), 'Original PNG geometry differs')
    view_path = COHORT / (name + '.root-png.json')
    view = read(view_path, 65536)
    require(view['actual_view_completed'] is True and view['reviewer'] == 'Root' and view['status'] == 'passed' and view['arm'] == name and view['source_revision'] == SOURCE and view['png_sha256'] == source['sha256'] and view['exact_query'] == setup['query'] and view['visible_matching_rows'] == 1 and view['full_visible_content'] == config['dataset'][7], 'Actual Root view of exact original PNG required')
    return proof, record(proof_path), record(view_path)


def original_raw_records(raw):
    files = [p for p in raw.iterdir() if p.is_file() and p.name != '.native-capture-fixture']
    files += [p for p in (raw / 'functional').iterdir() if p.is_file()]
    files += [raw / 'functional/private-ss/proof.json']
    require(0 < len(files) <= 128 and len(files) == len(set(files)), 'Closed raw original inventory differs')
    return [record(p) for p in sorted(files)]


def inspect_arm(index, manifest_sha):
    require(type(index) is int and 1 <= index <= 4, 'One fixed ABBA arm required')
    arm = ARMS[index - 1]
    name, raw = arm['run_name'], RAW_BASE / arm['run_name']
    manifest_path = COHORT / 'integration-manifest.json'
    manifest_ref = record(manifest_path)
    require(type(manifest_sha) is str and re.fullmatch('[0-9a-f]{64}', manifest_sha) and manifest_ref['sha256'] == manifest_sha, 'Exact Root-selected manifest SHA required')
    manifest = read(manifest_path)
    required_manifest = {'schema_version', 'kind', 'source_revision', 'observer_method', 'thread_context_switch_collection', 'policy', 'sources', 'plan', 'preparation', 'pending', 'prerequisites', 'r3_schemas'}
    require(set(manifest) == required_manifest and type(manifest['schema_version']) is int and manifest['schema_version'] == 1 and manifest['kind'] == 'phase6_F2_process_only_integration_manifest' and manifest['source_revision'] == SOURCE, 'Exact new manifest context required')
    method(manifest)
    require(manifest['policy']['path'] == str(INTEGRATION / 'source-plan.json') and manifest['policy']['sha256'] == INTEGRATION_PINS['source-plan.json'][1], 'Locked integration policy differs')
    require(manifest['plan']['path'] == str(COHORT / 'comparison-count-v1.plan.json') and manifest['preparation']['path'] == str(COHORT / 'preparation.json'), 'New packet originals required')
    for packet_name, pin in PACKET_PINS.items():
        actual = record(COHORT / packet_name)
        require((actual['bytes'], actual['sha256']) == pin, 'Selected prepared packet bytes differ')
    plan = read(manifest['plan']['path'])
    method(plan)
    require(plan['arms'] == list(ARMS) and plan['root_go'] is False and plan['performance_eligible'] is False and plan['expected']['source_revision'] == SOURCE, 'New four-arm false-GO plan required')
    execution_ref = record(COHORT / (name + '.execution.json'))
    config = read(execution_ref['path'])
    pending = read(COHORT / (name + '.pending.json'))
    require(pending == {**plan, **arm} and pending['root_go'] is False and config == {**pending, 'root_go': True}, 'Only root_go may change')
    method(config)
    sources = source_snapshot(manifest, config)
    check_prerequisites(manifest, config)
    reader_ref, reader_plan_ref = record(Path(__file__).resolve()), record(HERE / 'source-plan.json')
    raw_before = inventory(raw)
    receipt, runtime = read(raw / 'receipt.json'), read(raw / 'runtime.json')
    report = read(raw / 'functional/performance.json')
    keeper, ss = read(raw / 'functional/keeper.json'), read(raw / 'functional/private-ss/proof.json')
    cleanup = check_cleanup(receipt, report, keeper, ss)
    check_private_proofs(report, keeper, ss, config, raw)
    require(receipt['runtime_sha256'] == record(raw / 'runtime.json')['sha256'], 'Original runtime digest differs')
    require(runtime['inputs'] == config['inputs'] and runtime['expected'] == config['expected'] and runtime['comparison'] == config['comparison'] and runtime['fixture_sources'] == config['fixture_sources'] and runtime['pure_pacer'] == config['pure_pacer'], 'Actual runtime input/source differs')
    method(runtime)
    method(report)
    require(report['source_revision'] == SOURCE and report['arm_index'] == index and report['renderer'] == arm['renderer'], 'Original completed arm identity differs')
    require(receipt['source_revision'] == SOURCE and receipt['arm_index'] == index and receipt['renderer'] == arm['renderer'], 'Original outer receipt identity differs')
    require(report['performance_eligible'] is False and all(report[k] is None for k in ('first_interactive_frame', 'search_ready_latency', 'gpu_memory', 'wakeup_count', 'ime_dpi_multimonitor')), 'Unmeasured product claims must be null')
    check_namespaces(report['private_namespaces'], keeper['private_namespaces'], runtime['host_namespaces'])
    check_credential(report['credential_boundary'])
    boundary = read(raw / 'credential-boundary.json')
    require(boundary['status'] == 'boundary_installed_and_native_probe_passed' and boundary['canonical_module_sha256'] == manifest['sources']['foundation']['canonical/credential_guard.py']['sha256'] and boundary['bpf_sha256'] == manifest['sources']['foundation']['canonical/credential-deny.bpf']['sha256'] and boundary['launcher_sha256'] == manifest['sources']['foundation']['canonical/credential_launcher.py']['sha256'], 'Original credential launcher identity differs')
    check_credential(boundary['native_probe'])
    require(receipt['command'][1:3] == ['-s', '-B'] and receipt['command'][4] == '--proof' and receipt['command'][6] == '--' and boundary['command'] == receipt['command'][7:] and boundary['pid'] == boundary['native_probe']['allowed_getpid'], 'Original launcher command/pid differs')
    for key, info in (('surface_build_info', report['surface_build_info']), ('desktop_build_info', report['desktop_build_info'])):
        names = config['expected'] if key == 'surface_build_info' else ('component_version', 'source_revision', 'source_state', 'build_id', 'target')
        require(all(info[k] == config['expected'][k] for k in names), 'Actual build identity differs')
    require(read(raw / 'functional/surface-build-info.stdout') == report['surface_build_info'] and report['surface_build_info']['mygo_version'] == 'v0.6.4' and report['surface_build_info']['mygo_source_revision'] == '6255ea40139d06e0762a7c4a32626148ba410478', 'Original MyGo build bytes differ')
    resource_rows = {}
    for state in ('visible', 'hidden'):
        resource_rows[state] = rows(raw / ('functional/resources-' + state + '.jsonl'))
        check_resource(resource_rows[state], rows(raw / ('functional/resource-clock-' + state + '.jsonl')), report['resource_sampling_progress'][state], report['resources'][state], report['original_main'], report['first_hotkey'])
    check_native(report, rows(raw / 'functional/native-observations.jsonl'), rows(raw / 'functional/show-status-qualification.jsonl'), config, resource_rows)
    target = rows(raw / 'functional/target.stdout.jsonl')
    require(target[0]['ready'] is True and type(target[0]['pid']) is int and target[0]['pid'] > 0 and target[0]['windows'] == report['actual_paste']['windows'], 'Original target identity differs')
    replies = target[1:]
    require([r['id'] for r in replies] == list(range(1, len(replies) + 1)) and all(r['windows'] == target[0]['windows'] for r in replies) and report['actual_paste'] in replies and all(r['text'] in ('', config['dataset'][7]) for r in replies), 'Original target correlation/full paste differs')
    require(all(a['monotonic_ns'] <= b['monotonic_ns'] for a, b in zip(replies, replies[1:])), 'Target reply clock regressed')
    require(read(raw / 'host-preflight.json')['compiler_processes'] == [] and all(v['compiler_processes'] == [] for v in rows(raw / 'host-load.jsonl')), 'Known compiler contamination retained')
    proof, proof_ref, png_ref = check_png(name, report, config, raw)
    windows_refs = {stage: record(COHORT / (name + '.' + stage + '-windows.json')) for stage in ('preflight', 'postflight')}
    windows = {stage: read(ref['path'], 65536) for stage, ref in windows_refs.items()}
    check_host(windows, proof['postflight_linux_scope'], name, cleanup, record(raw / 'functional/keeper.json'), record(raw / 'functional/private-ss/proof.json'))
    assessment_ref = record(COHORT / (name + '.assessment.json'))
    assessment = read(assessment_ref['path'])
    method(assessment)
    scope(assessment)
    require(assessment['kind'] == 'phase6_count_paced_process_only_arm_assessment' and assessment['status'] == 'passed_limited_process_only_consistency' and assessment['source_revision'] == SOURCE and assessment['arm'] == arm, 'Separate Root limited assessment identity differs')
    originals = original_raw_records(raw)
    require(assessment['raw_evidence'] == originals and assessment['execution'] == execution_ref and assessment['root_png_evidence'] == png_ref and assessment['setup_copy_proof'] == proof_ref and assessment['assessor'] == record(COHORT / 'assess_descriptive.py'), 'Root original-byte binding differs')
    equal(assessment['verified_resources'], report['resources'])
    equal(assessment['warm_activation_proxy_ms'], report['warm_activation_proxy_ms'])
    require(assessment['qualification_count'] == 38 and assessment['actual_reply_count'] == len(rows(raw / 'functional/show-status-qualification.jsonl')) and assessment['cleanup'] == cleanup, 'Root summary differs from independent raw calculations')
    require(sources == source_snapshot(manifest, config) and manifest_ref == record(manifest_path) and raw_before == inventory(raw), 'Original source/input/raw bytes drifted')
    for ref in [execution_ref, assessment_ref, proof_ref, png_ref, reader_ref, reader_plan_ref, *windows_refs.values()]:
        verify(ref)
    review = {'kind': 'phase6_F2_process_only_independent_raw_review',
              'status': 'passed_limited_independent_process_only_raw_consistency',
              'source_revision': SOURCE, 'observer_method': METHOD, 'thread_context_switch_collection': COLLECTION,
              'arm': name, 'renderer': arm['renderer'], 'arm_index': index,
              'reviewer_role': 'independent_raw_reviewer', 'independent_from_authorizer_and_assessor_author': True,
              'actual_original_raw_review_completed': True, 'whole_ABBA_complete': False,
              'checks': {k: True for k in sorted(CHECKS)}, 'root_assessment': assessment_ref,
              'root_png_evidence': png_ref, 'setup_copy_proof': proof_ref,
              'assessor': record(COHORT / 'assess_descriptive.py'), 'integration_manifest': manifest_ref,
              'reviewer_reader': reader_ref, 'execution': execution_ref,
              'raw_evidence': originals, 'whole_host_idle': None, 'quiet_window': None,
              'performance_acceptance': None, 'performance_eligible': False, 'phase6_passed': False,
              'phase7_authorized': False, 'next_arm_authorized': False}
    require(set(review) == FIELDS, 'Closed v2 independent review schema differs')
    return review


def publish(path, value):
    pending = path.with_suffix('.pending.json')
    require(not path.exists() and not pending.exists(), 'Independent review output is exclusive')
    data = (json.dumps(value, sort_keys=True, indent=2, allow_nan=False) + '\n').encode('utf-8')
    with pending.open('xb') as stream:
        require(stream.write(data) == len(data), 'Short independent review write')
        stream.flush()
        os.fsync(stream.fileno())
    require(body(pending) == data, 'Independent review readback differs')
    os.link(pending, path)


def review_once(index, manifest_sha):
    require(sys.platform == 'linux', 'File-only reader requires original Linux path semantics')
    require(type(index) is int and 1 <= index <= 4, 'One fixed ABBA arm required')
    name = ARMS[index - 1]['run_name']
    output = COHORT / (name + '.independent-raw-review.json')
    failure_path = COHORT / (name + '.independent-raw-failure.json')
    require(all(not p.exists() for p in (output, output.with_suffix('.pending.json'), failure_path, failure_path.with_suffix('.pending.json'))), 'Existing review or failure cannot be reused')
    try:
        result = inspect_arm(index, manifest_sha)
        publish(output, result)
    except BaseException as error:
        failure = {'kind': 'phase6_F2_process_only_independent_raw_failure', 'status': 'failed',
                   'source_revision': SOURCE, 'observer_method': METHOD, 'arm': name,
                   'first_error': {'type': type(error).__name__, 'message': str(error)[:2048]},
                   'performance_eligible': False, 'phase6_passed': False, 'phase7_authorized': False,
                   'next_arm_authorized': False, 'actual_native_executed_by_reader': False}
        try:
            publish(failure_path, failure)
        except BaseException:
            pass
        raise


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--arm-index', type=int, choices=range(1, 5), required=True)
    parser.add_argument('--manifest-sha256', required=True)
    args = parser.parse_args()
    review_once(args.arm_index, args.manifest_sha256)


if __name__ == '__main__':
    main()

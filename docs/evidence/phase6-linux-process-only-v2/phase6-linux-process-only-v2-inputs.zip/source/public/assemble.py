"""Package an independently reviewed explicit file list; never discover or execute evidence."""
import argparse
import hashlib
import os
from pathlib import Path
import stat
import sys
import zipfile

import verify as portable

HERE = Path(__file__).resolve().parent
portable.require(Path(portable.__file__).resolve() == HERE / 'verify.py', 'Wrong local portable verifier module')
PUBLIC = {'assemble.py', 'verify.py', 'test_bundle.py', 'source-plan.json'}


def identity(value):
    return (value.st_dev, value.st_ino, value.st_mode, value.st_size, value.st_mtime_ns, value.st_ctime_ns)


def checked_path(path):
    path = Path(path)
    portable.require(path.is_absolute() and '..' not in path.parts, 'Explicit absolute source path required')
    for parent in (path, *path.parents):
        value = parent.lstat()
        portable.require(not stat.S_ISLNK(value.st_mode) and not (getattr(value, 'st_file_attributes', 0) & 0x400),
                         'Symlink or reparse source is excluded')
    portable.require(stat.S_ISREG(path.lstat().st_mode), 'Only regular files may be included')
    return path


def read_file(path, limit=portable.MAX_MEMBER):
    path = checked_path(path)
    before = path.stat()
    portable.require(before.st_size <= limit, 'Source file exceeds its bound')
    with path.open('rb') as handle:
        portable.require(identity(os.fstat(handle.fileno())) == identity(before), 'Source changed before open')
        data = handle.read(limit + 1)
        portable.require(identity(os.fstat(handle.fileno())) == identity(before), 'Source changed during read')
    portable.require(identity(path.stat()) == identity(before) and len(data) == before.st_size, 'Source read drift')
    return data


def read_header(path, record):
    path = checked_path(path)
    before = path.stat()
    portable.require(type(record) is dict and set(record) == {'path', 'bytes', 'sha256'} and
        type(record['bytes']) is int and record['bytes'] >= 64 and before.st_size == record['bytes'] and
        type(record['sha256']) is str and portable.re.fullmatch('[0-9a-f]{64}', record['sha256']), 'Invalid omitted historical identity')
    portable.original_name(record['path'])
    with path.open('rb') as handle:
        portable.require(identity(os.fstat(handle.fileno())) == identity(before), 'Omitted source changed before open')
        header = handle.read(64)
        portable.require(identity(os.fstat(handle.fileno())) == identity(before), 'Omitted header read drift')
    portable.require(identity(path.stat()) == identity(before), 'Omitted source changed after header read')
    return portable.elf_header(header)


def descriptor(value):
    portable.require(type(value) is dict and set(value) == {'source_path', 'original_paths', 'archive_path', 'role', 'bytes', 'sha256'},
                     'Exact allowlist file schema required')
    item = {k: v for k, v in value.items() if k != 'source_path'}
    portable.require(type(item['original_paths']) is list and 1 <= len(item['original_paths']) <= 8 and
        portable.safe_name(item['archive_path']) and item['archive_path'] != 'manifest.json' and
        item['role'] in ('raw', 'cohort', 'source', 'proof') and type(item['bytes']) is int and
        0 <= item['bytes'] <= portable.MAX_MEMBER and type(item['sha256']) is str and
        portable.re.fullmatch('[0-9a-f]{64}', item['sha256']), 'Malformed explicit allowlist record')
    for alias in item['original_paths']:
        portable.original_name(alias)
    lower = item['archive_path'].casefold()
    portable.require(not any(part in ('profile', 'profiles', 'userdata', 'databases', 'secrets', 'storage', 'sockets')
                            for part in lower.split('/')) and
        not lower.endswith(('.db', '.sqlite', '.sqlite3', '.sock', '.exe', '.dll', '.pdb')),
        'Private state and compiled payload paths are excluded')
    if 'private-ss/' in lower:
        portable.require(item['role'] == 'raw' and lower.endswith('/functional/private-ss/proof.json'),
                         'Only the explicit private Secret Service proof may be copied')
    return item


def input_snapshot(plan):
    portable.require(type(plan) is dict and set(plan) == {'schema_version', 'kind', 'source_revision', 'observer_method',
        'thread_context_switch_collection', 'manifest', 'files', 'omitted_inputs'} and
        type(plan['schema_version']) is int and plan['schema_version'] == 1 and
        plan['kind'] == 'phase6_process_only_v2_public_bundle_allowlist' and plan['source_revision'] == portable.SOURCE,
        'Exact Root allowlist/source schema required')
    portable.method(plan)
    portable.require(type(plan['files']) is list and 194 <= len(plan['files']) <= 319 and
                     type(plan['omitted_inputs']) is list and len(plan['omitted_inputs']) == 7, 'Closed evidence inventory required')
    files, omitted, snapshots, names, aliases = [], [], {}, set(), set()
    for value in plan['files']:
        item = descriptor(value)
        portable.require(item['archive_path'].casefold() not in names and not (aliases & set(item['original_paths'])) and
                         len(set(item['original_paths'])) == len(item['original_paths']), 'Duplicate file name or alias')
        names.add(item['archive_path'].casefold()); aliases.update(item['original_paths'])
        data = read_file(value['source_path'])
        portable.require(len(data) == item['bytes'] and hashlib.sha256(data).hexdigest() == item['sha256'], 'Included original bytes/SHA mismatch')
        portable.require(data[:4] != b'\x7fELF' and data[:2] != b'MZ' and not data.startswith(b'SQLite format 3\x00'),
                         'ELF/PE/database bytes cannot be included')
        files.append(item); snapshots[item['archive_path']] = data
    portable.require(sum(v['bytes'] for v in files) <= portable.MAX_TOTAL - 2 * 1024 * 1024, 'Bundle exceeds total bound')
    portable.require({v['archive_path'] for v in files if v['role'] == 'raw'} ==
        {'raw/' + a['run_name'] + '/' + n for a in portable.ARMS for n in portable.RAW_NAMES}, 'Exactly four closed34 raw sets required')
    controls = {v['archive_path'].removeprefix('cohort/'): {k: v[k] for k in ('bytes', 'sha256')}
                for v in files if v['role'] == 'cohort' and v['archive_path'].startswith('cohort/')}
    portable.require(set(controls) == portable.COHORT_NAMES and sum(v['role'] == 'cohort' for v in files) == 58 and
        hashlib.sha256(portable.canonical(controls)).hexdigest() == portable.COHORT_CONTROL_SHA, 'Frozen58 cohort original identities differ')
    portable.require({v['name'] for v in plan['omitted_inputs']} == portable.OMITTED, 'Exactly seven distinct omitted roles required')
    for value in plan['omitted_inputs']:
        portable.require(type(value) is dict and set(value) == {'name', 'record', 'source_path'} and
                         value['record']['path'] not in aliases, 'Invalid omitted input record')
        omitted.append({'name': value['name'], 'record': value['record'], 'elf_identity': read_header(value['source_path'], value['record'])})
    manifest = dict(plan['manifest'])
    portable.require('files' not in manifest and 'omitted_elf_inputs' not in manifest, 'Generated inventory cannot be supplied twice')
    manifest.update(files=files, omitted_elf_inputs=omitted)
    portable.require(set(manifest['public_sources']) == PUBLIC, 'All four public source files must be included')
    for name, reference in manifest['public_sources'].items():
        chosen = [v for v in files if reference['path'] in v['original_paths']]
        portable.require(len(chosen) == 1 and chosen[0]['role'] == 'source' and
            snapshots[chosen[0]['archive_path']] == read_file(HERE / name), 'Public source must match these reviewed local bytes')
    return manifest, snapshots


def write_candidate(path, manifest, snapshots):
    with path.open('xb') as handle:
        with zipfile.ZipFile(handle, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=6, allowZip64=False) as archive:
            entries = {'manifest.json': portable.canonical(manifest), **snapshots}
            for name, data in sorted(entries.items()):
                info = zipfile.ZipInfo(name, (2026, 11, 2, 0, 0, 0))
                info.create_system = 3
                info.external_attr = (stat.S_IFREG | 0o644) << 16
                info.compress_type = zipfile.ZIP_DEFLATED
                archive.writestr(info, data)
        handle.flush(); os.fsync(handle.fileno())


def assemble(plan_path, expected_sha, output):
    """Root separately authorizes this once; a partial candidate must never be retried in place."""
    portable.require(type(expected_sha) is str and portable.re.fullmatch('[0-9a-f]{64}', expected_sha), 'Exact independently selected plan SHA required')
    plan_path, output = Path(plan_path), Path(output)
    portable.require(output.is_absolute() and output.suffix == '.zip' and output.parent.is_dir(), 'Explicit existing output parent and ZIP name required')
    candidate = output.with_suffix('.pending.zip')
    portable.require(not os.path.lexists(output) and not os.path.lexists(candidate), 'Existing final or partial ZIP is never replaced')
    plan_data = read_file(plan_path, 2 * 1024 * 1024)
    portable.require(hashlib.sha256(plan_data).hexdigest() == expected_sha, 'Root-selected allowlist SHA differs')
    plan = portable.parse(plan_data)
    manifest, snapshots = input_snapshot(plan)
    write_candidate(candidate, manifest, snapshots)
    portable.verify(candidate)
    after, reread = input_snapshot(plan)
    portable.equal(after, manifest, 'Assembly input headers/metadata after portable check')
    portable.require(reread == snapshots and read_file(plan_path, 2 * 1024 * 1024) == plan_data, 'Assembly original or plan drift')
    candidate_data = read_file(candidate, portable.MAX_TOTAL)
    result = {'path': str(output), 'bytes': len(candidate_data), 'sha256': hashlib.sha256(candidate_data).hexdigest(),
              'status': 'included_originals_offline_verified', 'performance_eligible': False, 'phase6_passed': False,
              'phase7_authorized': False, 'omitted_full_hashes_rechecked': False}
    os.link(candidate, output)
    return result


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', required=True)
    parser.add_argument('--plan-sha256', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    assemble(args.plan, args.plan_sha256, args.output)

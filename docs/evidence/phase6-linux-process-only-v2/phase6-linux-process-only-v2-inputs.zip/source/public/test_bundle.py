"""Synthetic ZIP/files and reviewed pure vectors only; never assemble the actual cohort."""
import ast
import copy
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import struct
import tempfile
import unittest
from unittest import mock
import zipfile

import verify as reader
import assemble as assembler

HERE = Path(__file__).resolve().parent
REFERENCE = HERE.parent / 'phase6-linux-process-only-v2-independent-reader-20261102'
REFERENCE_TEST_SHA = 'c05bc4020e0e1c7d4b392409b86e59b4e1a1714b785f884063b57730c1f7aa2c'


def install_reviewed_pure_vectors():
    """Load only two builders and explicitly selected pure test methods, never any reader entry point."""
    data = (REFERENCE / 'test_review_arm.py').read_bytes()
    reader.require(hashlib.sha256(data).hexdigest() == REFERENCE_TEST_SHA, 'Reviewed synthetic vector source changed')
    tree = ast.parse(data)
    selected = []
    native_names = {'test_both_renderer_original_raw_qualifications_and_resources',
        'test_hidden_focus_wrong_window_and_raw_show_mismatch_are_fatal',
        'test_negative_proxy_or_inverted_input_sync_cannot_be_hidden_by_summary',
        'test_first_helper_unaccepted_status_is_replayed_without_fabricating_ready',
        'test_reply_empty_error_deadline_wire_and_endpoint_tamper_are_fatal',
        'test_38exact_tags_counts_and_all_native_rows_required',
        'test_six_namespace_and_credential_exact_denials',
        'test_original_failed_status_or_cleanup_never_becomes_pass',
        'test_host_nulls_private_cleanup_binding_and_display_limits'}
    for node in tree.body:
        if isinstance(node, ast.FunctionDef) and node.name in ('resource_fixture', 'native_fixture'):
            selected.append(node)
        if isinstance(node, ast.ClassDef) and node.name == 'ResourceContracts':
            selected.append(node)
        if isinstance(node, ast.ClassDef) and node.name == 'NativeContracts':
            node.body = [n for n in node.body if isinstance(n, ast.FunctionDef) and n.name in native_names]
            reader.require(len(node.body) == 9, 'Closed pure native vector set changed')
            selected.append(node)
    reader.require(len(selected) == 4, 'Closed pure resource vector set changed')
    exec(compile(ast.Module(body=selected, type_ignores=[]), '<reviewed-synthetic-vectors>', 'exec'), globals())


install_reviewed_pure_vectors()


def ref(path='/original/label', data=b'x'):
    return {'path': path, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def base_manifest():
    return {'schema_version': 1, 'kind': 'phase6_linux_process_only_v2_public_analysis_inputs',
        'source_revision': reader.SOURCE, 'observer_method': reader.METHOD,
        'thread_context_switch_collection': reader.COLLECTION,
        **{k: ref('/original/' + k) for k in ('summary', 'integration_manifest', 'reader', 'reader_freeze',
            'root_final_review', 'independent_summary_audit', 'independent_summary_source')},
        'public_sources': {}, 'performance_eligible': False, 'phase6_passed': False,
        'phase7_authorized': False, 'next_arm_authorized': False, 'whole_host_idle': None,
        'quiet_window': None, 'performance_acceptance': None, 'limits': ['synthetic only']}


def synthetic_files():
    files, content = [], {}
    raw = ['raw/' + arm['run_name'] + '/' + name for arm in reader.ARMS for name in reader.RAW_NAMES]
    for index, name in enumerate(raw + ['cohort/' + n for n in sorted(reader.COHORT_NAMES)]):
        data = b'synthetic ' + str(index).encode('ascii')
        files.append({'original_paths': ['/synthetic/' + name], 'archive_path': name,
                      'role': 'raw' if name.startswith('raw/') else 'cohort', **{k: v for k, v in ref(data=data).items() if k != 'path'}})
        content[name] = data
    return files, content


def control_digest(files):
    return hashlib.sha256(reader.canonical({v['archive_path'].removeprefix('cohort/'):
        {k: v[k] for k in ('bytes', 'sha256')} for v in files if v['role'] == 'cohort'})).hexdigest()


def memory_zip(manifest, contents, extra=None):
    stream = io.BytesIO()
    with zipfile.ZipFile(stream, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr('manifest.json', reader.canonical(manifest))
        for name, data in contents.items():
            archive.writestr(name, data)
        if extra:
            extra(archive)
    stream.seek(0)
    return zipfile.ZipFile(stream)


def elf_bytes():
    data = bytearray(64)
    data[:7] = b'\x7fELF\x02\x01\x01'
    struct.pack_into('<HHI', data, 16, 3, 62, 1)
    return bytes(data)


class PortableContracts(unittest.TestCase):
    def setUp(self):
        self.files, self.contents = synthetic_files()
        self.manifest = {**base_manifest(), 'files': self.files, 'omitted_elf_inputs': []}
        self.patch = mock.patch.object(reader, 'COHORT_CONTROL_SHA', control_digest(self.files))
        self.patch.start(); self.addCleanup(self.patch.stop)

    def open(self, extra=None):
        return memory_zip(self.manifest, self.contents, extra)

    def test_complete_closed_inventory_and_literal_aliases(self):
        self.files[0]['original_paths'].append('C:/literal/original.json')
        with self.open() as archive, mock.patch.object(Path, 'open', side_effect=AssertionError('host original opened')):
            store = reader.Bundle(archive)
            self.assertEqual(len(store.members), 194)
            self.assertEqual(store.data('/synthetic/' + self.files[0]['archive_path']), self.contents[self.files[0]['archive_path']])
            self.assertEqual(store.data('C:/literal/original.json'), self.contents[self.files[0]['archive_path']])

    def test_original_hash_size_and_ref_type_cannot_drift(self):
        with self.open() as archive:
            store = reader.Bundle(archive)
            for change in ({'bytes': True}, {'bytes': 0}, {'sha256': '0' * 64}, {'extra': True}):
                record = ref(self.files[0]['original_paths'][0], self.contents[self.files[0]['archive_path']]); record.update(change)
                with self.assertRaises(ValueError): store.item(record)
        self.contents[self.files[0]['archive_path']] += b'drift'
        with self.open() as archive, self.assertRaises(ValueError): reader.Bundle(archive)

    def test_missing_or_extra_raw_and_control_are_rejected(self):
        for index in (0, 136):
            files, contents = synthetic_files()
            removed = files.pop(index); contents.pop(removed['archive_path'])
            manifest = {**base_manifest(), 'files': files, 'omitted_elf_inputs': []}
            with memory_zip(manifest, contents) as archive, self.assertRaises(ValueError): reader.Bundle(archive)
        with self.open(lambda z: z.writestr('unlisted.json', b'x')) as archive, self.assertRaises(ValueError): reader.Bundle(archive)

    def test_duplicate_alias_and_case_duplicate_member_are_rejected(self):
        self.files[1]['original_paths'] = self.files[0]['original_paths'][:]
        with self.open() as archive, self.assertRaises(ValueError): reader.Bundle(archive)
        self.files[1]['original_paths'] = ['/unique']
        name = next(iter(self.contents))
        with self.open(lambda z: z.writestr(name.upper(), b'x')) as archive, self.assertRaises(ValueError): reader.Bundle(archive)

    def test_traversal_special_files_and_binary_payloads_are_rejected(self):
        for name in ('../secret', '/absolute', 'dir//file', 'dir/./file', 'dir\\file', 'dir/'):
            self.assertFalse(reader.safe_name(name), name)
        info = zipfile.ZipInfo('symlink'); info.create_system = 3; info.external_attr = (stat.S_IFLNK | 0o777) << 16
        with self.open(lambda z: z.writestr(info, b'/secret')) as archive, self.assertRaises(ValueError): reader.Bundle(archive)
        name = self.files[0]['archive_path']
        for data in (elf_bytes(), b'MZunusual', b'SQLite format 3\x00database'):
            self.contents[name] = data; self.files[0].update({k: v for k, v in ref(data=data).items() if k != 'path'})
            with self.open() as archive, self.assertRaises(ValueError): reader.Bundle(archive)

    def test_control_digest_not_replaced_by_declared_status(self):
        self.files[136]['sha256'] = hashlib.sha256(b'replaced').hexdigest(); self.files[136]['bytes'] = 8
        self.contents[self.files[136]['archive_path']] = b'replaced'
        with self.open() as archive, self.assertRaises(ValueError): reader.Bundle(archive)

    def test_windows_null_and_false_qualification_are_strict(self):
        for key in ('performance_eligible', 'phase6_passed', 'phase7_authorized', 'next_arm_authorized'):
            for wrong in (True, 0, None):
                value = base_manifest(); value[key] = wrong
                with self.assertRaises(ValueError): reader.scope(value)
        for key in ('whole_host_idle', 'quiet_window', 'performance_acceptance'):
            for wrong in (False, [], 'unverified'):
                value = base_manifest(); value[key] = wrong
                with self.assertRaises(ValueError): reader.scope(value)

    def test_JSON_duplicate_nonfinite_and_bool_number_rejected(self):
        for data in (b'{"x":1,"x":2}', b'{"x":NaN}', b'{"x":Infinity}'):
            with self.assertRaises(ValueError): reader.parse(data)
        for actual, expected in ((True, 1), (0, False), ([], None)):
            with self.assertRaises(ValueError): reader.equal(actual, expected)

    def test_omitted_headers_do_not_claim_full_binary_rehash(self):
        value = reader.elf_header(elf_bytes())
        self.assertFalse(value['full_bytes_included']); self.assertFalse(value['public_full_hash_rechecked'])
        for index in (0, 4, 5, 18):
            data = bytearray(elf_bytes()); data[index] ^= 0xff
            with self.assertRaises(ValueError): reader.elf_header(bytes(data))
        with self.assertRaises(ValueError): reader.elf_header(elf_bytes() + b'x')

    def test_core_pure_functions_match_frozen_reader_AST(self):
        data = (REFERENCE / 'review_arm.py').read_bytes()
        self.assertEqual(hashlib.sha256(data).hexdigest(), reader.READER_SHA)
        functions = lambda t: {n.name: ast.dump(n, include_attributes=False) for n in ast.parse(t).body if isinstance(n, ast.FunctionDef)}
        baseline, current = functions(data), functions((HERE / 'verify.py').read_bytes())
        for name in ('require', 'summary', 'equal', 'parse', 'method', 'scope', 'check_resource', 'check_namespaces',
                     'check_credential', 'check_cleanup', 'check_host', 'check_qualification_states', 'check_native'):
            self.assertEqual(current[name], baseline[name], name)

    def test_portable_verifier_never_imports_or_executes_archive_code(self):
        tree = ast.parse((HERE / 'verify.py').read_bytes())
        imported = {alias.name.split('.')[0] for n in ast.walk(tree) if isinstance(n, (ast.Import, ast.ImportFrom)) for alias in n.names}
        self.assertFalse(imported & {'importlib', 'subprocess', 'ctypes', 'socket', 'os', 'shutil'})
        calls = {ast.unparse(n.func) for n in ast.walk(tree) if isinstance(n, ast.Call)}
        self.assertFalse(any(n in calls for n in ('exec', 'eval', 'open', 'archive.extract', 'archive.extractall', 'Path.write_bytes', 'Path.write_text')))
        self.assertEqual({c for c in calls if c.endswith('.read_bytes')}, {'Path(__file__).read_bytes()'.removesuffix('()')})


class AssemblyContracts(unittest.TestCase):
    def test_explicit_file_read_preserves_bytes_and_rejects_directory(self):
        with tempfile.TemporaryDirectory() as temp:
            p = Path(temp) / 'original'; p.write_bytes(b'original\x00bytes')
            self.assertEqual(assembler.read_file(p), b'original\x00bytes')
            with self.assertRaises(ValueError): assembler.read_file(p, 1)
            with self.assertRaises(ValueError): assembler.read_file(Path(temp))

    def test_read_drift_is_fatal(self):
        with tempfile.TemporaryDirectory() as temp:
            p = Path(temp) / 'original'; p.write_bytes(b'x')
            original = assembler.identity; count = 0
            def drift(value):
                nonlocal count
                count += 1
                return original(value) + ((1,) if count == 3 else (0,))
            with mock.patch.object(assembler, 'identity', side_effect=drift), self.assertRaises(ValueError): assembler.read_file(p)

    def test_header_only_does_not_read_or_rehash_entire_ELF(self):
        with tempfile.TemporaryDirectory() as temp:
            p = Path(temp) / 'elf'; p.write_bytes(elf_bytes() + b'not_read' * 100)
            recorded = ref('/omitted/native', p.read_bytes()); calls = []
            original = Path.open
            class OnlyHeader:
                def __enter__(self): self.handle = original(p, 'rb'); return self
                def __exit__(self, *args): self.handle.close()
                def fileno(self): return self.handle.fileno()
                def read(self, count): calls.append(count); return self.handle.read(count)
            with mock.patch.object(Path, 'open', return_value=OnlyHeader()):
                result = assembler.read_header(p, recorded)
            self.assertEqual(calls, [64]); self.assertFalse(result['public_full_hash_rechecked'])

    def test_private_state_and_compiled_archive_names_rejected(self):
        for name in ('source/profile/preferences', 'proof/database.db', 'raw/private-ss/storage.json', 'source/native.exe'):
            item = {'source_path': '/unused', 'original_paths': ['/original'], 'archive_path': name,
                    'role': 'source', 'bytes': 1, 'sha256': '0' * 64}
            with self.assertRaises(ValueError): assembler.descriptor(item)

    def test_existing_final_or_partial_cannot_be_overwritten(self):
        with tempfile.TemporaryDirectory() as temp:
            for suffix in ('.zip', '.pending.zip'):
                out = Path(temp) / ('result' + suffix); out.write_bytes(b'old')
                with mock.patch.object(assembler, 'input_snapshot') as inspect, self.assertRaises(ValueError):
                    assembler.assemble(Path(temp) / 'absent', '0' * 64, Path(temp) / 'result.zip')
                inspect.assert_not_called(); self.assertEqual(out.read_bytes(), b'old')
                out.unlink()

    def test_final_link_failure_preserves_candidate_and_no_final(self):
        self.assembly_fake(link_error=True)

    def test_portable_failure_and_input_drift_never_publish(self):
        for failure in ('verify', 'drift'):
            self.assembly_fake(failure=failure)

    def test_publish_last_has_no_post_link_IO_or_replacement(self):
        self.assembly_fake()
        tree = ast.parse((HERE / 'assemble.py').read_bytes())
        function = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'assemble')
        self.assertEqual(ast.unparse(function.body[-2]), 'os.link(candidate, output)')
        self.assertIsInstance(function.body[-1], ast.Return)
        calls = {ast.unparse(n.func) for n in ast.walk(tree) if isinstance(n, ast.Call)}
        self.assertFalse(calls & {'os.replace', 'Path.unlink', 'shutil.copytree', 'Path.rglob', 'os.walk', 'subprocess.run'})

    def assembly_fake(self, link_error=False, failure=None):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp); out = root / 'result.zip'; plan = root / 'plan.json'; plan.write_bytes(b'{}')
            before = ({'synthetic': True}, {'raw/fake': b'original'})
            after = ({'synthetic': True}, {'raw/fake': b'changed'}) if failure == 'drift' else before
            portable_check = mock.Mock(side_effect=ValueError('offline check')) if failure == 'verify' else mock.Mock(return_value={})
            original_link = os.link
            def link(src, dst):
                if link_error: raise OSError('link denied')
                original_link(src, dst)
            with mock.patch.object(assembler, 'input_snapshot', side_effect=[before, after]), mock.patch.object(reader, 'verify', portable_check), mock.patch.object(assembler.os, 'link', side_effect=link):
                if failure or link_error:
                    with self.assertRaises((ValueError, OSError)): assembler.assemble(plan, hashlib.sha256(b'{}').hexdigest(), out)
                    self.assertFalse(out.exists()); self.assertTrue(out.with_suffix('.pending.zip').exists())
                else:
                    result = assembler.assemble(plan, hashlib.sha256(b'{}').hexdigest(), out)
                    self.assertEqual(result['sha256'], hashlib.sha256(out.read_bytes()).hexdigest())
                    self.assertEqual(out.read_bytes(), out.with_suffix('.pending.zip').read_bytes())


if __name__ == '__main__':
    unittest.main(verbosity=2)

"""File-only independent aggregation of four completed process-only arms. No fixture imports."""
import hashlib
import json
import math
import os
from pathlib import Path
import stat
import sys

HERE = Path(__file__).resolve().parent
HARNESS = HERE.parent
COHORT = HARNESS / 'phase6-linux-count-process-only-v2-1fe685c-20261102'
SOURCE = '1fe685c424602b2bc1892f1deb0794c2e0b90ad5'
RAW_BASE = Path('/home/qiyuaner/.cache/dezirclip-v02/phase6-performance-recovered') / SOURCE
METHOD, COLLECTION = 'process-resource-only-v2', 'not_collected'
SUMMARY = COHORT / 'comparison-process-only-v2.limited-descriptive.json'
SUMMARY_PIN = (92439, '3c9e9b1d8162859efc11aa5a30cede300b5bf77418559c52f5cb389367807b86')
MANIFEST_PIN = (12687, '63d0f6f062a5be89db5c534e72ca175677c3a6be6492655879acdcacebb7f30f')
FINAL_REVIEW_PIN = (6145, '1c03cb4c3654df48f329d974f03cb9da1151a98a7d36c411e859a8eb99ceaad9')
REVIEW_PINS = (
    (13564, '32185a1f7beb4652fd0643ddb320f76f6f4de653ae973ffa6f4fb034ce855725'),
    (13527, '48724c969aca2c688336a8108d3fca2e219cd6c3a46260e0f8bac86ebe1ab94e'),
    (13527, '5f19851e74bab8f0876645a8b844ba3dc7fa1248fe4178455835975472f8e94e'),
    (13564, '7201987fdc7df2a840e3fb0268493586c398277225d99ff14d7e2e1209f2119c'))
READER_PINS = {
    'review_arm.py': (52564, 'd32cf419ae5e90bde54ac673d33023aaa8cfd1fed5559c63d3992ee29d0e043e'),
    'test_review_arm.py': (38196, 'c05bc4020e0e1c7d4b392409b86e59b4e1a1714b785f884063b57730c1f7aa2c'),
    'source-plan.json': (10625, '2991fc5e399e6679c7e0377f27aa0181facd946d63a7746ae2701c41a59cf96e')}
CPU_SCOPE = 'Duration-weighted disjoint first/last counter-read intervals. Not elapsed-window/tail CPU, a common-time family bound, tick-quantization bound or statistical confidence interval.'
MAX_FILE = 128 * 1024 * 1024


def require(condition, message):
    if not condition:
        raise ValueError(message)


def raw(path, limit=MAX_FILE):
    path = Path(path)
    require(path.is_absolute() and not any(p.is_symlink() for p in (path, *path.parents)), 'Original absolute nonsymlink file required')
    before = path.stat()
    require(stat.S_ISREG(before.st_mode) and 0 <= before.st_size <= limit, 'Original file bound/type differs')
    with path.open('rb') as stream:
        value = stream.read(limit + 1)
    after = path.stat()
    require(len(value) == before.st_size <= limit and
            (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) ==
            (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns), 'Original file drift during reading')
    return value


def record(path):
    data = raw(path)
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def parse(data):
    def pairs(items):
        result = {}
        for name, value in items:
            require(name not in result, 'Duplicate JSON key')
            result[name] = value
        return result
    return json.loads(data, object_pairs_hook=pairs,
                      parse_constant=lambda v: (_ for _ in ()).throw(ValueError('Nonfinite JSON: ' + v)))


def read(path):
    return parse(raw(path, 4 * 1024 * 1024))


def rows(path):
    data = raw(path)
    require(data.endswith(b'\n'), 'Incomplete JSONL final line')
    return [parse(line) for line in data.splitlines()]


def verify(ref, expected=None):
    require(type(ref) is dict and set(ref) == {'path', 'bytes', 'sha256'}, 'Exact original file reference required')
    if expected is not None:
        require(ref['path'] == str(expected), 'Unexpected original file path')
    require(record(ref['path']) == ref, 'Original byte/hash reference changed')
    return ref


def pinned(path, pin):
    ref = record(path)
    require((ref['bytes'], ref['sha256']) == pin, 'Selected original bytes differ: ' + str(path))
    return ref


def summary(values):
    values = sorted(values)
    require(values and all(type(v) in (int, float) and math.isfinite(v) for v in values), 'Invalid numeric vector')
    return {'count': len(values), 'min': values[0], 'max': values[-1], 'mean': sum(values) / len(values),
            'p50': values[math.ceil(len(values) * .5) - 1], 'p95': values[math.ceil(len(values) * .95) - 1]}


def equal(actual, expected):
    if isinstance(expected, dict):
        require(type(actual) is dict and set(actual) == set(expected), 'Independent object shape differs')
        for name, value in expected.items():
            equal(actual[name], value)
    elif isinstance(expected, list):
        require(type(actual) is list and len(actual) == len(expected), 'Independent array length differs')
        for left, right in zip(actual, expected):
            equal(left, right)
    elif type(expected) is float:
        require(type(actual) in (float, int) and math.isfinite(actual) and
                math.isclose(actual, expected, rel_tol=1e-12, abs_tol=1e-9), 'Independent floating calculation differs')
    else:
        require(type(actual) is type(expected) and actual == expected, 'Independent exact value differs')


def method(value):
    require(value['observer_method'] == METHOD and value['thread_context_switch_collection'] == COLLECTION, 'Observer method differs')


def limited(value):
    method(value)
    require(value['source_revision'] == SOURCE and all(value[k] is False for k in
            ('performance_eligible', 'phase6_passed', 'phase7_authorized', 'next_arm_authorized')), 'Unqualified acceptance claim')
    require(all(value[k] is None for k in ('whole_host_idle', 'quiet_window', 'performance_acceptance')), 'Unknown host/performance claim differs')


def inventory(root):
    result = {}
    require(root.is_dir() and not root.is_symlink(), 'Original raw root missing')
    count = 0
    for path in sorted(root.rglob('*')):
        count += 1
        require(count <= 4096, 'Raw recursive inventory bound')
        mode = path.lstat().st_mode
        require(stat.S_ISDIR(mode) or stat.S_ISREG(mode), 'Nonregular raw object')
        if stat.S_ISREG(mode):
            result[path.relative_to(root).as_posix()] = record(path)
    require(sum(item['bytes'] for item in result.values()) <= 1024 * 1024 * 1024, 'Raw byte inventory bound')
    return result


def current_references(manifest, inputs):
    refs = {}
    require({k: len(v) for k, v in manifest['sources'].items()} == {'method': 9, 'foundation': 7, 'native': 4, 'integration': 6}, 'Current source inventory differs')
    for group, items in manifest['sources'].items():
        for name, ref in items.items():
            refs[group + '/' + name] = verify(ref)
    for key in ('policy', 'plan', 'preparation'):
        refs[key] = verify(manifest[key])
    for group in ('pending', 'prerequisites'):
        for name, ref in manifest[group].items():
            refs[group + '/' + name] = verify(ref)
    require(len(inputs) == 11, 'Eleven original inputs required')
    for name, ref in inputs.items():
        refs['input/' + name] = verify(ref)
    reader = HARNESS / 'phase6-linux-process-only-v2-independent-reader-20261102'
    for name, pin in READER_PINS.items():
        refs['reader/' + name] = pinned(reader / name, pin)
    refs['reader_source_freeze'] = pinned(HARNESS / 'phase6-linux-process-only-v2-independent-reader-review-20261102-root/source-freeze.json',
        (2110, '8078f18ed9f13846fef7e71bfadc508a431817e3c04d4be4fc73d22d0b177f25'))
    return refs


def check_window(samples, raw_clocks, progress, metric, main, panel):
    method(metric)
    require(len(samples) == len(raw_clocks) == len(progress['clocks']) == 960 and
            progress['requested_count'] == progress['capture_calls'] == progress['samples_written'] == 960,
            'Incomplete original 960 captures or clocks')
    require(progress['kind'] == 'event-anchored-count-v1' and progress['status'] == 'passed' and
            progress['interval_ns'] == 250000000 and 0 < progress['deadline_ns'] - progress['started_ns'] <= 1260000000000 and
            metric['sample_count'] == 960 and metric['sampling_protocol'] == 'event-anchored-count-v1', 'Count-pacing/deadline method differs')
    require(all(metric[k] is None for k in ('stable_thread_membership', 'observed_thread_context_switch_delta', 'wakeup_count')), 'Thread metrics must remain uncollected')
    families = []
    previous = None
    for index, (sample, clock, saved) in enumerate(zip(samples, raw_clocks, progress['clocks']), 1):
        method(sample)
        require(sample['context_switches'] is None, 'Sample context-switch metric is not null')
        require(set(saved) == {'index', 'due_ns', 'actual_start_ns', 'late_ns', 'capture_end_ns', 'serialization_end_ns', 'sample_write_end_ns', 'clock_log_end_ns'} and all(type(v) is int for v in saved.values()), 'Original clock shape differs')
        equal(clock, {k: v for k, v in saved.items() if k != 'clock_log_end_ns'})
        equal(sample['sampling_clock'], {k: saved[k] for k in ('index', 'due_ns', 'actual_start_ns', 'late_ns', 'capture_end_ns')})
        require(saved['index'] == sample['snapshot_index'] == index and saved['actual_start_ns'] == sample['monotonic_ns'], 'Original row/clock identity differs')
        require(saved['due_ns'] == (previous['actual_start_ns'] + 250000000 if previous else progress['started_ns']) and
                saved['late_ns'] == saved['actual_start_ns'] - saved['due_ns'] >= 0, 'Original pacing differs')
        require(saved['actual_start_ns'] <= saved['capture_end_ns'] <= saved['serialization_end_ns'] <= saved['sample_write_end_ns'] <= saved['clock_log_end_ns'] < progress['deadline_ns'], 'Original clock ordering differs')
        require(0 <= sample['observer_cost_ns'] <= saved['capture_end_ns'] - saved['actual_start_ns'], 'Observer time invalid')
        bounds = sample['cpu_counter_read_window_ns']
        require(len(bounds) == 2 and all(type(v) is int for v in bounds) and saved['actual_start_ns'] <= bounds[0] <= bounds[1] <= saved['capture_end_ns'], 'Original CPU read window differs')
        require(previous is None or saved['actual_start_ns'] >= previous['clock_log_end_ns'], 'Capture overlaps prior write')
        previous = saved
        members = sample['members']
        require(members and len({m['pid'] for m in members}) == len(members), 'Empty/duplicate original process family')
        family = {(m['pid'], m['started']) for m in members}
        require({(main['pid'], main['started']), (panel['pid'], panel['started'])} <= family, 'Original main/panel generation missing')
        for member in members:
            method(member)
            require(member['threads'] is None and all(type(member[k]) is int and member[k] > 0 for k in ('pid', 'started')) and
                    type(member['cpu_ticks']) is int and member['cpu_ticks'] >= 0, 'Original process identity/counters differ')
            memory = member['memory_kib']
            require({'Pss', 'Rss', 'Private_Clean', 'Private_Dirty'} <= set(memory) and all(type(v) is int and v >= 0 for v in memory.values()), 'Original memory metrics invalid')
        equal(sample['pss_kib'], sum(m['memory_kib']['Pss'] for m in members))
        equal(sample['uss_kib'], sum(sum(m['memory_kib'].get(k, 0) for k in ('Private_Clean', 'Private_Dirty', 'Private_Hugetlb')) for m in members))
        equal(sample['cpu_ticks'], sum(m['cpu_ticks'] for m in members))
        for side in ('original_identities_before', 'original_identities_after'):
            for role, expected in (('main', main), ('panel', panel)):
                require(all(sample[side][role][k] == expected[k] for k in ('pid', 'started')), 'Original retained identity changed')
        families.append(family)
    require(progress['tail_due_ns'] == previous['actual_start_ns'] + 250000000 and
            max(progress['tail_due_ns'], previous['clock_log_end_ns']) <= progress['tail_reached_ns'] <= progress['files_flushed_ns'] < progress['deadline_ns'], 'Original tail/flush differs')
    require(progress['files_flushed_ns'] - progress['started_ns'] >= 240000000000 and samples[-1]['monotonic_ns'] - samples[0]['monotonic_ns'] >= 239750000000, 'Original capture duration differs')
    equal(metric['actual_elapsed_seconds'], (progress['files_flushed_ns'] - progress['started_ns']) / 1e9)
    equal(metric['sample_span_seconds'], (samples[-1]['monotonic_ns'] - samples[0]['monotonic_ns']) / 1e9)
    for key in ('pss_kib', 'uss_kib'):
        equal(metric[key], summary([row[key] for row in samples]))
    equal(metric['observer_cost_ms'], summary([row['observer_cost_ns'] / 1e6 for row in samples]))
    equal(metric['late_ms'], summary([clock['late_ns'] / 1e6 for clock in progress['clocks']]))
    for key, begin, end in [('serialization_cost_ms', 'capture_end_ns', 'serialization_end_ns'), ('sample_write_cost_ms', 'serialization_end_ns', 'sample_write_end_ns'), ('clock_log_cost_ms', 'sample_write_end_ns', 'clock_log_end_ns')]:
        equal(metric[key], summary([(clock[end] - clock[begin]) / 1e6 for clock in progress['clocks']]))
    equal(metric['observation_intervals_ms'], summary([(right['monotonic_ns'] - left['monotonic_ns']) / 1e6 for left, right in zip(samples, samples[1:])]))
    require(all(family == families[0] for family in families) and metric['stable_process_membership'] is True, 'Stable process family required for current aggregate')
    first, last = samples[0]['cpu_counter_read_window_ns'], samples[-1]['cpu_counter_read_window_ns']
    delta, hz = samples[-1]['cpu_ticks'] - samples[0]['cpu_ticks'], metric['cpu_clock_ticks_per_second']
    low, high, twice = last[0] - first[1], last[1] - first[0], sum(last) - sum(first)
    require(delta >= 0 and type(hz) is int and hz > 0 and 0 < low <= twice / 2 <= high, 'Independent CPU interval invalid')
    cpu = metric['cpu_counter_normalization']
    for key, value in {'counter_delta_ticks': delta, 'interval_min_ns': low, 'interval_max_ns': high, 'twice_nominal_interval_ns': twice}.items():
        equal(cpu[key], value)
    nominal = delta * 200000000000.0 / (hz * twice)
    ranges = [delta * 100000000000.0 / (hz * high), delta * 100000000000.0 / (hz * low)]
    equal(cpu['nominal_percent_one_core'], nominal)
    equal(cpu['read_window_normalization_percent_range'], ranges)
    equal(metric['cpu_percent_one_core'], nominal)
    return {'delta': delta, 'hz': hz, 'low': low, 'high': high, 'twice': twice,
            'first_read_window_ns': first, 'last_read_window_ns': last,
            'nominal_percent_one_core': nominal, 'normalization_range': ranges}


def publish(path, value):
    pending = path.with_suffix('.pending.json')
    require(not path.exists() and not pending.exists(), 'Independent audit outputs are exclusive')
    data = (json.dumps(value, indent=2, sort_keys=True, allow_nan=False) + '\n').encode('utf-8')
    with pending.open('xb') as stream:
        require(stream.write(data) == len(data), 'Short independent audit write')
        stream.flush()
        os.fsync(stream.fileno())
    require(raw(pending) == data, 'Independent audit durable readback differs')
    os.link(pending, path)


def main():
    require(sys.platform == 'linux', 'Original Linux path semantics required')
    output = HERE / 'independent-summary-audit.json'
    require(not output.exists() and not output.with_suffix('.pending.json').exists(), 'Preserve prior independent audit')
    script_ref = record(Path(__file__).resolve())
    summary_ref = pinned(SUMMARY, SUMMARY_PIN)
    combined = read(SUMMARY)
    require(set(combined) == {'kind', 'status', 'source_revision', 'observer_method', 'thread_context_switch_collection', 'performance_eligible', 'phase6_passed', 'phase7_authorized', 'next_arm_authorized', 'whole_host_idle', 'quiet_window', 'performance_acceptance', 'context_switches', 'wakeup_count', 'integration_manifest', 'root_final_review', 'summarizer', 'inputs', 'arms_in_execution_order', 'variants', 'limits'}, 'Exact completed limited summary shape required')
    limited(combined)
    require(combined['kind'] == 'complete_F2_process_only_v2_limited_comparison' and combined['status'] == 'completed_limited_process_only_consistency' and combined['context_switches'] is combined['wakeup_count'] is None, 'Limited process-only summary context differs')
    manifest_ref = pinned(COHORT / 'integration-manifest.json', MANIFEST_PIN)
    require(combined['integration_manifest'] == manifest_ref, 'Summary manifest reference differs')
    manifest = read(manifest_ref['path'])
    final_ref = pinned(COHORT / 'complete-process-only-v2.root-summary-review.json', FINAL_REVIEW_PIN)
    require(combined['root_final_review'] == final_ref, 'Root final review reference differs')
    verify(combined['summarizer'], HARNESS / 'phase6-linux-process-only-v2-integration-20261102/summarize_descriptive.py')
    before = current_references(manifest, combined['inputs'])
    raw_before, original_records, arm_audits, external_refs = {}, [], [], [script_ref, summary_ref, manifest_ref, final_ref, combined['summarizer']]
    groups = {r: {'latencies': [], 'states': {s: {'pss': [], 'uss': [], 'counters': []} for s in ('visible', 'hidden')}} for r in ('tauri', 'mygo')}
    arms = combined['arms_in_execution_order']
    require(len(arms) == 4 and [a['renderer'] for a in arms] == ['tauri', 'mygo', 'mygo', 'tauri'], 'Four fresh ordered ABBA arms required')
    for index, (arm, pin) in enumerate(zip(arms, REVIEW_PINS), 1):
        renderer = arm['renderer']
        name = f'process-v2-1fe685c-{index}-{renderer}'
        require(arm['arm'] == name, 'Fresh v2 arm identity differs')
        root = RAW_BASE / name
        raw_before[name] = inventory(root)
        ref = pinned(COHORT / (name + '.independent-raw-review.json'), pin)
        require(arm['independent_review'] == ref, 'Four actual original independent reviews required')
        review = read(ref['path'])
        limited(review)
        require(review['kind'] == 'phase6_F2_process_only_independent_raw_review' and review['status'] == 'passed_limited_independent_process_only_raw_consistency' and review['arm'] == name and review['arm_index'] == index and review['renderer'] == renderer and review['actual_original_raw_review_completed'] is True and review['whole_ABBA_complete'] is False and len(review['checks']) == 13 and all(v is True for v in review['checks'].values()), 'Original independent review context differs')
        external_refs.append(ref)
        for key, review_key, suffix in [('assessment', 'root_assessment', 'assessment.json'), ('root_png', 'root_png_evidence', 'root-png.json'), ('copy_proof', 'setup_copy_proof', 'setup-copy-proof.json')]:
            require(arm[key] == review[review_key], 'Arm original proof chain differs')
            external_refs.append(verify(arm[key], COHORT / (name + '.' + suffix)))
        external_refs.append(verify(review['execution'], COHORT / (name + '.execution.json')))
        external_refs.append(verify(review['assessor'], COHORT / 'assess_descriptive.py'))
        require(review['integration_manifest'] == manifest_ref, 'Original arm manifest differs')
        assessment = read(arm['assessment']['path'])
        limited(assessment)
        config, runtime, report = read(review['execution']['path']), read(root / 'runtime.json'), read(root / 'functional/performance.json')
        method(config); method(runtime); method(report)
        require(config == {**read(COHORT / (name + '.pending.json')), 'root_go': True} and config['inputs'] == combined['inputs'] == runtime['inputs'] and config['expected'] == runtime['expected'] and config['expected']['source_revision'] == SOURCE, 'Original execution inputs/source differ')
        require(report['status'] == 'passed' and report['source_revision'] == SOURCE and report['renderer'] == renderer and report['arm_index'] == index and report.get('first_error') is None, 'Original failed arm cannot enter aggregate')
        raw_list = arm['raw_evidence']
        expected_paths = {str(p) for p in root.iterdir() if p.is_file() and p.name != '.native-capture-fixture'}
        expected_paths |= {str(p) for p in (root / 'functional').iterdir() if p.is_file()}
        expected_paths.add(str(root / 'functional/private-ss/proof.json'))
        require(raw_list == review['raw_evidence'] == assessment['raw_evidence'] and len(raw_list) == 34 and {r['path'] for r in raw_list} == expected_paths, 'Every original closed raw file must match')
        original_records.extend(verify(r) for r in raw_list)
        require(len(report['warmup']) == 5 and len(report['samples']) == 30, 'Five discarded/30 formal activation counts differ')
        values = []
        first = report['first_hotkey']
        for sample in [first, *report['warmup'], *report['samples']]:
            require(all(sample[k] == first[k] for k in ('pid', 'started', 'xid', 'session_id')), 'Activation process/window/session changed')
            require(0 < sample['input']['input_start_ns'] <= sample['input']['input_synced_ns'] <= sample['native']['monotonic_ns'] <= sample['native_observed_ns'], 'Activation input/observation causality differs')
            equal(sample['activation_proxy_ms'], (sample['native_observed_ns'] - sample['input']['input_start_ns']) / 1e6)
        values = [(sample['native_observed_ns'] - sample['input']['input_start_ns']) / 1e6 for sample in report['samples']]
        equal(report['warm_activation_proxy_ms'], summary(values))
        equal(assessment['warm_activation_proxy_ms'], summary(values))
        equal(arm['warm_activation_proxy_ms'], summary(values))
        groups[renderer]['latencies'].extend(values)
        counters = {}
        for state in ('visible', 'hidden'):
            samples = rows(root / ('functional/resources-' + state + '.jsonl'))
            clocks = rows(root / ('functional/resource-clock-' + state + '.jsonl'))
            metric = report['resources'][state]
            counter = check_window(samples, clocks, report['resource_sampling_progress'][state], metric, report['original_main'], first)
            equal(arm['resources'][state], metric)
            equal(assessment['verified_resources'][state], metric)
            group = groups[renderer]['states'][state]
            group['pss'].extend(row['pss_kib'] for row in samples)
            group['uss'].extend(row['uss_kib'] for row in samples)
            group['counters'].append(counter)
            counters[state] = counter
        arm_audits.append({'arm': name, 'renderer': renderer, 'formal_activations': 30, 'discarded_warmups': 5,
                           'resources_per_state': 960, 'raw_clock_rows_per_state': 960,
                           'original_main': report['original_main'],
                           'original_panel': {k: first[k] for k in ('pid', 'started', 'xid', 'session_id')},
                           'counter_intervals_recomputed_from_raw': counters, 'independent_review': ref})
    computed = {}
    for renderer, group in groups.items():
        require(len(group['latencies']) == 60, 'Sixty genuine formal samples per renderer required')
        result = {'warm_activation_proxy_ms': summary(group['latencies']), 'resources': {}}
        for state, values in group['states'].items():
            require(len(values['pss']) == len(values['uss']) == 1920 and len(values['counters']) == 2, '1920 genuine snapshots/two intervals required')
            frequencies = {c['hz'] for c in values['counters']}
            require(len(frequencies) == 1, 'Actual CPU clock frequency differs between arms')
            hz = frequencies.pop()
            delta = sum(c['delta'] for c in values['counters'])
            twice = sum(c['twice'] for c in values['counters'])
            low, high = sum(c['low'] for c in values['counters']), sum(c['high'] for c in values['counters'])
            cpu = {'counter_delta_ticks': delta, 'ticks_per_second': hz, 'sum_twice_nominal_intervals_ns': twice,
                   'nominal_percent_one_core': delta * 200000000000.0 / (hz * twice),
                   'read_window_normalization_percent_range': [delta * 100000000000.0 / (hz * high), delta * 100000000000.0 / (hz * low)], 'scope': CPU_SCOPE}
            result['resources'][state] = {'empirical_snapshot_pss_kib': summary(values['pss']),
                'empirical_snapshot_uss_kib': summary(values['uss']), 'cpu_counter_interval': cpu,
                'stable_thread_membership': None, 'observed_thread_context_switch_delta': None,
                'wakeup_count': None, 'thread_context_switch_collection': COLLECTION}
        computed[renderer] = result
    equal(combined['variants'], computed)
    require(len(original_records) == len({r['path'] for r in original_records}) == 136, 'All 136 unique original raw records required')
    require(before == current_references(manifest, combined['inputs']), 'Current source/input bytes drifted')
    for ref in external_refs:
        verify(ref)
    inventories = {}
    for name, original in raw_before.items():
        require(original == inventory(RAW_BASE / name), 'Recursive original raw inventory drifted')
        inventories[name] = {'regular_files': len(original), 'bytes': sum(r['bytes'] for r in original.values()),
                            'before_after_identical': True,
                            'inventory_sha256': hashlib.sha256(json.dumps(original, sort_keys=True, separators=(',', ':')).encode('utf-8')).hexdigest()}
    audit = {'kind': 'phase6_F2_process_only_v2_independent_summary_audit',
             'status': 'passed_limited_independent_summary_consistency', 'source_revision': SOURCE,
             'observer_method': METHOD, 'thread_context_switch_collection': COLLECTION,
             'summary': summary_ref, 'root_final_review': final_ref, 'integration_manifest': manifest_ref,
             'independent_audit_reader': script_ref, 'whole_ABBA_raw_consistency_recomputed': True,
             'formal_activations_total': 120, 'formal_activations_per_renderer': 60,
             'resource_rows_total': 7680, 'raw_clock_rows_total': 7680,
             'snapshots_per_state_per_renderer': 1920, 'closed_raw_originals_total': 136,
             'arms': arm_audits, 'variants_recomputed_from_original_raw': computed,
             'current_source_and_input_records_before_after_identical': before,
             'original_136_raw_records': original_records, 'recursive_raw_inventories': inventories,
             'actual_native_or_product_executed': False, 'original_reader_rerun': False,
             'author_summarizer_executed': False, 'root_go': False,
             'performance_eligible': False, 'phase6_passed': False, 'phase7_authorized': False,
             'next_arm_authorized': False, 'whole_host_idle': None, 'quiet_window': None,
             'performance_acceptance': None, 'context_switches': None, 'wakeup_count': None,
             'limits': ['Independent numeric/clock/current-byte consistency only; actual per-arm native/privacy/visual checks remain the original separately bound four reviews.',
                        'Snapshot empirical distributions are correlated; pooled nearest-rank percentiles are not equal-time means or independent repetitions.',
                        'Duration-weighted disjoint counter-read intervals only; neither full-window CPU nor a common-time family bound, tick-quantization bound or statistical confidence interval.',
                        'Thread/context/wakeup probes were not collected; removing them changes observer cost. No v1 sample or failed v1 A1 contributes to these four v2 arms.',
                        'Whole-host quiet, Windows names, GPU, first-interactive/search-ready/IME/DPI/multimonitor and performance adoption remain unverified.']}
    publish(output, audit)


if __name__ == '__main__':
    main()

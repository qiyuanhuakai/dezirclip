"""Source/AST and synthetic proc files only; no native fixture or main is executed."""
import ast
import collections
import copy
import errno
import hashlib
import importlib.util
import math
from pathlib import Path
import tempfile
import types
import unittest
from unittest import mock

HERE = Path(__file__).resolve().parent
OLD_INNER = HERE.parent / 'phase6-linux-count-observer-v1-5d6-20261030/inner.py'
OLD_ASSESS = HERE.parent / 'phase6-linux-count-assessment-F2-descriptive-20261102/assess_descriptive.py'
METHOD = 'process-resource-only-v2'
COLLECTION = 'not_collected'
SPEC = importlib.util.spec_from_file_location('process_only_assessor', HERE / 'assess_descriptive.py')
ASSESS = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(ASSESS)


def require(condition, message):
    if not condition:
        raise RuntimeError(message)


def functions(path):
    return {node.name: node for node in ast.parse(path.read_bytes()).body
            if isinstance(node, ast.FunctionDef)}


def load_sampler(proc):
    names = {'summary', 'process_stat', 'family_snapshot', 'original_resource_processes',
             'counter_rate_interval'}
    tree = ast.parse((HERE / 'inner.py').read_bytes())
    selected = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in names]
    namespace = {'Path': lambda value: proc if str(value) == '/proc' else Path(value),
                 'require': require, 'math': math, 'OBSERVER_METHOD': METHOD,
                 'THREAD_COLLECTION': COLLECTION}
    exec(compile(ast.Module(body=selected, type_ignores=[]), '<reviewed pure proc sampler>', 'exec'), namespace)
    return namespace


def stat_text(pid, parent, started, user=10, kernel=5):
    fields = ['0'] * 40
    fields[0], fields[1], fields[11], fields[12], fields[19] = 'S', str(parent), str(user), str(kernel), str(started)
    return str(pid) + ' (synthetic process) ' + ' '.join(fields) + '\n'


def member(proc, pid, parent, started, pss, clean, dirty, user=10, kernel=5):
    path = proc / str(pid)
    path.mkdir()
    (path / 'stat').write_text(stat_text(pid, parent, started, user, kernel), encoding='ascii')
    (path / 'smaps_rollup').write_text(
        f'Pss: {pss} kB\nRss: {pss * 2} kB\nPrivate_Clean: {clean} kB\nPrivate_Dirty: {dirty} kB\n',
        encoding='ascii')
    return path


def clocks():
    start, interval = 1000, 250_000_000
    samples, raw, stored = [], [], []
    for offset in range(960):
        actual = start + offset * interval
        row = {'index': offset + 1, 'due_ns': actual, 'actual_start_ns': actual, 'late_ns': 0,
               'capture_end_ns': actual + 10, 'serialization_end_ns': actual + 20,
               'sample_write_end_ns': actual + 30, 'clock_log_end_ns': actual + 40}
        stored.append(row)
        raw.append({key: value for key, value in row.items() if key != 'clock_log_end_ns'})
        samples.append({'snapshot_index': offset + 1, 'monotonic_ns': actual,
                        'sampling_clock': {key: row[key] for key in
                            ('index', 'due_ns', 'actual_start_ns', 'late_ns', 'capture_end_ns')},
                        'cpu_counter_read_window_ns': [actual + 1, actual + 9], 'observer_cost_ns': 10})
    tail = stored[-1]['actual_start_ns'] + interval
    progress = {'kind': 'event-anchored-count-v1', 'status': 'passed', 'requested_count': 960,
                'capture_calls': 960, 'samples_written': 960, 'interval_ns': interval,
                'deadline_ns': start + 1_260_000_000_000, 'started_ns': start,
                'tail_due_ns': tail, 'tail_reached_ns': tail, 'files_flushed_ns': tail + 1,
                'clocks': stored}
    return samples, raw, progress


class ProcessOnlyContracts(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='process-only-source-fake-')
        self.addCleanup(self.temporary.cleanup)
        self.proc = Path(self.temporary.name).resolve() / 'proc'
        self.proc.mkdir()
        self.main = member(self.proc, 68, 1, 100, 100, 30, 40)
        self.child = member(self.proc, 69, 68, 101, 50, 10, 20, 2, 1)
        self.namespace = load_sampler(self.proc)

    def snapshot(self):
        return self.namespace['family_snapshot'](68, {68: 100})

    def test_process_memory_and_CPU_sums_are_preserved_without_any_task_access(self):
        (self.main / 'task').mkdir()
        (self.main / 'task/546').mkdir()
        (self.child / 'task').mkdir()
        original_read, original_iter = Path.read_text, Path.iterdir
        attempted = []
        def guarded_read(path, *args, **kwargs):
            if 'task' in path.parts:
                attempted.append(str(path))
                raise AssertionError('Task probe is forbidden')
            return original_read(path, *args, **kwargs)
        def guarded_iter(path):
            if 'task' in path.parts:
                attempted.append(str(path))
                raise AssertionError('Task probe is forbidden')
            return original_iter(path)
        with mock.patch.object(Path, 'read_text', guarded_read), mock.patch.object(Path, 'iterdir', guarded_iter):
            value = self.snapshot()
        self.assertEqual(attempted, [])
        self.assertEqual((value['pss_kib'], value['uss_kib'], value['cpu_ticks']), (150, 100, 18))
        self.assertEqual(value['observer_method'], METHOD)
        self.assertEqual(value['thread_context_switch_collection'], COLLECTION)
        self.assertIsNone(value['context_switches'])
        self.assertTrue(all(item['threads'] is None and item['observer_method'] == METHOD
                            and item['thread_context_switch_collection'] == COLLECTION for item in value['members']))

    def test_missing_original_Desktop_stat_is_fatal(self):
        (self.main / 'stat').unlink()
        with self.assertRaisesRegex(RuntimeError, 'Desktop identity lost'):
            self.snapshot()

    def test_selected_process_missing_smaps_is_fatal(self):
        (self.child / 'smaps_rollup').unlink()
        with self.assertRaisesRegex(RuntimeError, 'stage=smaps-rollup pid=69'):
            self.snapshot()

    def test_required_memory_fields_or_bad_numbers_are_fatal(self):
        for contents in ['Pss: 100 kB\n', 'Pss: invalid kB\n']:
            with self.subTest(contents=contents):
                (self.main / 'smaps_rollup').write_text(contents, encoding='ascii')
                with self.assertRaisesRegex(RuntimeError, 'stage=smaps-rollup pid=68'):
                    self.snapshot()

    def test_permission_and_other_IO_errors_are_not_thread_exemptions(self):
        original = Path.read_text
        for error in [PermissionError(errno.EACCES, 'synthetic denied'), OSError(errno.EIO, 'synthetic IO')]:
            def read(path, *args, **kwargs):
                if path == self.main / 'smaps_rollup':
                    raise error
                return original(path, *args, **kwargs)
            with self.subTest(error=type(error).__name__), mock.patch.object(Path, 'read_text', read):
                with self.assertRaisesRegex(RuntimeError, 'stage=smaps-rollup pid=68'):
                    self.snapshot()

    def test_process_start_generation_change_during_sample_is_fatal(self):
        original = Path.read_text
        reads = 0
        def read(path, *args, **kwargs):
            nonlocal reads
            if path == self.main / 'stat':
                reads += 1
                if reads == 2:
                    return stat_text(68, 1, 999)
            return original(path, *args, **kwargs)
        with mock.patch.object(Path, 'read_text', read), self.assertRaisesRegex(RuntimeError, 'process-identity-recheck'):
            self.snapshot()

    def test_selected_process_disappearing_at_recheck_is_fatal(self):
        original = Path.read_text
        reads = 0
        def read(path, *args, **kwargs):
            nonlocal reads
            if path == self.main / 'stat':
                reads += 1
                if reads == 2:
                    raise FileNotFoundError(errno.ENOENT, 'synthetic process exit')
            return original(path, *args, **kwargs)
        with mock.patch.object(Path, 'read_text', read), self.assertRaisesRegex(RuntimeError, 'process-identity-recheck'):
            self.snapshot()

    def test_original_pidfd_exit_or_identity_change_remains_fatal(self):
        tickets = [{'identity': {'pid': 68, 'started': 100}}, {'identity': {'pid': 69, 'started': 101}}]
        for exited, started in [(True, 100), (False, 999)]:
            support = types.SimpleNamespace(exited=lambda unused: exited,
                process_identity=lambda pid: {'pid': pid, 'started': started})
            with self.subTest(exited=exited), self.assertRaisesRegex(RuntimeError, 'resource identity failed'):
                self.namespace['original_resource_processes'](support, *tickets, 'synthetic')

    def test_assessor_accepts_only_explicit_process_only_members(self):
        value = self.snapshot()
        ASSESS.validate_members(value, {'pid': 68, 'started': 100}, {'pid': 69, 'started': 101})
        for replacement in ([], 0, False, {}, [{'tid': 546, 'started': 200}]):
            bad = copy.deepcopy(value)
            bad['members'][0]['threads'] = replacement
            with self.subTest(replacement=replacement), self.assertRaises(AssertionError):
                ASSESS.validate_members(bad, {'pid': 68, 'started': 100}, {'pid': 69, 'started': 101})

    def test_assessor_rejects_context_zero_empty_or_missing_method_markers(self):
        value = self.snapshot()
        for field, replacement in [('context_switches', 0), ('context_switches', []),
                                    ('observer_method', 'event-anchored-count-v1'),
                                    ('thread_context_switch_collection', 'complete')]:
            bad = copy.deepcopy(value)
            bad[field] = replacement
            with self.subTest(field=field), self.assertRaises(AssertionError):
                ASSESS.validate_members(bad, {'pid': 68, 'started': 100}, {'pid': 69, 'started': 101})
        bad = copy.deepcopy(value)
        bad['members'][0].pop('observer_method')
        with self.assertRaises(KeyError):
            ASSESS.validate_members(bad, {'pid': 68, 'started': 100}, {'pid': 69, 'started': 101})

    def test_uncollected_threads_do_not_relax_memory_CPU_or_process_identity_validation(self):
        for change in [lambda value: value['members'][0]['memory_kib'].update(Pss=-1),
                       lambda value: value['members'][0]['memory_kib'].pop('Private_Dirty'),
                       lambda value: value['members'][0].update(cpu_ticks=None),
                       lambda value: value['members'][0].update(started=999),
                       lambda value: value['members'].append(copy.deepcopy(value['members'][0]))]:
            bad = self.snapshot()
            change(bad)
            with self.assertRaises(AssertionError):
                ASSESS.validate_members(bad, {'pid': 68, 'started': 100}, {'pid': 69, 'started': 101})

    def test_window_context_membership_delta_and_wakeup_are_strictly_uncollected(self):
        metric = {'observer_method': METHOD, 'thread_context_switch_collection': COLLECTION,
                  'stable_thread_membership': None, 'observed_thread_context_switch_delta': None,
                  'wakeup_count': None}
        ASSESS.validate_process_only_window(metric)
        for field in ('stable_thread_membership', 'observed_thread_context_switch_delta', 'wakeup_count'):
            for replacement in (0, [], False, True):
                with self.subTest(field=field, replacement=replacement), self.assertRaises(AssertionError):
                    ASSESS.validate_process_only_window({**metric, field: replacement})

    def test_frozen_math_pacer_UI_qualification_and_resource_identity_functions_are_unchanged(self):
        raw = OLD_INNER.read_bytes()
        self.assertEqual((len(raw), hashlib.sha256(raw).hexdigest()),
                         (44940, 'e8a3d1f0f1972e6ed51d81cbfc147f85b63d1371f7c0d0e1b8084f918ff163d5'))
        before, after = functions(OLD_INNER), functions(HERE / 'inner.py')
        for name in set(before) - {'family_snapshot', 'main'}:
            self.assertEqual(ast.dump(before[name]), ast.dump(after[name]), name)
        for name in ('counted_snapshots', 'counter_rate_interval'):
            old_pacer = functions(OLD_INNER.with_name('pacer.py'))[name]
            self.assertEqual(ast.dump(after[name]), ast.dump(old_pacer), name)
        before_nested = {n.name: n for n in ast.walk(before['main']) if isinstance(n, ast.FunctionDef)}
        after_nested = {n.name: n for n in ast.walk(after['main']) if isinstance(n, ast.FunctionDef)}
        for name in set(before_nested) - {'main', 'resources'}:
            self.assertEqual(ast.dump(before_nested[name]), ast.dump(after_nested[name]), name)

    def test_frozen_assessor_math_metadata_and_all_nonthread_native_assertions_are_preserved(self):
        raw = OLD_ASSESS.read_bytes()
        self.assertEqual((len(raw), hashlib.sha256(raw).hexdigest()),
                         (28640, '3f33819586b577a0441954a9240bdd85f66f7f7de5866499b7f4cc99983918ac'))
        before, after = functions(OLD_ASSESS), functions(HERE / 'assess_descriptive.py')
        for name in set(before) - {'validate_members', 'main'}:
            self.assertEqual(ast.dump(before[name]), ast.dump(after[name]), name)
        def nonthread_asserts(node):
            return collections.Counter(ast.dump(item) for item in ast.walk(node) if isinstance(item, ast.Assert)
                and not any(word in ast.dump(item) for word in ('thread', 'context_switch')))
        for name in ('main', 'validate_members'):
            missing = nonthread_asserts(before[name]) - nonthread_asserts(after[name])
            self.assertEqual(missing, collections.Counter(), name)

    def test_family_memory_and_CPU_formulas_are_AST_identical_and_no_task_path_exists(self):
        old = functions(OLD_INNER)['family_snapshot']
        new = functions(HERE / 'inner.py')['family_snapshot']
        old_return = next(node.value for node in old.body if isinstance(node, ast.Return))
        new_return = next(node.value for node in new.body if isinstance(node, ast.Return))
        old_values = {key.value: value for key, value in zip(old_return.keys, old_return.values)}
        new_values = {key.value: value for key, value in zip(new_return.keys, new_return.values)}
        for name in ('pss_kib', 'uss_kib', 'cpu_ticks'):
            self.assertEqual(ast.dump(old_values[name]), ast.dump(new_values[name]), name)
        self.assertIsNone(ast.literal_eval(new_values['context_switches']))
        self.assertFalse(any(isinstance(node, ast.Constant) and node.value == 'task' for node in ast.walk(new)))

    def test_changing_process_membership_still_makes_CPU_unknown(self):
        old = functions(OLD_INNER)['main']
        new = functions(HERE / 'inner.py')['main']
        resources = next(node for node in ast.walk(new) if isinstance(node, ast.FunctionDef) and node.name == 'resources')
        names = {'family_ids', 'stable_family', 'span_ns', 'cpu_delta', 'cpu'}
        statements = [node for node in resources.body if isinstance(node, ast.Assign)
                      and isinstance(node.targets[0], ast.Name) and node.targets[0].id in names]
        old_resources = next(node for node in ast.walk(old) if isinstance(node, ast.FunctionDef) and node.name == 'resources')
        old_statements = [node for node in old_resources.body if isinstance(node, ast.Assign)
                          and isinstance(node.targets[0], ast.Name) and node.targets[0].id in names]
        self.assertEqual([ast.dump(node) for node in statements], [ast.dump(node) for node in old_statements])
        samples = [{'members': [{'pid': 68, 'started': 100}], 'monotonic_ns': 1000, 'cpu_ticks': 5,
                    'cpu_counter_read_window_ns': [1000, 1010]},
                   {'members': [{'pid': 68, 'started': 100}, {'pid': 69, 'started': 101}],
                    'monotonic_ns': 2000, 'cpu_ticks': 20, 'cpu_counter_read_window_ns': [2000, 2010]}]
        namespace = {'samples': samples, 'counter_rate_interval': self.namespace['counter_rate_interval'],
                     'os': types.SimpleNamespace(sysconf=lambda unused: 100)}
        exec(compile(ast.Module(body=statements, type_ignores=[]), '<original process CPU math>', 'exec'), namespace)
        self.assertIs(namespace['stable_family'], False)
        self.assertIsNone(namespace['cpu_delta'])
        self.assertIsNone(namespace['cpu'])

    def test_original_observer_cost_and_counter_read_window_are_still_actual(self):
        old = functions(OLD_INNER)['main']
        new = functions(HERE / 'inner.py')['main']
        def update(tree):
            capture = next(node for node in ast.walk(tree) if isinstance(node, ast.FunctionDef) and node.name == 'capture')
            return next(node for node in ast.walk(capture) if isinstance(node, ast.Call)
                        and isinstance(node.func, ast.Attribute) and node.func.attr == 'update')
        original, current = update(old), update(new)
        self.assertEqual(ast.dump(original), ast.dump(current))
        selected = [keyword for keyword in current.keywords if keyword.arg in ('observer_cost_ns', 'cpu_counter_read_window_ns')]
        call = ast.Expr(value=ast.Call(func=current.func, args=[], keywords=selected))
        namespace = {'value': {}, 'actual_start_ns': 1000, 'counter_start_ns': 1002, 'counter_end_ns': 1100,
                     'time': types.SimpleNamespace(monotonic_ns=lambda: 2234)}
        exec(compile(ast.fix_missing_locations(ast.Module(body=[call], type_ignores=[])), '<actual observer clock expression>', 'exec'), namespace)
        self.assertEqual(namespace['value'], {'observer_cost_ns': 1234, 'cpu_counter_read_window_ns': [1002, 1100]})

    def test_full_960_clock_pacer_tail_contract_is_not_relaxed(self):
        samples, raw, progress = clocks()
        ASSESS.validate_clocks(samples, raw, progress)
        with self.assertRaises(AssertionError):
            ASSESS.validate_clocks(samples[:-1], raw[:-1], progress)
        bad = copy.deepcopy(progress)
        bad['tail_reached_ns'] = bad['tail_due_ns'] - 1
        with self.assertRaises(AssertionError):
            ASSESS.validate_clocks(samples, raw, bad)
        bad = copy.deepcopy(progress)
        bad['interval_ns'] = 249_000_000
        with self.assertRaises(AssertionError):
            ASSESS.validate_clocks(samples, raw, bad)

    def test_new_config_method_is_required_before_private_boundary(self):
        main = functions(HERE / 'inner.py')['main']
        marker = next(node for node in main.body if isinstance(node, ast.Expr) and isinstance(node.value, ast.Call)
                      and isinstance(node.value.func, ast.Name) and node.value.func.id == 'require'
                      and 'observer_method' in ast.dump(node))
        boundary = next(node for node in main.body if isinstance(node, ast.Assign)
                        and isinstance(node.value, ast.Call) and isinstance(node.value.func, ast.Name)
                        and node.value.func.id == 'boundary')
        self.assertLess(main.body.index(marker), main.body.index(boundary))
        for config, accepted in [({'observer_method': METHOD, 'thread_context_switch_collection': COLLECTION}, True),
                                 ({}, False), ({'observer_method': 'old-v1', 'thread_context_switch_collection': COLLECTION}, False)]:
            namespace = {'config': config, 'require': require, 'OBSERVER_METHOD': METHOD, 'THREAD_COLLECTION': COLLECTION}
            code = compile(ast.Module(body=[marker], type_ignores=[]), '<method marker only>', 'exec')
            if accepted:
                exec(code, namespace)
            else:
                with self.assertRaises(RuntimeError):
                    exec(code, namespace)

    def test_assessment_uses_new_limited_kind_and_no_acceptance_or_thread_claim(self):
        self.assertEqual(ASSESS.LIMITED_STATUS, 'passed_limited_process_only_consistency')
        main = functions(HERE / 'assess_descriptive.py')['main']
        assignment = next(node for node in main.body if isinstance(node, ast.Assign)
                          and isinstance(node.targets[0], ast.Name) and node.targets[0].id == 'assessment')
        values = {key.value: value for key, value in zip(assignment.value.keys, assignment.value.values)}
        self.assertEqual(ast.literal_eval(values['kind']), 'phase6_count_paced_process_only_arm_assessment')
        self.assertEqual(values['observer_method'].id, 'OBSERVER_METHOD')
        for name in ('performance_eligible', 'phase6_passed', 'phase7_authorized', 'next_arm_authorized'):
            self.assertIs(ast.literal_eval(values[name]), False)
        for name in ('whole_host_idle', 'quiet_window', 'performance_acceptance'):
            self.assertIsNone(ast.literal_eval(values[name]))


if __name__ == '__main__':
    unittest.main(verbosity=2)

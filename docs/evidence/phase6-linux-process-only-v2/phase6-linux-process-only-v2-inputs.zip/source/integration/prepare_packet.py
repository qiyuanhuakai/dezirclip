"""Prepare fresh false-GO process-only files; never import or execute a native fixture."""
import argparse
import copy
import importlib.util
from pathlib import Path

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('process_only_preparation_helpers', HERE / 'authorize_arm.py')
C = importlib.util.module_from_spec(spec)
spec.loader.exec_module(C)


def prepare(bundle_path, bundle_sha):
    policy, baseline = C.load_policy()
    before = C.snapshot(policy, False)
    C.require(not C.COHORT.exists() and not C.COHORT.is_symlink(), 'Fresh packet required; partial packet is never reused')
    C.require(all(not (C.RAW_BASE / arm['run_name']).exists() and
                  not (C.RAW_BASE / arm['run_name']).is_symlink() for arm in C.ARMS), 'All four v2 raw paths must be absent')
    bundle_ref = C.record(bundle_path)
    C.require(bundle_ref['sha256'] == bundle_sha, 'Exact Root-selected actual prerequisite bundle required')
    bundle = C.read(bundle_path)
    C.require(set(bundle) == {'schema_version', 'kind', 'expected_source_revision', 'root_validated_actual_evidence',
              'candidate_prerequisites', 'r3_schemas'} and type(bundle['schema_version']) is int and bundle['schema_version'] == 1 and
              bundle['kind'] == 'phase6_linux_count_root_input_bundle_v1' and bundle['expected_source_revision'] == C.SOURCE and
              bundle['root_validated_actual_evidence'] is True, 'Original exact-F2 completed-evidence bundle required')
    refs = bundle['candidate_prerequisites']
    C.require(type(refs) is dict and set(refs) == C.PREREQUISITES, 'Five original prerequisites required')
    for item in refs.values():
        C.verify(item)
    provenance = C.read(refs['input_provenance']['path'])
    inputs = copy.deepcopy(provenance['inputs'])
    C.require(set(inputs) == {'desktop', 'helper', 'desktop_proof', 'helper_proof'}, 'Four original F2 product/proof records required')
    C.prerequisites(refs, bundle['r3_schemas'], inputs, baseline)
    original_plan_ref = C.record(C.PRIOR / baseline['prior_plan']['name'])
    C.require({key: original_plan_ref[key] for key in ('bytes', 'sha256')} ==
              {key: baseline['prior_plan'][key] for key in ('bytes', 'sha256')}, 'Original method template changed')
    template = C.read(original_plan_ref['path'])
    C.require(template['root_go'] is False and template['performance_eligible'] is False, 'Only a false-GO template may be copied')
    for name in C.INPUTS - {'desktop', 'helper', 'desktop_proof', 'helper_proof', 'quiet_window_note'}:
        inputs[name] = copy.deepcopy(template['inputs'][name])
    C.require(set(inputs) == C.INPUTS - {'quiet_window_note'}, 'Ten genuine inputs required before the new note')
    for item in inputs.values():
        C.verify(item)
    original_inputs = copy.deepcopy(inputs)
    original_policy = C.record(C.POLICY)
    C.COHORT.mkdir()
    for name in sorted(policy['method_pins']):
        source = (C.NATIVE if name == 'inner.py' else C.PRIOR) / name
        C.write_exclusive(C.COHORT / name, C.bytes_at(source))
    for name in ('assess_descriptive.py', 'test_process_only.py'):
        C.write_exclusive(C.COHORT / name, C.bytes_at(C.NATIVE / name))
    C.write_exclusive(C.COHORT / 'process-only-method.plan.json', C.bytes_at(C.NATIVE / 'source-plan.json'))
    note = {'kind': 'phase6_process_only_v2_prepared_only_note', 'source_revision': C.SOURCE,
            'observer_method': C.METHOD, 'thread_context_switch_collection': C.COLLECTION,
            'root_go': False, 'performance_eligible': False, 'measurement_started': False,
            'windows_host_quiet': None, 'windows_observation_performed': False, 'host_display_ownership': None,
            'scope': 'Preparation only. This hash-bound note is not a quiet certificate or an arm authorization.'}
    note_ref = C.save(C.COHORT / 'prepared-only-note.json', note)
    inputs['quiet_window_note'] = note_ref
    plan = copy.deepcopy(template)
    plan.update(kind='phase6_F2_process_only_v2_pending_review', expected=copy.deepcopy(baseline['expected']),
                inputs=inputs, arms=list(C.ARMS), run_name='awaiting-specific-process-only-arm-review',
                root_go=False, performance_eligible=False, observer_method=C.METHOD,
                thread_context_switch_collection=C.COLLECTION,
                fixture_sources={name: policy['method_pins'][name]['sha256'] for name in template['fixture_sources']},
                planned_raw_output_paths=[str(C.RAW_BASE / arm['run_name']) for arm in C.ARMS],
                candidate_prerequisites=copy.deepcopy(refs), quiet_window_note=note_ref,
                source_preparation={'root_go': False, 'performance_eligible': False, 'phase6_pass': False,
                    'windows_host_quiet': None, 'host_display_ownership': None, 'old_assessor_qualification': None,
                    'baseline_tests_executed_as_v2': False,
                    'scope': 'New process-only method; old tests/assessor are retained as baselines only. No old GO, failed A1, PNG, assessment or review is copied.'})
    for key in baseline['unchanged_method_fields']:
        if key != 'fixture_sources':
            C.require(plan[key] == template[key], 'Original UI/pacing/limit method changed: ' + key)
    for key, name in [('pure_pacer', 'pacer.py'), ('pure_fake_tests', 'test_pacer.py'),
                      ('assessor', 'assess_descriptive.py'), ('assessor_tests', 'test_process_only.py')]:
        plan[key] = C.record(C.COHORT / name)
    plan['baseline_only'] = {'files': {name: C.record(C.COHORT / name) for name in
                            ('assess.py', 'test_assess.py', 'test_source.py', 'test_pacer.py')},
                            'executed_as_process_only_v2_tests': False}
    plan_ref = C.save(C.COHORT / 'comparison-count-v1.plan.json', plan)
    pending = {}
    for arm in C.ARMS:
        pending[arm['run_name']] = C.save(C.COHORT / (arm['run_name'] + '.pending.json'), {**plan, **arm})
    C.require(C.snapshot(policy, False) == before and C.record(C.POLICY) == original_policy,
              'Source/proposal/integration changed during preparation')
    after = C.snapshot(policy, True)
    for item in inputs.values():
        C.verify(item)
    C.require({name: inputs[name] for name in original_inputs} == original_inputs, 'Input records changed')
    C.prerequisites(refs, bundle['r3_schemas'], inputs, baseline)
    C.verify(bundle_ref)
    C.verify(original_plan_ref)
    C.verify(plan_ref)
    C.verify(note_ref)
    for arm in C.ARMS:
        C.verify(pending[arm['run_name']])
        C.require(C.read(pending[arm['run_name']]['path']) == {**plan, **arm}, 'Pending readback differs')
    result = {'kind': 'phase6_process_only_v2_source_preparation', 'status': 'prepared_only',
              'source_revision': C.SOURCE, 'observer_method': C.METHOD, 'thread_context_switch_collection': C.COLLECTION,
              'root_go': False, 'performance_eligible': False, 'phase6_passed': False, 'native_executed': False,
              'runtime_imported_or_executed': False, 'windows_host_quiet': None, 'host_display_ownership': None,
              'root_bundle': bundle_ref, 'candidate_prerequisites': refs, 'r3_schemas': bundle['r3_schemas'],
              'sources_before': before, 'sources_after': after, 'inputs': inputs, 'plan': plan_ref, 'pending': pending,
              'baseline_tests_executed_as_v2': False,
              'scope': 'File preparation only; reused exact-F2 functional19/R3 originals are not new executions. No GO/freeze/manifest/native qualification is produced.'}
    temporary, terminal = C.COHORT / 'preparation.pending.json', C.COHORT / 'preparation.json'
    expected = C.save(temporary, result)
    C.require(C.read(temporary) == result and C.record(temporary) == expected, 'Terminal candidate readback differs')
    C.require(C.snapshot(policy, False) == before and C.snapshot(policy, True) == after,
              'Sources changed before terminal publication')
    for item in inputs.values():
        C.verify(item)
    for item in refs.values():
        C.verify(item)
    C.verify(bundle_ref)
    C.verify(plan_ref)
    C.require(all(not (C.RAW_BASE / arm['run_name']).exists() and
                  not (C.RAW_BASE / arm['run_name']).is_symlink() for arm in C.ARMS), 'A raw arm appeared during preparation')
    C.require(not terminal.exists() and not terminal.is_symlink(), 'Terminal already exists')
    C.os.link(temporary, terminal)
    return result


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--bundle', required=True)
    parser.add_argument('--bundle-sha256', required=True)
    args = parser.parse_args()
    prepare(args.bundle, args.bundle_sha256)


if __name__ == '__main__':
    main()

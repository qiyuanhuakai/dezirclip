"""Standard-library synthetic-file and AST checks; no real preparer, arm or native code."""
import ast
import copy
import errno
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import types
import unittest
from unittest import mock

HERE = Path(__file__).resolve().parent


def module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    value = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(value)
    return value


C = module('pure_process_only_helpers', HERE / 'authorize_arm.py')
P = module('pure_process_only_preparation', HERE / 'prepare_packet.py')
S = module('pure_process_only_summary', HERE / 'summarize_descriptive.py')
D = module('pure_process_only_assessor_helpers', C.NATIVE / 'assess_descriptive.py')


def write(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(value if type(value) is bytes else C.encoded(value))
    return C.record(path)


def pin(reference):
    return {key: reference[key] for key in ('bytes', 'sha256')}


def process_metric():
    return {'observer_method': C.METHOD, 'thread_context_switch_collection': C.COLLECTION,
            'stable_thread_membership': None, 'observed_thread_context_switch_delta': None, 'wakeup_count': None,
            'stable_process_membership': True, 'cpu_clock_ticks_per_second': 100,
            'cpu_counter_normalization': {'counter_delta_ticks': 3, 'twice_nominal_interval_ns': 4_000_000_000,
                                         'interval_min_ns': 1_999_999_999, 'interval_max_ns': 2_000_000_001}}


class PureIntegration(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.base = Path(self.temp.name).resolve()

    def test_real_source_pins_and_only_original_inner_changed(self):
        policy, baseline = C.load_policy()
        self.assertEqual(len(policy['method_pins']), 9)
        self.assertEqual(len(policy['foundation_pins']), 7)
        self.assertEqual(policy['foundation_pins'], baseline['foundation_pins'])
        for name, expected in baseline['method_pins'].items():
            if name != 'inner.py':
                self.assertEqual(policy['method_pins'][name], expected)
        for name, expected in policy['native_pins'].items():
            self.assertEqual(pin(C.record(C.NATIVE / name)), expected)
        self.assertEqual(C.record(C.POLICY)['sha256'], C.POLICY_SHA)

    def test_math_and_unchanged_original_outer_gates_are_exact(self):
        old = ast.parse((C.PRIOR / 'summarize-cohort.py').read_text(encoding='utf-8'))
        new = ast.parse((HERE / 'summarize_descriptive.py').read_text(encoding='utf-8'))
        for name in ('summary', 'check_summary', 'weighted_cpu'):
            a = next(x for x in old.body if isinstance(x, ast.FunctionDef) and x.name == name)
            b = next(x for x in new.body if isinstance(x, ast.FunctionDef) and x.name == name)
            self.assertEqual(ast.dump(a), ast.dump(b))
        source = (HERE / 'authorize_arm.py').read_text(encoding='utf-8')
        self.assertIn('result.validate(execution)', source)
        self.assertNotIn('result.validate =', source)

    def test_unfrozen_policy_refuses_before_output_or_import(self):
        with mock.patch.object(C, 'POLICY_SHA', None), mock.patch.object(C, 'record') as read_record:
            with self.assertRaisesRegex(ValueError, 'unfrozen'):
                C.load_policy()
            read_record.assert_not_called()
        with mock.patch.object(P, 'C', C), mock.patch.object(C, 'POLICY_SHA', None):
            with self.assertRaises(ValueError):
                P.prepare(self.base / 'missing', '0' * 64)
        self.assertFalse(any(self.base.iterdir()))

    def test_strict_json_records_and_exclusive_partial_output(self):
        for body in (b'{"x":1,"x":2}', b'{"x":NaN}', b'{"x":Infinity}'):
            with self.assertRaises(ValueError):
                C.parse(body)
        path = self.base / 'original'
        reference = write(path, b'original')
        with self.assertRaises(ValueError):
            C.verify({**reference, 'bytes': True})
        path.write_bytes(b'partial')
        with self.assertRaises(FileExistsError):
            C.write_exclusive(path, b'replacement')
        self.assertEqual(path.read_bytes(), b'partial')
        with self.assertRaises(ValueError):
            C.verify(reference)

    def test_strict_unknown_Windows_metadata(self):
        value = C.windows(C.ARMS[0]['run_name'], 'preflight')
        D.validate_windows_unverified(value, C.ARMS[0]['run_name'], C.SOURCE, 'preflight')
        for key, replacement in [('native_names', []), ('host_idle', False), ('quiet_window_certified', True),
                                 ('stage', 'postflight'), ('source_revision', 'old')]:
            with self.subTest(key=key), self.assertRaises(AssertionError):
                D.validate_windows_unverified({**value, key: replacement}, C.ARMS[0]['run_name'], C.SOURCE, 'preflight')

    def scan(self, name=None, error=None):
        proc = self.base / 'proc'
        proc.mkdir(exist_ok=True)
        if name is not None:
            write(proc / '77/comm', name.encode('ascii') + b'\n')
        with mock.patch.object(C, 'PROC', proc), mock.patch.object(C, 'sys', types.SimpleNamespace(platform='linux')), \
             mock.patch.object(C, 'os', types.SimpleNamespace(name='posix')):
            if error is None:
                return C.collect_names()
            with mock.patch.object(Path, 'open', side_effect=error):
                return C.collect_names()

    def test_actual_names_strict_and_display_never_owned(self):
        value = self.scan('Xvfb')
        self.assertEqual(value['observed_display_services'], [{'pid': 77, 'name': 'Xvfb', 'source_status': 'unverified', 'operated': False}])
        self.assertIsNone(value['host_idle'])
        for name in sorted(C.COMPILERS | C.PRODUCTS):
            with self.subTest(name=name), self.assertRaises(ValueError):
                self.scan(name)

    def test_only_ENOENT_may_vanish(self):
        self.scan('ordinary')
        self.assertEqual(self.scan(error=FileNotFoundError(errno.ENOENT, 'synthetic'))['vanished_before_name_read'], 1)
        for code in (errno.ESRCH, errno.EACCES, errno.EIO):
            with self.subTest(code=code), self.assertRaises(OSError):
                self.scan(error=OSError(code, 'synthetic'))

    def test_new_method_and_not_collected_fields_cannot_be_fabricated(self):
        good = process_metric()
        S.process_metric(good)
        for key, value in [('observer_method', 'event-anchored-count-v1'),
                           ('thread_context_switch_collection', None), ('stable_thread_membership', False),
                           ('observed_thread_context_switch_delta', 0), ('wakeup_count', 0)]:
            with self.subTest(key=key), self.assertRaises(ValueError):
                S.process_metric({**good, key: value})

    def test_old_enums_and_positive_qualification_are_rejected(self):
        good = {'observer_method': C.METHOD, 'thread_context_switch_collection': C.COLLECTION,
                'status': C.LIMITED, 'source_revision': C.SOURCE, 'performance_eligible': False,
                'phase6_passed': False, 'phase7_authorized': False, 'next_arm_authorized': False,
                'whole_host_idle': None, 'quiet_window': None, 'performance_acceptance': None}
        C.limited(good, C.LIMITED)
        for key, value in [('status', 'passed_limited_descriptive_consistency'), ('status', 'passed'),
                           ('observer_method', 'old'), ('performance_eligible', True), ('quiet_window', False)]:
            with self.subTest(key=key, value=value), self.assertRaises(ValueError):
                C.limited({**good, key: value}, C.LIMITED)

    def test_fresh_v2_prefix_does_not_reuse_failed_count_v1(self):
        raw = self.base / 'raw'
        raw.mkdir()
        (raw / 'count-v1-1fe685c-1-tauri').mkdir()
        with mock.patch.object(C, 'RAW_BASE', raw):
            C.require_prefix(1)
            with self.assertRaises(ValueError):
                C.require_prefix(2)
            (raw / C.ARMS[0]['run_name']).mkdir()
            C.require_prefix(2)
            (raw / (C.ARMS[0]['run_name'] + '-retry')).mkdir()
            with self.assertRaises(ValueError):
                C.require_prefix(2)

    def test_exact_R3_schemas_and_frozen_order_remain(self):
        four = {'desktop': {'synthetic': True}}
        root = {'status': 'passed', 'source_revision': C.SOURCE, 'actual_stages': 13,
                'kind': C.R3_KINDS['root'], 'original_inputs': four,
                'phases': [{'name': name} for name in C.R3_PHASES]}
        C.completed(root, 13, 'original_inputs', C.R3_KINDS['root'], four, C.R3_PHASES)
        for changed in ({**root, 'phase_names': list(reversed(C.R3_PHASES))},
                        {**root, 'phases': root['phases'][:-1]}, {**root, 'status': 'prepared_only'},
                        {**root, 'actual_stages': True}, {**root, 'source_revision': 'old'}):
            with self.assertRaises(ValueError):
                C.completed(changed, 13, 'original_inputs', C.R3_KINDS['root'], four, C.R3_PHASES)

    def synthetic_packet(self):
        roots = {key: self.base / key for key in ('prior', 'native', 'foundation', 'integration', 'cohort', 'raw')}
        real = C.read(C.POLICY)
        methods, foundation, native = {}, {}, {}
        for name in real['method_pins']:
            directory = roots['native'] if name == 'inner.py' else roots['prior']
            methods[name] = pin(write(directory / name, ('synthetic unexecuted ' + name).encode()))
        for name in C.NATIVE_FILES:
            path = roots['native'] / name
            if not path.exists():
                write(path, ('synthetic proposal ' + name).encode())
            native[name] = pin(C.record(path))
        for name in real['foundation_pins']:
            foundation[name] = pin(write(roots['foundation'] / name, ('synthetic foundation ' + name).encode()))
        for name in C.INTEGRATION:
            write(roots['integration'] / name, ('synthetic integration ' + name).encode())
        policy = {'method_pins': methods, 'foundation_pins': foundation, 'native_pins': native,
                  'integration_files': list(C.INTEGRATION)}
        inputs = {name: write(self.base / 'inputs' / name, ('synthetic input ' + name).encode())
                  for name in C.INPUTS - {'quiet_window_note'}}
        four = {name: inputs[name] for name in ('desktop', 'helper', 'desktop_proof', 'helper_proof')}
        expected = {'source_revision': C.SOURCE, 'component_version': '0.2.0-alpha.5'}
        names19 = ['actual19-' + str(n) for n in range(19)]
        refs = {'input_provenance': write(self.base / 'prerequisites/provenance.json', {'expected': expected, 'inputs': four})}
        for key, count, kind, input_key in [
                ('original19_assessment', 19, 'root19', 'input_pair_and_dependencies'),
                ('original19_independent_review', 19, 'phase6-linux-F2-actual19-independent-review', 'original_inputs'),
                ('idle_R3_assessment', 13, C.R3_KINDS['root'], 'original_inputs'),
                ('idle_R3_independent_review', 13, C.R3_KINDS['peer'], 'original_inputs')]:
            document = {'status': 'passed', 'source_revision': C.SOURCE, 'actual_stages': count, 'kind': kind, input_key: four}
            if key == 'idle_R3_assessment':
                document['phases'] = [{'name': name} for name in C.R3_PHASES]
            else:
                document['phase_names'] = C.R3_PHASES if count == 13 else names19
            refs[key] = write(self.base / 'prerequisites' / (key + '.json'), document)
        schemas = {role: {'kind': C.R3_KINDS[role], 'inputs_key': 'original_inputs'} for role in ('root', 'peer')}
        template = {'root_go': False, 'performance_eligible': False, 'inputs': inputs,
                    'fixture_sources': {name: 'original' for name in ('outer.py', 'inner.py', 'x11_target.py', 'paste_prerequisite.py')},
                    'confirmation': 'synthetic only', 'dataset': ['synthetic'], 'comparison': {'synthetic': True},
                    'target_timeout_seconds': 1080, 'resource_display': {'synthetic': True},
                    'execution_policy': {'synthetic': True}, 'per_arm_review_requirements': {'synthetic': True}, 'limits': []}
        plan_ref = write(roots['prior'] / 'comparison-count-v1.plan.json', template)
        baseline = {'fixed_prerequisites': {key: refs[key] for key in
                    ('input_provenance', 'original19_assessment', 'original19_independent_review')},
                    'expected': expected, 'actual19_phase_names': names19,
                    'prior_plan': {'name': 'comparison-count-v1.plan.json', **pin(plan_ref)},
                    'unchanged_method_fields': ['confirmation', 'dataset', 'comparison', 'target_timeout_seconds',
                        'resource_display', 'execution_policy', 'per_arm_review_requirements', 'fixture_sources', 'limits']}
        bundle = {'schema_version': 1, 'kind': 'phase6_linux_count_root_input_bundle_v1',
                  'expected_source_revision': C.SOURCE, 'root_validated_actual_evidence': True,
                  'candidate_prerequisites': refs, 'r3_schemas': schemas}
        bundle_ref = write(self.base / 'root-bundle.json', bundle)
        patches = {'PRIOR': roots['prior'], 'NATIVE': roots['native'], 'FOUNDATION': roots['foundation'],
                   'HERE': roots['integration'], 'COHORT': roots['cohort'], 'RAW_BASE': roots['raw'],
                   'POLICY': roots['integration'] / 'source-plan.json'}
        return roots, policy, baseline, bundle_ref, patches

    def test_synthetic_prepare_copies_only_new_pending_and_publishes_last(self):
        roots, policy, baseline, bundle, patches = self.synthetic_packet()
        with mock.patch.object(P, 'C', C), mock.patch.multiple(C, **patches), \
             mock.patch.object(C, 'load_policy', return_value=(policy, baseline)):
            result = P.prepare(bundle['path'], bundle['sha256'])
            self.assertEqual(result['status'], 'prepared_only')
            self.assertFalse(result['root_go'])
            self.assertFalse(result['baseline_tests_executed_as_v2'])
            self.assertEqual(C.read(roots['cohort'] / 'preparation.json'), result)
            self.assertEqual((roots['cohort'] / 'inner.py').read_bytes(), (roots['native'] / 'inner.py').read_bytes())
            self.assertEqual((roots['cohort'] / 'test_source.py').read_bytes(), (roots['prior'] / 'test_source.py').read_bytes())
            self.assertEqual(len(result['inputs']), 11)
            for arm in C.ARMS:
                pending = C.read(result['pending'][arm['run_name']]['path'])
                C.method(pending)
                self.assertFalse(pending['root_go'])
                self.assertFalse((roots['cohort'] / (arm['run_name'] + '.execution.json')).exists())
            self.assertFalse((roots['cohort'] / 'integration-manifest.json').exists())
            with self.assertRaises(ValueError):
                P.prepare(bundle['path'], bundle['sha256'])

    def test_prepare_source_drift_refuses_without_terminal(self):
        roots, policy, baseline, bundle, patches = self.synthetic_packet()
        original = C.write_exclusive
        def drifting(path, data):
            reference = original(path, data)
            if Path(path).name == 'process-only-method.plan.json':
                (roots['native'] / 'inner.py').write_bytes(b'synthetic changed source')
            return reference
        with mock.patch.object(P, 'C', C), mock.patch.multiple(C, **patches), \
             mock.patch.object(C, 'load_policy', return_value=(policy, baseline)), \
             mock.patch.object(C, 'write_exclusive', side_effect=drifting):
            with self.assertRaises(ValueError):
                P.prepare(bundle['path'], bundle['sha256'])
        self.assertFalse((roots['cohort'] / 'preparation.json').exists())

    def test_prepare_terminal_link_failure_has_no_fallback_or_retry(self):
        roots, policy, baseline, bundle, patches = self.synthetic_packet()
        with mock.patch.object(P, 'C', C), mock.patch.multiple(C, **patches), \
             mock.patch.object(C, 'load_policy', return_value=(policy, baseline)), \
             mock.patch.object(C.os, 'link', side_effect=PermissionError('synthetic no-overwrite publication failure')) as link:
            with self.assertRaises(PermissionError):
                P.prepare(bundle['path'], bundle['sha256'])
            self.assertEqual(link.call_count, 1)
            self.assertTrue((roots['cohort'] / 'preparation.pending.json').exists())
            self.assertFalse((roots['cohort'] / 'preparation.json').exists())
            with self.assertRaises(ValueError):
                P.prepare(bundle['path'], bundle['sha256'])
            self.assertEqual(link.call_count, 1)

    def test_terminal_publication_is_the_last_fallible_operation(self):
        tree = ast.parse((HERE / 'prepare_packet.py').read_text(encoding='utf-8'))
        function = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'prepare')
        self.assertEqual(ast.unparse(function.body[-2].value.func), 'C.os.link')
        self.assertIsInstance(function.body[-1], ast.Return)
        self.assertIsInstance(function.body[-1].value, ast.Name)
        main = next(n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == 'main')
        self.assertNotIn('print(', ast.unparse(main))

    def test_synthetic_prepared_manifest_locks_all_sources_and_method_plan_copy(self):
        roots, policy, baseline, bundle, patches = self.synthetic_packet()
        with mock.patch.object(P, 'C', C), mock.patch.multiple(C, **patches), \
             mock.patch.object(C, 'load_policy', return_value=(policy, baseline)):
            result = P.prepare(bundle['path'], bundle['sha256'])
            manifest = {'schema_version': 1, 'kind': 'phase6_F2_process_only_integration_manifest',
                        'source_revision': C.SOURCE, 'observer_method': C.METHOD, 'thread_context_switch_collection': C.COLLECTION,
                        'policy': C.record(C.POLICY), 'sources': result['sources_after'], 'plan': result['plan'],
                        'preparation': C.record(roots['cohort'] / 'preparation.json'), 'pending': result['pending'],
                        'prerequisites': result['candidate_prerequisites'], 'r3_schemas': result['r3_schemas']}
            reference = write(roots['cohort'] / 'integration-manifest.json', manifest)
            loaded, plan = C.load_manifest(reference['path'], reference['sha256'])
            self.assertEqual(loaded, manifest)
            C.method(plan)
            write(roots['cohort'] / 'process-only-method.plan.json', b'changed synthetic copy')
            with self.assertRaises(ValueError):
                C.load_manifest(reference['path'], reference['sha256'])

    def test_synthetic_one_arm_changes_only_GO_and_never_executes_or_advances(self):
        cohort = self.base / 'cohort'
        cohort.mkdir()
        arm = C.ARMS[0]
        identity = {'observer_method': C.METHOD, 'thread_context_switch_collection': C.COLLECTION}
        pending = {**identity, **arm, 'root_go': False, 'performance_eligible': False, 'synthetic_only': True}
        pending_ref = write(cohort / (arm['run_name'] + '.pending.json'), pending)
        manifest_ref = write(cohort / 'integration-manifest.json', {'synthetic': True})
        root = {**identity, 'schema_version': 1, 'kind': 'phase6_F2_process_only_root_once_review',
                'source_revision': C.SOURCE, 'arm': arm, 'manifest': manifest_ref, 'pending': pending_ref,
                'prior_arms': [], 'root_once_statement': f"Authorize {arm['run_name']} once; no retry, replacement or next arm.",
                'root_scheduling_statement': 'Synthetic declaration; not a quiet certificate.', 'performance_eligible': False}
        root_ref = write(self.base / 'root-review.json', root)
        outer = types.SimpleNamespace(host_activity=mock.Mock(return_value={'compiler_processes': []}))
        with mock.patch.object(C, 'COHORT', cohort), \
             mock.patch.object(C, 'sys', types.SimpleNamespace(platform='linux', dont_write_bytecode=True)), \
             mock.patch.object(C, 'os', types.SimpleNamespace(name='posix', fsync=lambda unused: None)), \
             mock.patch.object(C, 'load_manifest', return_value=({'pending': {arm['run_name']: pending_ref}}, {})), \
             mock.patch.object(C, 'validate_outer', return_value=outer) as validate, \
             mock.patch.object(C, 'require_prefix') as prefix, mock.patch.object(C, 'collect_names', return_value={'synthetic': True}), \
             mock.patch.object(C.time, 'sleep'):
            result = C.authorize(1, root_ref['path'], root_ref['sha256'])
            self.assertEqual(C.read(result['execution']['path']), {**pending, 'root_go': True})
            self.assertEqual(outer.host_activity.call_count, 3)
            self.assertEqual(validate.call_count, 1)
            self.assertFalse(result['outer_started'])
            self.assertFalse(result['next_arm_authorized'])
            self.assertTrue(all(call.args == (1,) for call in prefix.call_args_list))
            with self.assertRaises(ValueError):
                C.authorize(1, root_ref['path'], root_ref['sha256'])

    def test_current_method_does_not_relax_original_private_cleanup(self):
        receipt = {'status': 'passed', 'exit_code': 0}
        report = {'status': 'passed', 'cleanup': {
                    'target': {'exit_code': 0, 'pidfd_exited': True, 'forced': False},
                    'webdriver': {'exit_code': -15, 'pidfd_exited': True, 'forced': False},
                    'desktop_pidfd_exit': True, 'wm_exit_code': 0, 'errors': []},
                  'paste_prerequisite': {'exit_code': 0, 'native_input_generated': False}}
        keeper = {'status': 'passed', 'exit_code': 0, 'forced_cleanup': [], 'remaining': []}
        ss = {'status': 'passed', 'command_exit_code': 0, 'helper_unchanged': True,
              'processes': [{'exit_code': 0, 'stopped': True}, {'exit_code': 0, 'stopped': True}]}
        C.validate_cleanup(receipt, report, keeper, ss)
        for key, value in [('desktop_pidfd_exit', False), ('errors', ['error'])]:
            changed = copy.deepcopy(report)
            changed['cleanup'][key] = value
            with self.assertRaises(ValueError):
                C.validate_cleanup(receipt, changed, keeper, ss)
        with self.assertRaises(ValueError):
            C.validate_cleanup(receipt, report, {**keeper, 'remaining': [77]}, ss)

    def test_aggregate_requires_all_four_and_no_thread_counter_substitution(self):
        arms = [{'arm': arm['run_name'], 'renderer': arm['renderer'], 'observer_method': C.METHOD,
                 'thread_context_switch_collection': C.COLLECTION, 'latencies': list(range(30)),
                 'states': {state: {'pss': [2] * 960, 'uss': [1] * 960, 'metric': process_metric()}
                            for state in ('visible', 'hidden')}} for arm in C.ARMS]
        result = S.aggregate(arms)
        self.assertEqual(result['tauri']['warm_activation_proxy_ms']['count'], 60)
        self.assertIsNone(result['mygo']['resources']['hidden']['observed_thread_context_switch_delta'])
        for wrong in (arms[:3], [arms[1], arms[0], *arms[2:]]):
            with self.assertRaises(ValueError):
                S.aggregate(wrong)
        missing = copy.deepcopy(arms)
        missing[0]['states']['visible']['pss'].pop()
        with self.assertRaises(ValueError):
            S.aggregate(missing)
        unstable = copy.deepcopy(arms)
        unstable[0]['states']['visible']['metric']['stable_process_membership'] = False
        with self.assertRaises(AssertionError):
            S.aggregate(unstable)

    def test_no_product_runner_or_automatic_next_arm_in_sources(self):
        for name in C.INTEGRATION - {'source-plan.json', 'test_integration.py'}:
            tree = ast.parse((HERE / name).read_text(encoding='utf-8'))
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    self.assertFalse({'subprocess', 'ctypes'} & {x.name for x in node.names})
                if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
                    self.assertNotIn(node.func.attr, {'Popen', 'system', 'spawnv', 'sandbox', 'keeper'})
        self.assertEqual(C.REVIEW_KIND, 'phase6_F2_process_only_independent_raw_review')
        self.assertNotEqual(C.RAW_REVIEW, 'passed_limited_independent_raw_consistency')


if __name__ == '__main__':
    unittest.main(verbosity=2)

"""Aggregate only four new reviewed process-only arms; never pass Phase 6."""
import argparse
import importlib.util
import json
import math
from pathlib import Path

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('process_only_summary_helpers', HERE / 'authorize_arm.py')
C = importlib.util.module_from_spec(spec)
spec.loader.exec_module(C)


def summary(values):
    values = sorted(values)
    assert values and all(type(value) in (int, float) and math.isfinite(value) for value in values)
    return {'count': len(values), 'min': values[0], 'max': values[-1], 'mean': sum(values) / len(values),
            'p50': values[math.ceil(len(values) * .5) - 1], 'p95': values[math.ceil(len(values) * .95) - 1]}


def check_summary(actual, values):
    expected = summary(values)
    assert set(actual) == set(expected)
    assert all(math.isclose(actual[key], expected[key], rel_tol=1e-12, abs_tol=1e-9) for key in expected)


def weighted_cpu(metrics):
    assert all(metric['stable_process_membership'] is True for metric in metrics)
    hz = {metric['cpu_clock_ticks_per_second'] for metric in metrics}
    assert len(hz) == 1
    hz = hz.pop()
    assert type(hz) is int and hz > 0
    clocks = [metric['cpu_counter_normalization'] for metric in metrics]
    ticks = sum(clock['counter_delta_ticks'] for clock in clocks)
    twice_interval = sum(clock['twice_nominal_interval_ns'] for clock in clocks)
    minimum = sum(clock['interval_min_ns'] for clock in clocks)
    maximum = sum(clock['interval_max_ns'] for clock in clocks)
    assert 0 < minimum <= twice_interval / 2 <= maximum and ticks >= 0
    return {'counter_delta_ticks': ticks, 'ticks_per_second': hz,
            'sum_twice_nominal_intervals_ns': twice_interval,
            'nominal_percent_one_core': ticks * 2e11 / (hz * twice_interval),
            'read_window_normalization_percent_range': [ticks * 1e11 / (hz * maximum), ticks * 1e11 / (hz * minimum)],
            'scope': 'Duration-weighted disjoint first/last counter-read intervals. Not elapsed-window/tail CPU, a common-time family bound, tick-quantization bound or statistical confidence interval.'}


def process_metric(value):
    C.method(value)
    C.require(all(value[key] is None for key in ('stable_thread_membership', 'observed_thread_context_switch_delta', 'wakeup_count')),
              'Uncollected thread/context/wakeup metrics must be null, never zero/false')


def aggregate(arms):
    C.require(type(arms) is list and len(arms) == 4 and
              [a['arm'] for a in arms] == [a['run_name'] for a in C.ARMS] and
              [a['renderer'] for a in arms] == ['tauri', 'mygo', 'mygo', 'tauri'], 'Complete new ordered ABBA required')
    groups = {name: {'latencies': [], 'states': {state: {'pss': [], 'uss': [], 'metrics': []}
              for state in ('visible', 'hidden')}} for name in ('tauri', 'mygo')}
    for arm in arms:
        C.method(arm)
        C.require(len(arm['latencies']) == 30, 'Thirty original formal samples per arm required')
        group = groups[arm['renderer']]
        group['latencies'].extend(arm['latencies'])
        for state in ('visible', 'hidden'):
            value = arm['states'][state]
            C.require(len(value['pss']) == len(value['uss']) == 960, 'All original 960 captures required')
            process_metric(value['metric'])
            for key in ('pss', 'uss'):
                group['states'][state][key].extend(value[key])
            group['states'][state]['metrics'].append(value['metric'])
    result = {}
    for renderer, group in groups.items():
        assert len(group['latencies']) == 60
        result[renderer] = {'warm_activation_proxy_ms': summary(group['latencies']), 'resources': {}}
        for state, values in group['states'].items():
            assert len(values['pss']) == len(values['uss']) == 1920 and len(values['metrics']) == 2
            result[renderer]['resources'][state] = {'empirical_snapshot_pss_kib': summary(values['pss']),
                'empirical_snapshot_uss_kib': summary(values['uss']), 'cpu_counter_interval': weighted_cpu(values['metrics']),
                'stable_thread_membership': None, 'observed_thread_context_switch_delta': None, 'wakeup_count': None,
                'thread_context_switch_collection': C.COLLECTION}
    return result


def summarize(root_path, root_sha):
    C.require(C.record(root_path)['sha256'] == root_sha, 'Exact final Root decision required')
    root = C.read(root_path)
    C.require(set(root) == {'schema_version', 'kind', 'source_revision', 'observer_method', 'thread_context_switch_collection',
              'manifest', 'arms', 'performance_eligible', 'phase6_passed'} and type(root['schema_version']) is int and
              root['schema_version'] == 1 and root['kind'] == 'phase6_F2_process_only_summary_review' and
              root['source_revision'] == C.SOURCE and root['performance_eligible'] is False and
              root['phase6_passed'] is False and type(root['arms']) is list and len(root['arms']) == 4,
              'Separate new complete-cohort review required')
    C.method(root)
    ref = C.verify(root['manifest'], C.COHORT / 'integration-manifest.json')
    manifest, plan = C.load_manifest(ref['path'], ref['sha256'])
    C.require_prefix(5)
    output_path = C.COHORT / 'comparison-process-only-v2.limited-descriptive.json'
    C.require(not output_path.exists() and not output_path.is_symlink(), 'Existing or partial summary is retained')
    originals, collected = [], []
    for arm, binding in zip(C.ARMS, root['arms']):
        assessment, review = C.validate_prior(binding, arm, ref)
        execution = C.read(assessment['execution']['path'])
        C.require(execution['inputs'] == plan['inputs'], 'One unchanged eleven-input set required')
        raw = C.RAW_BASE / arm['run_name']
        report = C.read(raw / 'functional/performance.json')
        C.require(report['status'] == 'passed' and len(report['warmup']) == 5 and len(report['samples']) == 30, 'Complete original arm required')
        values = [item['activation_proxy_ms'] for item in report['samples']]
        check_summary(assessment['warm_activation_proxy_ms'], values)
        states = {}
        for state in ('visible', 'hidden'):
            rows = [C.parse(line) for line in C.bytes_at(raw / ('functional/resources-' + state + '.jsonl')).splitlines()]
            C.require(len(rows) == 960, 'All original resource rows required')
            for row in rows:
                C.method(row)
                C.require(row['context_switches'] is None, 'Context switches must remain uncollected')
                for member in row['members']:
                    C.method(member)
                    C.require(member['threads'] is None, 'No thread identities or counters may be substituted')
            metric = assessment['verified_resources'][state]
            process_metric(metric)
            check_summary(metric['pss_kib'], [row['pss_kib'] for row in rows])
            check_summary(metric['uss_kib'], [row['uss_kib'] for row in rows])
            states[state] = {'pss': [r['pss_kib'] for r in rows], 'uss': [r['uss_kib'] for r in rows], 'metric': metric}
        collected.append({'arm': arm['run_name'], 'renderer': arm['renderer'], 'observer_method': C.METHOD,
                          'thread_context_switch_collection': C.COLLECTION, 'latencies': values, 'states': states})
        originals.append({'arm': arm['run_name'], 'renderer': arm['renderer'], **binding,
                          'raw_evidence': assessment['raw_evidence'], 'resources': assessment['verified_resources'],
                          'warm_activation_proxy_ms': assessment['warm_activation_proxy_ms']})
    variants = aggregate(collected)
    C.load_manifest(ref['path'], ref['sha256'])
    C.require(C.record(root_path)['sha256'] == root_sha, 'Root final review changed')
    for arm, binding in zip(C.ARMS, root['arms']):
        C.validate_prior(binding, arm, ref)
    result = {'kind': 'complete_F2_process_only_v2_limited_comparison', 'status': 'completed_limited_process_only_consistency',
              'source_revision': C.SOURCE, 'observer_method': C.METHOD, 'thread_context_switch_collection': C.COLLECTION,
              'performance_eligible': False, 'phase6_passed': False, 'phase7_authorized': False, 'next_arm_authorized': False,
              'whole_host_idle': None, 'quiet_window': None, 'performance_acceptance': None,
              'context_switches': None, 'wakeup_count': None, 'integration_manifest': ref,
              'root_final_review': C.record(root_path), 'summarizer': C.record(Path(__file__).resolve()),
              'inputs': plan['inputs'], 'arms_in_execution_order': originals, 'variants': variants,
              'limits': ['Only four fresh process-only arms; old failed count-v1 A1 remains failed and contributes no samples.',
                         'Thread/context counters were not collected and are null, not zero, not wakeup measurements.',
                         'Unchanged process CPU read-window arithmetic; snapshot distributions are correlated and not equal-time means.',
                         'Windows host metadata/whole-host quiet/GPU/first-interactive/search/IME/DPI/multimonitor remain unverified.',
                         'Descriptive consistency only; no adoption, Phase6/Phase7 or statistical-significance qualification.']}
    return C.save(output_path, result)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root-review', required=True)
    parser.add_argument('--root-review-sha256', required=True)
    args = parser.parse_args()
    print(json.dumps({'output': summarize(args.root_review, args.root_review_sha256)}))


if __name__ == '__main__':
    main()

"""Authorize one new process-only arm; never launch a fixture or advance an arm."""
import argparse
import copy
import errno
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import sys
import time

HERE = Path(__file__).resolve().parent
HARNESS = HERE.parent
COHORT = HARNESS / 'phase6-linux-count-process-only-v2-1fe685c-20261102'
FOUNDATION = HARNESS / 'phase6-linux-recovery-20261028'
PRIOR = HARNESS / 'phase6-linux-count-observer-v1-5d6-20261030'
NATIVE = HARNESS / 'phase6-linux-process-only-v2-method-20261102'
BASE_POLICY = HARNESS / 'phase6-linux-count-prepare-1fe685c-20261102/source-plan.json'
BASE_POLICY_SHA = 'cc3922225451d5c1ae742e10ce8b364890b78104a2a3266eb487bc7ff0915c82'
POLICY = HERE / 'source-plan.json'
POLICY_SHA = 'fc29660de7f582e70d9d613ce09fe262d5a8b227ae87fdf378063150df195c7d'
SOURCE = '1fe685c424602b2bc1892f1deb0794c2e0b90ad5'
METHOD = 'process-resource-only-v2'
COLLECTION = 'not_collected'
RAW_BASE = Path('/home/qiyuaner/.cache/dezirclip-v02/phase6-performance-recovered') / SOURCE
ARMS = tuple({'arm_index': i, 'renderer': renderer, 'run_name': f'process-v2-1fe685c-{i}-{renderer}'}
             for i, renderer in enumerate(('tauri', 'mygo', 'mygo', 'tauri'), 1))
ASSESSMENT_KIND = 'phase6_count_paced_process_only_arm_assessment'
LIMITED = 'passed_limited_process_only_consistency'
REVIEW_KIND = 'phase6_F2_process_only_independent_raw_review'
RAW_REVIEW = 'passed_limited_independent_process_only_raw_consistency'
INTEGRATION = {'authorize_arm.py', 'postflight_arm.py', 'summarize_descriptive.py',
               'prepare_packet.py', 'test_integration.py', 'source-plan.json'}
NATIVE_FILES = {'inner.py', 'assess_descriptive.py', 'test_process_only.py', 'source-plan.json'}
INPUTS = {'desktop', 'helper', 'desktop_proof', 'helper_proof', 'private_ss_helper', 'webkit_driver',
          'python', 'quiet_window_note', 'screenshot_tool', 'paste_tool', 'paste_tool_proof'}
PREREQUISITES = {'input_provenance', 'original19_assessment', 'original19_independent_review',
                 'idle_R3_assessment', 'idle_R3_independent_review'}
R3_KINDS = {'root': 'phase6-linux-F2-focused-idle-R3-completed-assessment',
            'peer': 'phase6-linux-F2-focused-idle-R3-independent-review'}
R3_PHASES = ['real-ewmh-wm', 'actual-native-surface-identity', 'actual-desktop-identity',
             'actual-private-data-path', 'real-host-seed-ten', 'first-native-show', 'actual-initial-hide',
             'idle-before-real-registered-hotkey', 'same-original-helper-after-idle-hotkey',
             'idle-recovery-query-and-one-enter', 'idle-before-normal-disable',
             'normal-disable-confirms-original-helper-exit', 'owner-history-retained']
RAW_CHECKS = {'original_bytes', 'all_raw_evidence', 'input_and_source_identity', 'six_namespaces',
              'native_focus_and_paste', 'qualifications_and_replies', 'original_process_identities',
              'all_capture_rows_and_clocks', 'process_counter_math', 'thread_metrics_not_collected',
              'root_actual_png_view', 'private_pidfd_keeper_secret_service_cleanup', 'unverified_host_metadata_limits'}
COMPILERS = frozenset({'cargo', 'rustc', 'rustdoc', 'go', 'cc', 'cc1', 'cc1plus', 'clang', 'clang++',
                      'gcc', 'g++', 'ld', 'ld.lld', 'lld', 'ninja'})
PRODUCTS = frozenset({'dezirclip', 'dzc-surface', 'WebKitWebDriver'})
DISPLAY = frozenset({'Xvfb', 'marco'})
PROC = Path('/proc')
MAX_FILE = 128 * 1024 * 1024
MAX_JSON = 4 * 1024 * 1024


def require(value, message):
    if not value:
        raise ValueError(message)


def absolute(path):
    path = Path(path)
    require(path.is_absolute() and not any(p.is_symlink() for p in (path, *path.parents)),
            'Absolute path without symlinks required')
    return path


def bytes_at(path, maximum=MAX_FILE):
    path = absolute(path)
    require(path.is_file(), 'Regular original file required')
    before = path.stat()
    require(0 <= before.st_size <= maximum, 'Bounded file required')
    with path.open('rb') as stream:
        data = stream.read(maximum + 1)
    after = path.stat()
    require(len(data) == before.st_size <= maximum and
            (before.st_dev, before.st_ino, before.st_size, before.st_mtime_ns) ==
            (after.st_dev, after.st_ino, after.st_size, after.st_mtime_ns), 'File changed during read')
    return data


def record(path):
    path = absolute(path)
    data = bytes_at(path)
    return {'path': str(path), 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}


def parse(data):
    def pairs(items):
        result = {}
        for key, value in items:
            require(key not in result, 'Duplicate JSON key')
            result[key] = value
        return result
    def constant(value):
        raise ValueError('Nonfinite JSON: ' + value)
    return json.loads(data, object_pairs_hook=pairs, parse_constant=constant)


def read(path):
    return parse(bytes_at(path, MAX_JSON))


def verify(value, path=None):
    require(type(value) is dict and set(value) == {'path', 'bytes', 'sha256'} and
            type(value['path']) is str and type(value['bytes']) is int and 0 <= value['bytes'] <= MAX_FILE and
            type(value['sha256']) is str and re.fullmatch('[0-9a-f]{64}', value['sha256']), 'Exact file record required')
    require(path is None or value['path'] == str(absolute(path)), 'Original path differs')
    require(record(value['path']) == value, 'Original bytes differ')
    return value


def encoded(value):
    return (json.dumps(value, indent=2, ensure_ascii=True, allow_nan=False) + '\n').encode('utf-8')


def write_exclusive(path, data):
    path = absolute(path)
    with path.open('xb') as stream:
        require(stream.write(data) == len(data), 'Short exclusive write')
        stream.flush()
        os.fsync(stream.fileno())
    require(bytes_at(path) == data, 'Exclusive write readback differs')
    return record(path)


def save(path, value):
    data = encoded(value)
    require(len(data) <= MAX_JSON, 'JSON output bound exceeded')
    return write_exclusive(path, data)


def arm_at(number):
    require(type(number) is int and 1 <= number <= 4, 'One explicit new ABBA arm required')
    return ARMS[number - 1]


def method(value):
    require(value['observer_method'] == METHOD and value['thread_context_switch_collection'] == COLLECTION,
            'Explicit process-only v2 identity required')


def windows(arm, stage):
    require(stage in ('preflight', 'postflight'), 'Exact metadata stage required')
    return {'schema_version': 1, 'kind': 'phase6_windows_host_unverified', 'source_revision': SOURCE,
            'arm': arm, 'stage': stage, 'collection_status': 'unverified_no_local_WinAPI',
            'known_compiler_names': None, 'compiler_processes': None, 'native_names': None,
            'host_idle': None, 'observation_performed': False, 'quiet_window_certified': False}


def collect_names():
    require(sys.platform == 'linux' and os.name == 'posix', 'Linux proc observation only')
    entries = list(PROC.iterdir())
    require(len(entries) <= 32768, 'Bounded proc-name snapshot required')
    compiler, product, display, vanished, inspected = [], [], [], 0, 0
    for directory in sorted(entries, key=lambda item: item.name):
        if not directory.name.isdigit():
            continue
        try:
            with (directory / 'comm').open('rb') as stream:
                raw = stream.read(257)
            require(len(raw) <= 256, 'Process-name bound exceeded')
        except OSError as error:
            if error.errno == errno.ENOENT:
                vanished += 1
                continue
            raise
        inspected += 1
        name = raw.strip()
        item = {'pid': int(directory.name), 'name': name.decode('ascii', errors='replace')}
        if name in {value.encode('ascii') for value in COMPILERS}:
            compiler.append(item)
        if name in {value.encode('ascii') for value in PRODUCTS}:
            product.append(item)
        if name in {value.encode('ascii') for value in DISPLAY}:
            display.append({**item, 'source_status': 'unverified', 'operated': False})
    require(not compiler and not product and len(display) <= 64, 'Active compiler/product or oversized display observation')
    return {'collection_status': 'observed_linux_proc_names_only', 'compiler_processes': compiler,
            'known_product_processes': product, 'observed_display_services': display, 'host_idle': None,
            'inspected_process_names': inspected, 'vanished_before_name_read': vanished}


def load_policy():
    require(type(POLICY_SHA) is str and re.fullmatch('[0-9a-f]{64}', POLICY_SHA),
            'Policy is unfrozen; real preparation and authorization are forbidden')
    require(record(POLICY)['sha256'] == POLICY_SHA, 'Reviewed v2 policy changed')
    value = read(POLICY)
    require(value['source_revision'] == SOURCE and value['observer_method'] == METHOD and
            value['thread_context_switch_collection'] == COLLECTION, 'Wrong policy identity')
    require(type(value['native_pins']) is dict and set(value['native_pins']) == NATIVE_FILES and
            all(type(pin) is dict and set(pin) == {'bytes', 'sha256'} and type(pin['bytes']) is int and
                pin['bytes'] > 0 and type(pin['sha256']) is str and re.fullmatch('[0-9a-f]{64}', pin['sha256'])
                for pin in value['native_pins'].values()), 'Native proposal is unfrozen')
    require(record(BASE_POLICY)['sha256'] == BASE_POLICY_SHA, 'Original inventory policy changed')
    baseline = read(BASE_POLICY)
    require(set(value['method_pins']) == set(baseline['method_pins']) and
            value['foundation_pins'] == baseline['foundation_pins'] and
            all(value['method_pins'][name] == pin for name, pin in baseline['method_pins'].items() if name != 'inner.py') and
            value['method_pins']['inner.py'] == value['native_pins']['inner.py'],
            'Only the inner observer may change in the original sixteen-source inventory')
    return value, baseline


def snapshot(policy, prepared):
    result = {'method': {}, 'foundation': {}, 'native': {}, 'integration': {}}
    for name, pin in policy['method_pins'].items():
        path = COHORT / name if prepared else (NATIVE if name == 'inner.py' else PRIOR) / name
        actual = record(path)
        require({key: actual[key] for key in ('bytes', 'sha256')} == pin, 'Method source changed: ' + name)
        result['method'][name] = actual
    for name, pin in policy['foundation_pins'].items():
        actual = record(FOUNDATION / name)
        require({key: actual[key] for key in ('bytes', 'sha256')} == pin, 'Foundation source changed: ' + name)
        result['foundation'][name] = actual
    for name, pin in policy['native_pins'].items():
        actual = record(NATIVE / name)
        require({key: actual[key] for key in ('bytes', 'sha256')} == pin, 'Native method proposal changed: ' + name)
        result['native'][name] = actual
    require(set(policy['integration_files']) == INTEGRATION, 'Exactly six integration sources required')
    for name in INTEGRATION:
        result['integration'][name] = record(HERE / name)
    if prepared:
        for name in ('assess_descriptive.py', 'test_process_only.py'):
            copied = record(COHORT / name)
            require({key: copied[key] for key in ('bytes', 'sha256')} == policy['native_pins'][name],
                    'Copied v2 assessor/tests changed')
        copied_plan = record(COHORT / 'process-only-method.plan.json')
        require({key: copied_plan[key] for key in ('bytes', 'sha256')} == policy['native_pins']['source-plan.json'],
                'Copied native method policy changed')
    return result


def completed(value, stages, key, kind, four, phases):
    require(type(value) is dict and value.get('status') == 'passed' and value.get('source_revision') == SOURCE and
            type(value.get('actual_stages')) is int and value['actual_stages'] == stages and
            (kind is None or value.get('kind') == kind), 'Actual prerequisite must have passed for exact F2')
    require(type(value.get(key)) is dict and {name: value[key][name] for name in four} == four,
            'Actual prerequisite product/proof inputs differ')
    if stages == 13:
        require(kind in R3_KINDS.values(), 'Known actual R3 schema required')
        orders = []
        if 'phases' in value:
            require(type(value['phases']) is list and len(value['phases']) == 13 and
                    all(type(item) is dict and type(item.get('name')) is str for item in value['phases']),
                    'Thirteen named R3 dictionaries required')
            orders.append([item['name'] for item in value['phases']])
        if 'phase_names' in value:
            require(type(value['phase_names']) is list and len(value['phase_names']) == 13 and
                    all(type(name) is str for name in value['phase_names']), 'Thirteen R3 phase strings required')
            orders.append(value['phase_names'])
        require(('phases' if kind == R3_KINDS['root'] else 'phase_names') in value and orders and
                all(order == R3_PHASES for order in orders), 'Every actual R3 order must match the frozen prerequisite')
    else:
        require(value.get('phase_names') == phases and type(value['phase_names']) is list and
                len(phases) == len(set(phases)) == stages, 'Actual nineteen-stage order differs')


def prerequisites(refs, schemas, inputs, baseline):
    require(type(refs) is dict and set(refs) == PREREQUISITES and len({x['path'] for x in refs.values()}) == 5,
            'Five distinct original actual prerequisites required')
    for name, item in refs.items():
        verify(item)
        if name in baseline['fixed_prerequisites']:
            require(item == baseline['fixed_prerequisites'][name], 'Original F2 binding differs')
    four = {name: inputs[name] for name in ('desktop', 'helper', 'desktop_proof', 'helper_proof')}
    provenance = read(refs['input_provenance']['path'])
    require(provenance['expected'] == baseline['expected'] and provenance['inputs'] == four, 'Original F2 supplier pair required')
    completed(read(refs['original19_assessment']['path']), 19, 'input_pair_and_dependencies', None,
              four, baseline['actual19_phase_names'])
    completed(read(refs['original19_independent_review']['path']), 19, 'original_inputs',
              'phase6-linux-F2-actual19-independent-review', four, baseline['actual19_phase_names'])
    require(type(schemas) is dict and set(schemas) == {'root', 'peer'}, 'Two actual R3 schemas required')
    for role, name in [('root', 'idle_R3_assessment'), ('peer', 'idle_R3_independent_review')]:
        schema = schemas[role]
        require(type(schema) is dict and set(schema) == {'kind', 'inputs_key'} and schema['kind'] == R3_KINDS[role] and
                schema['inputs_key'] in ('runtime_input_pair', 'original_inputs', 'input_pair_and_dependencies'), 'R3 schema differs')
        completed(read(refs[name]['path']), 13, schema['inputs_key'], schema['kind'], four, R3_PHASES)


def load_manifest(path, sha):
    policy, baseline = load_policy()
    require(record(path)['sha256'] == sha, 'Exact Root-selected manifest required')
    value = read(path)
    require(set(value) == {'schema_version', 'kind', 'source_revision', 'observer_method',
            'thread_context_switch_collection', 'policy', 'sources', 'plan', 'preparation', 'pending',
            'prerequisites', 'r3_schemas'}, 'Exact v2 manifest shape required')
    require(type(value['schema_version']) is int and value['schema_version'] == 1 and
            value['kind'] == 'phase6_F2_process_only_integration_manifest' and value['source_revision'] == SOURCE,
            'Fresh process-only manifest required')
    method(value)
    verify(value['policy'], POLICY)
    require(value['sources'] == snapshot(policy, True), 'All16+4+6 source records must match')
    verify(value['plan'], COHORT / 'comparison-count-v1.plan.json')
    verify(value['preparation'], COHORT / 'preparation.json')
    plan, preparation = read(value['plan']['path']), read(value['preparation']['path'])
    method(plan)
    method(preparation)
    require(preparation['kind'] == 'phase6_process_only_v2_source_preparation' and
            preparation['status'] == 'prepared_only' and preparation['source_revision'] == SOURCE and preparation['root_go'] is False and
            preparation['performance_eligible'] is False and preparation['native_executed'] is False and
            preparation['plan'] == value['plan'] and preparation['sources_after'] == value['sources'],
            'Completed source-only v2 preparation required')
    require(plan['expected'] == baseline['expected'] and plan['arms'] == list(ARMS) and
            all(type(arm['arm_index']) is int for arm in plan['arms']) and
            plan['root_go'] is False and plan['performance_eligible'] is False and set(plan['inputs']) == INPUTS,
            'Only the new false-GO eleven-input plan is accepted')
    for item in plan['inputs'].values():
        verify(item)
    require(set(value['pending']) == {arm['run_name'] for arm in ARMS}, 'Four new pending originals required')
    for arm in ARMS:
        item = value['pending'][arm['run_name']]
        verify(item, COHORT / (arm['run_name'] + '.pending.json'))
        require(read(item['path']) == {**plan, **arm}, 'Original pending differs')
    require(plan['candidate_prerequisites'] == value['prerequisites'], 'Prepared prerequisite records differ')
    prerequisites(value['prerequisites'], value['r3_schemas'], plan['inputs'], baseline)
    return value, plan


def require_prefix(number):
    entries = list(RAW_BASE.iterdir()) if RAW_BASE.exists() else []
    names = sorted(path.name for path in entries if path.name.startswith('process-v2-1fe685c-'))
    require(names == sorted(arm['run_name'] for arm in ARMS[:number - 1]) and
            all((RAW_BASE / name).is_dir() and not (RAW_BASE / name).is_symlink() for name in names),
            'Exactly the fresh completed v2 prefix is required; no retries or replacements')


def validate_cleanup(receipt, report, keeper, ss):
    require(receipt['status'] == report['status'] == keeper['status'] == ss['status'] == 'passed' and
            receipt['exit_code'] == keeper['exit_code'] == ss['command_exit_code'] == 0 and
            'forced_outer_stop' not in receipt and report.get('first_error') is None, 'Original failure retained')
    cleanup = report['cleanup']
    require(cleanup['target'] == {'exit_code': 0, 'pidfd_exited': True, 'forced': False} and
            cleanup['webdriver']['exit_code'] == -15 and cleanup['webdriver']['pidfd_exited'] is True and
            cleanup['webdriver']['forced'] is False and cleanup['desktop_pidfd_exit'] is True and
            cleanup['wm_exit_code'] == 0 and cleanup['errors'] == [] and keeper['forced_cleanup'] == [] and
            keeper['remaining'] == [], 'Private original cleanup incomplete')
    require(len(ss['processes']) == 2 and all(x['exit_code'] == 0 and x['stopped'] is True for x in ss['processes']) and
            ss['helper_unchanged'] is True and report['paste_prerequisite']['exit_code'] == 0 and
            report['paste_prerequisite']['native_input_generated'] is False, 'Private SS/paste cleanup differs')
    return cleanup


def assessor_module():
    policy, unused = load_policy()
    item = record(COHORT / 'assess_descriptive.py')
    require({key: item[key] for key in ('bytes', 'sha256')} == policy['native_pins']['assess_descriptive.py'],
            'Reviewed v2 assessor required before pure-helper import')
    spec = importlib.util.spec_from_file_location('reviewed_process_only_assessor_helpers', COHORT / 'assess_descriptive.py')
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result


def limited(value, status):
    method(value)
    require(value['status'] == status and value['source_revision'] == SOURCE and
            all(value[key] is False for key in ('performance_eligible', 'phase6_passed', 'phase7_authorized', 'next_arm_authorized')) and
            all(value[key] is None for key in ('whole_host_idle', 'quiet_window', 'performance_acceptance')),
            'Only the new limited process-only qualification is accepted')


def validate_prior(binding, arm, manifest_ref):
    require(set(binding) == {'assessment', 'independent_review', 'root_png', 'copy_proof'}, 'Exact previous-arm chain required')
    name, raw = arm['run_name'], RAW_BASE / arm['run_name']
    for key, suffix in [('assessment', 'assessment.json'), ('independent_review', 'independent-raw-review.json'),
                        ('root_png', 'root-png.json'), ('copy_proof', 'setup-copy-proof.json')]:
        verify(binding[key], COHORT / (name + '.' + suffix))
    assessment, review = read(binding['assessment']['path']), read(binding['independent_review']['path'])
    limited(assessment, LIMITED)
    limited(review, RAW_REVIEW)
    required = {'kind', 'status', 'source_revision', 'observer_method', 'thread_context_switch_collection',
                'arm', 'renderer', 'arm_index', 'reviewer_role', 'independent_from_authorizer_and_assessor_author',
                'actual_original_raw_review_completed', 'whole_ABBA_complete', 'checks', 'root_assessment',
                'root_png_evidence', 'setup_copy_proof', 'assessor', 'integration_manifest', 'reviewer_reader',
                'execution', 'raw_evidence', 'whole_host_idle', 'quiet_window', 'performance_acceptance',
                'performance_eligible', 'phase6_passed', 'phase7_authorized', 'next_arm_authorized'}
    require(set(review) == required and review['kind'] == REVIEW_KIND and assessment['kind'] == ASSESSMENT_KIND and
            assessment['arm'] == arm and review['arm'] == name and review['renderer'] == arm['renderer'] and
            type(review['arm_index']) is int and review['arm_index'] == arm['arm_index'] and
            review['reviewer_role'] == 'independent_raw_reviewer' and
            review['independent_from_authorizer_and_assessor_author'] is True and
            review['actual_original_raw_review_completed'] is True and review['whole_ABBA_complete'] is False and
            type(review['checks']) is dict and set(review['checks']) == RAW_CHECKS and
            all(value is True for value in review['checks'].values()), 'Actual independent v2 raw review required')
    require(review['root_assessment'] == binding['assessment'] and review['root_png_evidence'] == binding['root_png'] and
            review['setup_copy_proof'] == binding['copy_proof'] and review['integration_manifest'] == manifest_ref and
            review['assessor'] == assessment['assessor'] == record(COHORT / 'assess_descriptive.py'),
            'Independent review source/proof chain differs')
    verify(review['reviewer_reader'])
    execution_ref = record(COHORT / (name + '.execution.json'))
    require(assessment['execution'] == review['execution'] == execution_ref, 'Original execution differs')
    execution = read(execution_ref['path'])
    require(execution == {**read(COHORT / (name + '.pending.json')), 'root_go': True}, 'Only root_go may change')
    method(execution)
    originals = assessment['raw_evidence']
    paths = {str(p) for p in raw.iterdir() if p.is_file() and p.name != '.native-capture-fixture'}
    paths |= {str(p) for p in (raw / 'functional').iterdir() if p.is_file()}
    paths.add(str(raw / 'functional/private-ss/proof.json'))
    require(type(originals) is list and 0 < len(originals) <= 128 and review['raw_evidence'] == originals and
            len({x['path'] for x in originals}) == len(originals) and {x['path'] for x in originals} == paths,
            'Every original raw record must be independently bound')
    for item in originals:
        verify(item)
    report, runtime = read(raw / 'functional/performance.json'), read(raw / 'runtime.json')
    method(report)
    method(runtime)
    require(runtime['inputs'] == execution['inputs'] and runtime['expected'] == execution['expected'] and
            runtime['comparison'] == execution['comparison'] and execution['expected']['source_revision'] == SOURCE and
            execution['run_name'] == name and execution['arm_index'] == report['arm_index'] == arm['arm_index'] and
            execution['renderer'] == report['renderer'] == arm['renderer'] and report['source_revision'] == SOURCE,
            'Original runtime/arm identity differs')
    keeper, ss = read(raw / 'functional/keeper.json'), read(raw / 'functional/private-ss/proof.json')
    cleanup = validate_cleanup(read(raw / 'receipt.json'), report, keeper, ss)
    helper = assessor_module()
    helper.validate_namespace_binding(report['private_namespaces'], keeper['private_namespaces'], runtime['host_namespaces'])
    proof = read(binding['copy_proof']['path'])
    helper.reject_legacy_host_claims(proof)
    helper.validate_linux_postflight(proof['postflight_linux_scope'], name, SOURCE, cleanup,
                                    record(raw / 'functional/keeper.json'), record(raw / 'functional/private-ss/proof.json'))
    for stage in ('preflight', 'postflight'):
        helper.validate_windows_unverified(read(COHORT / (name + '.' + stage + '-windows.json')), name, SOURCE, stage)
    image = verify(proof['copy'], COHORT / (name + '.setup.png'))
    source_image = verify(proof['source'], raw / 'functional/resource-visible-query.png')
    png = read(binding['root_png']['path'])
    require(proof['sha256_verified_equal'] is True and source_image['sha256'] == image['sha256'] == png['png_sha256'] and
            png['actual_view_completed'] is True and png['reviewer'] == 'Root' and png['status'] == 'passed' and
            png['source_revision'] == SOURCE and png['arm'] == name and png['exact_query'] == 'dzcp6needle7' and
            png['visible_matching_rows'] == 1 and png['full_visible_content'] == 'phase6 record 07 dzcp6needle7 synthetic payload' and
            assessment['root_png_evidence'] == binding['root_png'] and assessment['setup_copy_proof'] == binding['copy_proof'],
            'Actual Root view of the new original PNG required')
    return assessment, review


def validate_outer(execution):
    require('paste_prerequisite' not in sys.modules, 'Cached validator refused')
    original = list(sys.path)
    try:
        sys.path.insert(0, str(COHORT))
        spec = importlib.util.spec_from_file_location('reviewed_v2_original_outer', COHORT / 'outer.py')
        result = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(result)
        require(result.BASE / SOURCE == RAW_BASE and result.FOUNDATION == FOUNDATION, 'Original outer bindings differ')
        result.validate(execution)
        return result
    finally:
        sys.path[:] = original
        sys.modules.pop('paste_prerequisite', None)


def authorize(number, root_path, root_sha):
    require(sys.platform == 'linux' and os.name == 'posix' and sys.dont_write_bytecode, 'Explicit Linux -B only')
    arm = arm_at(number)
    require(record(root_path)['sha256'] == root_sha, 'Exact new Root decision required')
    root = read(root_path)
    require(set(root) == {'schema_version', 'kind', 'source_revision', 'observer_method', 'thread_context_switch_collection',
            'arm', 'manifest', 'pending', 'prior_arms', 'root_once_statement', 'root_scheduling_statement', 'performance_eligible'} and
            type(root['schema_version']) is int and root['schema_version'] == 1 and
            root['kind'] == 'phase6_F2_process_only_root_once_review' and root['source_revision'] == SOURCE and
            type(root['arm']) is dict and type(root['arm'].get('arm_index')) is int and root['arm'] == arm and
            root['performance_eligible'] is False and root['root_once_statement'] ==
            f"Authorize {arm['run_name']} once; no retry, replacement or next arm.", 'New one-arm v2 Root decision required')
    method(root)
    require(type(root['root_scheduling_statement']) is str and 1 <= len(root['root_scheduling_statement']) <= 2048,
            'Bounded current scheduling declaration required; it is not quiet proof')
    ref = verify(root['manifest'], COHORT / 'integration-manifest.json')
    manifest, plan = load_manifest(ref['path'], ref['sha256'])
    require(root['pending'] == manifest['pending'][arm['run_name']] and type(root['prior_arms']) is list and
            len(root['prior_arms']) == number - 1, 'Exact pending and complete prior prefix required')
    require_prefix(number)
    for previous, binding in zip(ARMS[:number - 1], root['prior_arms']):
        validate_prior(binding, previous, ref)
    name = arm['run_name']
    outputs = [COHORT / (name + suffix) for suffix in ('.preflight-windows.json', '.preflight-linux.json',
               '.scheduling.json', '.authorization.json', '.execution.json')]
    require(all(not p.exists() and not p.is_symlink() for p in outputs), 'Old or partial outputs prevent reuse')
    pending = read(root['pending']['path'])
    execution = {**copy.deepcopy(pending), 'root_go': True}
    method(execution)
    outer = validate_outer(execution)
    samples = []
    for i in range(3):
        host = outer.host_activity()
        require(type(host['compiler_processes']) is list and host['compiler_processes'] == [], 'Original compiler gate failed')
        samples.append({'original_host_activity': host, 'strict_proc_names': collect_names()})
        if i < 2:
            time.sleep(1)
    load_manifest(ref['path'], ref['sha256'])
    require_prefix(number)
    require(record(root_path)['sha256'] == root_sha, 'Root decision changed')
    for previous, binding in zip(ARMS[:number - 1], root['prior_arms']):
        validate_prior(binding, previous, ref)
    window = save(outputs[0], windows(name, 'preflight'))
    linux = save(outputs[1], {'source_revision': SOURCE, 'arm': name, 'samples': samples, 'whole_host_idle': None})
    schedule = save(outputs[2], {'source_revision': SOURCE, 'arm': name, 'windows': window, 'linux': linux,
                    'root_scheduling_statement': root['root_scheduling_statement'], 'whole_host_idle': None,
                    'scope': 'Current Root scheduling declaration; observed names/load are not a quiet certification.'})
    authorization = save(outputs[3], {'kind': 'phase6_F2_process_only_one_arm_authorization', 'source_revision': SOURCE,
        'observer_method': METHOD, 'thread_context_switch_collection': COLLECTION, 'arm': arm, 'root_review': record(root_path),
        'manifest': ref, 'pending': root['pending'], 'scheduling': schedule, 'prior_arms': root['prior_arms'],
        'root_go': True, 'performance_eligible': False, 'native_executed_by_authorizer': False, 'next_arm_authorized': False,
        'stop_rule': 'Root separately requires exit0 and execution/auth readback before one original outer launch. Stop after either outcome; never retry or authorize the next arm automatically.'})
    execution_ref = save(outputs[4], execution)
    return {'execution': execution_ref, 'authorization': authorization, 'outer_started': False, 'next_arm_authorized': False}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--arm', type=int, required=True, choices=(1, 2, 3, 4))
    parser.add_argument('--root-review', required=True)
    parser.add_argument('--root-review-sha256', required=True)
    args = parser.parse_args()
    print(json.dumps(authorize(args.arm, args.root_review, args.root_review_sha256)))


if __name__ == '__main__':
    main()

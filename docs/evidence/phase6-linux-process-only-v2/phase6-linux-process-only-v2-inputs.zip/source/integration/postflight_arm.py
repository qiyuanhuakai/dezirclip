"""Read one completed process-only arm and copy its original owned setup PNG."""
import argparse
import importlib.util
import json
from pathlib import Path
import struct

HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('process_only_postflight_helpers', HERE / 'authorize_arm.py')
C = importlib.util.module_from_spec(spec)
spec.loader.exec_module(C)


def complete(number, manifest_path, manifest_sha):
    arm = C.arm_at(number)
    manifest, plan = C.load_manifest(manifest_path, manifest_sha)
    C.require_prefix(number + 1)
    name, raw = arm['run_name'], C.RAW_BASE / arm['run_name']
    outputs = [C.COHORT / (name + suffix) for suffix in
               ('.postflight-windows.json', '.setup.png', '.setup-copy-proof.json')]
    C.require(all(not p.exists() and not p.is_symlink() for p in outputs), 'Old or partial postflight is not reused')
    receipt, runtime = C.read(raw / 'receipt.json'), C.read(raw / 'runtime.json')
    report = C.read(raw / 'functional/performance.json')
    C.method(runtime)
    C.method(report)
    keeper_ref, ss_ref = C.record(raw / 'functional/keeper.json'), C.record(raw / 'functional/private-ss/proof.json')
    keeper, ss = C.read(keeper_ref['path']), C.read(ss_ref['path'])
    cleanup = C.validate_cleanup(receipt, report, keeper, ss)
    execution = C.read(C.COHORT / (name + '.execution.json'))
    C.method(execution)
    C.require(execution == {**C.read(manifest['pending'][name]['path']), 'root_go': True} and
              receipt['runtime_sha256'] == C.record(raw / 'runtime.json')['sha256'] and
              runtime['inputs'] == plan['inputs'] and runtime['expected'] == plan['expected'] and
              runtime['comparison'] == plan['comparison'] and report['source_revision'] == C.SOURCE and
              report['arm_index'] == number and report['renderer'] == arm['renderer'], 'Original completed arm differs')
    helper = C.assessor_module()
    helper.validate_namespace_binding(report['private_namespaces'], keeper['private_namespaces'], runtime['host_namespaces'])
    observation = C.collect_names()
    host = {key: observation[key] for key in ('collection_status', 'compiler_processes',
            'known_product_processes', 'observed_display_services', 'host_idle')}
    scope = {'schema_version': 1, 'kind': 'phase6_linux_postflight_scoped_observation',
             'source_revision': C.SOURCE, 'arm': name, 'host_observation': host,
             'private_cleanup_binding': {'cleanup': cleanup, 'keeper': keeper_ref, 'secret_service': ss_ref}}
    helper.validate_linux_postflight(scope, name, C.SOURCE, cleanup, keeper_ref, ss_ref)
    source = raw / 'functional/resource-visible-query.png'
    pixels = C.bytes_at(source, 8 * 1024 * 1024)
    C.require(len(pixels) >= 24 and pixels[:8] == b'\x89PNG\r\n\x1a\n' and
              struct.unpack('>II', pixels[16:24]) == (480, 360), 'Original 480x360 PNG required')
    source_ref = C.record(source)
    C.require(source_ref['sha256'] == report['resource_query_setup']['screenshot']['sha256'] and
              C.read(raw / 'functional/keeper.json') == keeper and C.read(raw / 'functional/private-ss/proof.json') == ss,
              'Original PNG or private cleanup changed')
    C.load_manifest(manifest_path, manifest_sha)
    window = C.windows(name, 'postflight')
    helper.validate_windows_unverified(window, name, C.SOURCE, 'postflight')
    window_ref = C.save(outputs[0], window)
    copied = C.write_exclusive(outputs[1], pixels)
    C.require(copied['sha256'] == C.record(source)['sha256'] == source_ref['sha256'], 'PNG source/copy/readback differs')
    proof_ref = C.save(outputs[2], {'source': source_ref, 'copy': copied, 'sha256_verified_equal': True,
        'postflight_linux_scope': scope, 'cleanup': cleanup, 'keeper': keeper_ref, 'secret_service': ss_ref,
        'manifest': C.record(manifest_path), 'postflight_windows': window_ref,
        'observer_method': C.METHOD, 'thread_context_switch_collection': C.COLLECTION,
        'proc_scan_diagnostics': {key: observation[key] for key in ('inspected_process_names', 'vanished_before_name_read')},
        'scope': 'Original owned setup PNG only. Root actual view is pending. Host display origins and quiet are unverified.'})
    return {'copy': copied, 'proof': proof_ref, 'root_actual_view_completed': False,
            'assessment_executed': False, 'next_arm_authorized': False}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--arm', type=int, required=True, choices=(1, 2, 3, 4))
    parser.add_argument('--manifest', required=True)
    parser.add_argument('--manifest-sha256', required=True)
    args = parser.parse_args()
    print(json.dumps(complete(args.arm, args.manifest, args.manifest_sha256)))


if __name__ == '__main__':
    main()

"""Exact offline paste dependency; executable probe is private and pre-Desktop only."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

PROOF_SHA256 = '59b337921bf01ec715286d432137bbfa44c9abe0d9cf802e46f68f4f86f6b87f'
BINARY_SHA256 = 'a21dba4297e197ef27035071f6a36061cc8604ac360df19792db99ad3fd9a5f5'
BINARY_BYTES = 84696
MOUNTED_TOOL = Path('/fixture-bin/xdotool')
MOUNTED_PROOF = Path('/fixture-bin/paste-tool-proof.json')


def require(value, message):
    if not value:
        raise RuntimeError(message)


def verify_file(path, expected):
    path = Path(path)
    require(path.is_absolute() and path.is_file() and not path.is_symlink(), 'regular paste prerequisite file required')
    body = path.read_bytes()
    require(len(body) == expected['bytes'] and hashlib.sha256(body).hexdigest() == expected['sha256'],
            'paste prerequisite bytes differ: ' + str(path))
    return path


def validate(config, tool, proof_path):
    record = config['inputs']['paste_tool_proof']
    require(record['sha256'] == PROOF_SHA256, 'reviewed signed-index dependency proof required')
    verify_file(proof_path, record)
    proof = json.loads(Path(proof_path).read_text())
    require(proof['package'] == 'xdotool' and proof['version'] == '1:3.20160805.1-5build1'
            and proof['architecture'] == 'amd64' and proof['host_install_performed'] is False,
            'reviewed Ubuntu package identity required')
    expected = config['inputs']['paste_tool']
    require(expected == proof['binary'] and expected['sha256'] == BINARY_SHA256
            and expected['bytes'] == BINARY_BYTES, 'exact trusted paste executable input required')
    verify_file(tool, expected)
    mode = Path(tool).stat().st_mode & 0o777
    require(os.access(tool, os.X_OK) and mode & 0o111 and not mode & 0o022,
            'trusted paste executable permissions required')
    files = []
    for item in proof['elf_dependency_closure']:
        dependency = item['file']
        if dependency['sha256'] == BINARY_SHA256:
            continue
        require(dependency['path'].startswith('/usr/lib/x86_64-linux-gnu/'), 'bounded library path required')
        verify_file(dependency['path'], dependency)
        files.append(dependency)
    interpreter = proof['elf_interpreter']
    require(interpreter['path'] == '/usr/lib/x86_64-linux-gnu/ld-linux-x86-64.so.2', 'fixed ELF interpreter required')
    verify_file(interpreter['path'], interpreter)
    return {'tool': expected, 'proof': record, 'mode': oct(mode), 'library_files': files,
            'interpreter': interpreter, 'executable_run': False}


def validate_host(config):
    return validate(config, Path(config['inputs']['paste_tool']['path']), Path(config['inputs']['paste_tool_proof']['path']))


def private_pre_desktop_probe(config):
    from x11_target import boundary
    private = boundary(config)
    checked = validate(config, MOUNTED_TOOL, MOUNTED_PROOF)
    require(os.environ['PATH'] == '/usr/bin:/bin:/fixture-bin', 'reviewed private PATH required')
    require(shutil.which('xdotool') == str(MOUNTED_TOOL), 'product command must resolve to exact read-only tool')
    for item in Path('/proc').iterdir():
        if item.name.isdigit():
            try:
                require(os.readlink(item / 'exe') not in ('/fixture-bin/dezirclip', '/fixture-bin/dzc-surface'),
                        'paste prerequisite must precede Desktop and Surface startup')
            except (FileNotFoundError, ProcessLookupError, PermissionError):
                pass
    stdout = Path('/output/paste-tool-version.stdout.log')
    stderr = Path('/output/paste-tool-version.stderr.log')
    began = time.monotonic_ns()
    with stdout.open('xb') as out, stderr.open('xb') as err:
        result = subprocess.run([str(MOUNTED_TOOL), 'version'], stdin=subprocess.DEVNULL,
                                stdout=out, stderr=err, timeout=5)
    require(stdout.stat().st_size <= 4096 and stderr.stat().st_size <= 4096, 'bounded dependency version output required')
    require(result.returncode == 0 and '3.20160805.1' in stdout.read_text(), 'private paste dependency loader/version failed')
    return {**checked, 'executable_run': True, 'native_input_generated': False,
            'private_namespaces': private, 'command': [str(MOUNTED_TOOL), 'version'],
            'started_ns': began, 'finished_ns': time.monotonic_ns(), 'exit_code': result.returncode,
            'stdout': {'bytes': stdout.stat().st_size, 'sha256': hashlib.sha256(stdout.read_bytes()).hexdigest()},
            'stderr': {'bytes': stderr.stat().st_size, 'sha256': hashlib.sha256(stderr.read_bytes()).hexdigest()}}

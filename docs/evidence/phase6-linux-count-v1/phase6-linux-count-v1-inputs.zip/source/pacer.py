"""Event-anchored, fixed-count observations; contains no product or native calls."""


def counted_snapshots(progress, count, interval_ns, deadline_ns, clock, sleep, capture, encode, write_sample, write_clock):
    if not (type(count) is int and 0 < count <= 960 and type(interval_ns) is int and interval_ns > 0
            and type(deadline_ns) is int and deadline_ns > 0):
        raise ValueError('Invalid count-paced sampling policy')
    previous = None

    def now():
        nonlocal previous
        value = clock()
        if type(value) is not int or value < 0 or previous is not None and value < previous:
            raise RuntimeError('Sampling monotonic clock changed domain or moved backwards')
        previous = value
        if value >= deadline_ns:
            raise RuntimeError('Sampling deadline expired; retain partial observations')
        return value

    def until(due):
        value = now()
        while value < due:
            before = value
            sleep(min(due - value, deadline_ns - value) / 1_000_000_000)
            value = now()
            if value <= before:
                raise RuntimeError('Sampling clock did not advance during wait')
        return value

    progress.update(kind='event-anchored-count-v1', status='running', requested_count=count,
                    interval_ns=interval_ns, deadline_ns=deadline_ns, capture_calls=0,
                    samples_written=0, clocks=[])
    try:
        started = now()
        if deadline_ns - started > 1_260_000_000_000:
            raise RuntimeError('Sampling deadline is outside the original arm budget or clock domain')
        progress['started_ns'] = started
        due = started
        for index in range(count):
            actual = until(due)
            tick = {'index': index + 1, 'due_ns': due, 'actual_start_ns': actual, 'late_ns': actual - due}
            progress['clocks'].append(tick)
            progress['capture_calls'] += 1
            sample = capture(index + 1, actual)
            if not isinstance(sample, dict):
                raise RuntimeError('Capture did not return one complete observation')
            tick['capture_end_ns'] = now()
            sample['sampling_clock'] = dict(tick)
            encoded = encode(sample)
            tick['serialization_end_ns'] = now()
            write_sample(encoded)
            tick['sample_write_end_ns'] = now()
            progress['samples_written'] += 1
            write_clock(dict(tick))
            tick['clock_log_end_ns'] = now()
            due = actual + interval_ns
        progress['tail_due_ns'] = due
        progress['tail_reached_ns'] = until(due)
        progress['status'] = 'passed'
        return progress
    except BaseException as error:
        progress.update(status='failed', error_type=type(error).__name__, error=str(error))
        raise


def counter_rate_interval(first, last, delta_ticks, ticks_per_second):
    """Normalization uncertainty from read windows; neither a CI nor a common-time CPU bound."""
    if not (isinstance(first, (list, tuple)) and isinstance(last, (list, tuple))
            and len(first) == len(last) == 2 and all(type(value) is int and value >= 0 for value in (*first, *last))
            and first[0] <= first[1] < last[0] <= last[1]
            and last[1] - first[0] <= 1_260_000_000_000
            and type(delta_ticks) is int and delta_ticks >= 0
            and type(ticks_per_second) is int and ticks_per_second > 0):
        return None
    minimum = last[0] - first[1]
    maximum = last[1] - first[0]
    twice_midpoint_interval = (last[0] - first[0]) + (last[1] - first[1])
    numerator = delta_ticks * 100 * 1_000_000_000 / ticks_per_second
    return {'counter_delta_ticks': delta_ticks, 'interval_min_ns': minimum, 'interval_max_ns': maximum,
            'twice_nominal_interval_ns': twice_midpoint_interval,
            'nominal_percent_one_core': numerator * 2 / twice_midpoint_interval,
            'read_window_normalization_percent_range': [numerator / maximum, numerator / minimum],
            'scope': 'Read-point timing uncertainty only, not a statistical confidence interval, common-time family CPU bound, tick-quantization bound or whole-window CPU average.'}

"""Read-only assessment of one count-paced arm; never execute a native fixture."""
import collections
import hashlib
import json
import math
from pathlib import Path
import re
import struct
import sys

HERE = Path(__file__).resolve().parent
BASE = Path('/home/qiyuaner/.cache/dezirclip-v02/phase6-performance-recovered')


def read(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


def lines(path):
    return [json.loads(line) for line in Path(path).read_text().splitlines()]


def record(path):
    path = Path(path)
    assert path.is_absolute() and path.is_file() and not path.is_symlink()
    value = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            value.update(chunk)
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': value.hexdigest()}


def summarize(values):
    values = sorted(values)
    assert values
    return {'count': len(values), 'min': values[0], 'max': values[-1], 'mean': sum(values) / len(values),
            'p50': values[math.ceil(len(values) * .5) - 1], 'p95': values[math.ceil(len(values) * .95) - 1]}


def equal_summary(actual, values):
    expected = summarize(values)
    assert set(actual) == set(expected)
    for key in expected:
        assert math.isclose(actual[key], expected[key], rel_tol=1e-12, abs_tol=1e-9)


def equal_range(actual, expected):
    assert isinstance(actual, (list, tuple)) and len(actual) == 2
    assert all(type(value) in (int, float) and math.isfinite(value) for value in actual)
    assert all(math.isclose(value, target, rel_tol=1e-12, abs_tol=1e-9) for value, target in zip(actual, expected))


def validate_namespace_binding(report, keeper, host):
    names = {'user', 'mnt', 'pid', 'ipc', 'uts', 'net'}
    assert isinstance(report, dict) and isinstance(keeper, dict) and isinstance(host, dict)
    assert set(report) == set(keeper) == set(host) == names and report == keeper
    for name in names:
        assert all(isinstance(value, str) and re.fullmatch(name + r':\[[0-9]+\]', value) for value in (report[name], host[name]))
        assert report[name] != host[name]


def validate_members(sample, main, panel):
    members = sample['members']
    assert isinstance(members, list) and members
    assert all(isinstance(member, dict) for member in members)
    assert len({member['pid'] for member in members}) == len(members)
    identities = set()
    for member in members:
        assert all(type(member[key]) is int and member[key] > 0 for key in ('pid', 'started'))
        assert type(member['cpu_ticks']) is int and member['cpu_ticks'] >= 0
        identities.add((member['pid'], member['started']))
        memory = member['memory_kib']
        assert isinstance(memory, dict) and {'Pss', 'Rss', 'Private_Clean', 'Private_Dirty'} <= set(memory)
        assert all(type(value) is int and value >= 0 for value in memory.values())
        threads = member['threads']
        assert isinstance(threads, list) and threads
        assert len({thread['tid'] for thread in threads}) == len(threads)
        for thread in threads:
            assert all(type(thread[key]) is int and thread[key] > 0 for key in ('tid', 'started'))
            assert all(type(thread[key]) is int and thread[key] >= 0 for key in ('voluntary_ctxt_switches', 'nonvoluntary_ctxt_switches'))
    assert {(main['pid'], main['started']), (panel['pid'], panel['started'])} <= identities


def validate_clocks(samples, clock_lines, progress):
    assert all(type(progress[key]) is int for key in ('requested_count', 'capture_calls', 'samples_written', 'interval_ns',
        'deadline_ns', 'started_ns', 'tail_due_ns', 'tail_reached_ns', 'files_flushed_ns'))
    assert progress['kind'] == 'event-anchored-count-v1' and progress['status'] == 'passed'
    assert progress['requested_count'] == progress['capture_calls'] == progress['samples_written'] == len(samples) == len(clock_lines) == len(progress['clocks']) == 960
    assert progress['interval_ns'] == 250_000_000
    assert 0 < progress['deadline_ns'] - progress['started_ns'] <= 1_260_000_000_000
    previous = None
    clock_keys = {'index', 'due_ns', 'actual_start_ns', 'late_ns', 'capture_end_ns', 'serialization_end_ns', 'sample_write_end_ns', 'clock_log_end_ns'}
    for index, (sample, raw_clock, clock) in enumerate(zip(samples, clock_lines, progress['clocks']), 1):
        assert set(clock) == clock_keys and all(type(value) is int for value in clock.values())
        assert clock['index'] == sample['snapshot_index'] == index
        assert raw_clock == {key: value for key, value in clock.items() if key != 'clock_log_end_ns'}
        assert sample['sampling_clock'] == {key: clock[key] for key in ('index', 'due_ns', 'actual_start_ns', 'late_ns', 'capture_end_ns')}
        assert sample['monotonic_ns'] == clock['actual_start_ns']
        assert clock['due_ns'] == (previous['actual_start_ns'] + 250_000_000 if previous else progress['started_ns'])
        assert clock['actual_start_ns'] >= clock['due_ns']
        assert clock['late_ns'] == clock['actual_start_ns'] - clock['due_ns']
        assert clock['actual_start_ns'] <= clock['capture_end_ns'] <= clock['serialization_end_ns'] <= clock['sample_write_end_ns'] <= clock['clock_log_end_ns'] < progress['deadline_ns']
        assert clock['capture_end_ns'] - clock['actual_start_ns'] >= sample['observer_cost_ns'] >= 0
        bounds = sample['cpu_counter_read_window_ns']
        assert len(bounds) == 2 and all(type(value) is int for value in bounds)
        assert clock['actual_start_ns'] <= bounds[0] <= bounds[1] <= clock['capture_end_ns']
        if previous:
            assert clock['actual_start_ns'] >= previous['clock_log_end_ns']
        previous = clock
    assert progress['tail_due_ns'] == previous['actual_start_ns'] + 250_000_000
    assert max(progress['tail_due_ns'], previous['clock_log_end_ns']) <= progress['tail_reached_ns'] <= progress['files_flushed_ns'] < progress['deadline_ns']
    assert progress['files_flushed_ns'] - progress['started_ns'] >= 240_000_000_000
    assert samples[-1]['monotonic_ns'] - samples[0]['monotonic_ns'] >= 239_750_000_000


def main(arm_name):
    plan = read(HERE / 'comparison-count-v1.plan.json')
    matching = [arm for arm in plan['arms'] if arm['run_name'] == arm_name]
    assert len(matching) == 1
    arm = matching[0]
    config_path = HERE / (arm_name + '.execution.json')
    config = read(config_path)
    pending = read(HERE / (arm_name + '.pending.json'))
    assert pending['root_go'] is False and config == {**pending, 'root_go': True}
    assert config['performance_eligible'] is False and config['comparison'] == plan['comparison']
    revision = config['expected']['source_revision']
    raw = BASE / revision / arm_name
    receipt, runtime, report = read(raw / 'receipt.json'), read(raw / 'runtime.json'), read(raw / 'functional/performance.json')
    keeper, ss = read(raw / 'functional/keeper.json'), read(raw / 'functional/private-ss/proof.json')
    assert receipt['status'] == report['status'] == keeper['status'] == ss['status'] == 'passed'
    assert receipt['exit_code'] == keeper['exit_code'] == ss['command_exit_code'] == 0
    assert 'forced_outer_stop' not in receipt and report.get('first_error') is None
    assert receipt['runtime_sha256'] == record(raw / 'runtime.json')['sha256']
    assert runtime['inputs'] == config['inputs'] and runtime['expected'] == config['expected'] and runtime['comparison'] == config['comparison']
    assert report['arm_index'] == arm['arm_index'] and report['renderer'] == arm['renderer'] and report['source_revision'] == revision
    for item in config['inputs'].values():
        assert record(item['path']) == item
    for name, expected in config['fixture_sources'].items():
        assert record(HERE / name)['sha256'] == expected
    validate_namespace_binding(report['private_namespaces'], keeper['private_namespaces'], runtime['host_namespaces'])
    assert report['credential_boundary']['status'] == 'passed'
    for suffix in ('preflight-windows.json', 'postflight-windows.json'):
        assert read(HERE / (arm_name + '.' + suffix))['known_compiler_names'] == []
    assert len(report['warmup']) == 5 and len(report['samples']) == 30
    first, main_window = report['first_hotkey'], report['original_main']
    renderer = arm['renderer']
    assert (first['pid'] == main_window['pid']) == (renderer == 'tauri')
    for show in [*report['warmup'], *report['samples']]:
        assert all(show[key] == first[key] for key in ('pid', 'started', 'xid', 'session_id'))
        assert show['input']['keys'] == ['Control_L', 'Alt_L', 'Shift_L', 'F10']
        assert show['native']['active'] == first['xid'] and first['xid'] in show['native']['focus_chain']
        assert abs(show['activation_proxy_ms'] - (show['native_observed_ns'] - show['input']['input_start_ns']) / 1e6) < 1e-9
    equal_summary(report['warm_activation_proxy_ms'], [show['activation_proxy_ms'] for show in report['samples']])
    assert report['actual_paste']['text'] == config['dataset'][7] and report['actual_paste']['pending'] is False
    assert report['retained_ids'] == list(range(1, 11))
    assert report['capture_owner']['mode'] == 'embedded' and report['capture_owner']['capture_owner'] is True
    target = report['actual_paste']['windows']['target']
    setup = report['resource_query_setup']
    assert setup['query'] == 'dzcp6needle7' and setup['expected_content'] == config['dataset'][7]
    assert setup['stored_rows'] == 10 and setup['expected_matching_rows'] == 1 and setup['setup_wait_seconds'] == .7
    png = record(raw / 'functional/resource-visible-query.png')
    assert png['sha256'] == setup['screenshot']['sha256']
    assert record(HERE / (arm_name + '.setup.png'))['sha256'] == png['sha256']
    copy_proof = read(HERE / (arm_name + '.setup-copy-proof.json'))
    assert copy_proof['source'] == png and copy_proof['copy'] == record(HERE / (arm_name + '.setup.png'))
    assert copy_proof['sha256_verified_equal'] is True and copy_proof['postflight_linux_owned_native'] == []
    pixels = (raw / 'functional/resource-visible-query.png').read_bytes()
    assert len(pixels) <= 8 * 1024 * 1024 and pixels[:8] == b'\x89PNG\r\n\x1a\n' and struct.unpack('>II', pixels[16:24]) == (480, 360)
    root_png = read(HERE / (arm_name + '.root-png.json'))
    assert root_png['actual_view_completed'] is True and root_png['reviewer'] == 'Root' and root_png['status'] == 'passed'
    assert root_png['arm'] == arm_name and root_png['source_revision'] == revision and root_png['png_sha256'] == png['sha256']
    assert root_png['exact_query'] == setup['query'] and root_png['visible_matching_rows'] == 1 and root_png['full_visible_content'] == config['dataset'][7]
    native = lines(raw / 'functional/native-observations.jsonl')
    assert all(item['x_errors'] == 0 for item in native)
    native_index = {item['monotonic_ns']: item for item in native}
    qualifications = report['show_qualifications']
    replies = lines(raw / 'functional/show-status-qualification.jsonl')
    assert len(qualifications) == len({item['tag'] for item in qualifications}) == 38
    reply_counts = collections.Counter(item['tag'] for item in replies)
    timed = {'first-hotkey': first, **{f'warmup-{i}': value for i, value in enumerate(report['warmup'], 1)},
             **{f'samples-{i}': value for i, value in enumerate(report['samples'], 1)}}
    by_tag = {item['tag']: item for item in qualifications}
    for item in qualifications:
        endpoint = item['original_endpoint']
        assert item['qualified'] is True and item['native_proxy_endpoint_unchanged'] is True
        assert all(endpoint[key] == first[key] for key in ('pid', 'started', 'xid'))
        assert item['native_proxy_endpoint_ns'] == endpoint['native_observed_ns'] <= item['qualification_completed_ns']
        assert item['qualification_completed_ns'] / 1e9 < item['original_deadline_monotonic']
        assert item['reply_records'] == reply_counts[item['tag']]
        assert item['status_reads'] == len(item['observations']) >= 1
        assert item['reply_records'] == item['status_reads'] * (2 if renderer == 'tauri' else 1)
        if item['tag'] in timed:
            assert timed[item['tag']]['native_observed_ns'] == endpoint['native_observed_ns']
        final = item['final_status']
        if renderer == 'mygo':
            assert final['managed_pid'] == first['pid'] and final['session_id'] == first['session_id'] and final['visible'] is True
        else:
            assert final['renderer'] == 'tauri' and final['managed_pid'] is None and final['session_id'] is None
        for observation in item['observations']:
            if renderer == 'tauri':
                assert observation['tauri_visible'] is True and observation['status'] == final
            for side in ('before', 'after'):
                current = native_index[observation[side + '_native_ns']]
                assert current['active'] == first['xid'] and first['xid'] in current['focus_chain']
                windows = [window for window in current['windows'] if window['xid'] == first['xid']]
                assert len(windows) == 1 and windows[0]['pids'] == [first['pid']] and windows[0]['viewable'] is True
                roles = observation[side + '_identities']
                assert (roles['main']['pid'], roles['main']['started']) == (main_window['pid'], main_window['started'])
                assert (roles['panel']['pid'], roles['panel']['started']) == (first['pid'], first['started'])
    for reply in replies:
        item = by_tag[reply['tag']]
        assert 'error' not in reply and reply['http_status'] == 200 and reply['original_endpoint'] == item['original_endpoint']
        assert item['native_proxy_endpoint_ns'] <= reply['request_started_ns'] <= reply['response_finished_ns'] <= item['qualification_completed_ns']
        assert reply['response_finished_ns'] / 1e9 < item['original_deadline_monotonic']
        assert 0 < reply['remaining_budget_ms'] <= 5000 and reply['wire_bytes'] <= 65536
        assert abs(item['original_deadline_monotonic'] - (reply['request_started_ns'] / 1e9 + reply['remaining_budget_ms'] / 1000)) < .02
        assert reply['actual_response']['value']['ok'] is True and reply['actual_response']['value']['value'] == reply['reply']
        assert reply['command'] in ('get_quick_paste_surface_status', 'is_quick_paste_visible')
        if reply['command'] == 'is_quick_paste_visible':
            assert renderer == 'tauri' and reply['reply'] is True
        elif renderer == 'tauri':
            assert reply['reply'] == item['final_status']
    assert len(replies) == sum(reply_counts.values()) == sum(item['reply_records'] for item in qualifications)
    verified = {}
    assert set(report['resources']) == {'visible', 'hidden'}
    for state, visible in (('visible', True), ('hidden', False)):
        samples = lines(raw / ('functional/resources-' + state + '.jsonl'))
        clock_lines = lines(raw / ('functional/resource-clock-' + state + '.jsonl'))
        progress, metric = report['resource_sampling_progress'][state], report['resources'][state]
        validate_clocks(samples, clock_lines, progress)
        assert metric['sample_count'] == 960 and metric['sampling_protocol'] == 'event-anchored-count-v1'
        assert math.isclose(metric['actual_elapsed_seconds'], (progress['files_flushed_ns'] - progress['started_ns']) / 1e9)
        assert math.isclose(metric['sample_span_seconds'], (samples[-1]['monotonic_ns'] - samples[0]['monotonic_ns']) / 1e9)
        observations = [item for item in native if item['tag'] == 'resource-' + state][-960:]
        assert len(observations) == 960
        for sample, observation in zip(samples, observations):
            validate_members(sample, main_window, first)
            assert sample['monotonic_ns'] <= observation['monotonic_ns'] <= sample['cpu_counter_read_window_ns'][0]
            assert sample['pss_kib'] == sum(item['memory_kib']['Pss'] for item in sample['members'])
            assert sample['uss_kib'] == sum(sum(item['memory_kib'].get(key, 0) for key in ('Private_Clean', 'Private_Dirty', 'Private_Hugetlb')) for item in sample['members'])
            for side in ('original_identities_before', 'original_identities_after'):
                assert (sample[side]['main']['pid'], sample[side]['main']['started']) == (main_window['pid'], main_window['started'])
                assert (sample[side]['panel']['pid'], sample[side]['panel']['started']) == (first['pid'], first['started'])
            for expected, displayed in ((main_window, False), (first, visible)):
                windows = [window for window in observation['windows'] if window['xid'] == expected['xid']]
                assert len(windows) == 1 and windows[0]['pids'] == [expected['pid']] and windows[0]['viewable'] is displayed
            panel = next(window for window in observation['windows'] if window['xid'] == first['xid'])
            assert panel['rect']['width'] == 480 and panel['rect']['height'] == 360
            expected_active = first['xid'] if visible else target
            assert observation['active'] == expected_active and expected_active in observation['focus_chain']
        for key in ('pss_kib', 'uss_kib'):
            equal_summary(metric[key], [sample[key] for sample in samples])
        equal_summary(metric['late_ms'], [clock['late_ns'] / 1e6 for clock in progress['clocks']])
        equal_summary(metric['observer_cost_ms'], [sample['observer_cost_ns'] / 1e6 for sample in samples])
        for metric_key, beginning, end in (
                ('serialization_cost_ms', 'capture_end_ns', 'serialization_end_ns'),
                ('sample_write_cost_ms', 'serialization_end_ns', 'sample_write_end_ns'),
                ('clock_log_cost_ms', 'sample_write_end_ns', 'clock_log_end_ns')):
            equal_summary(metric[metric_key], [(clock[end] - clock[beginning]) / 1e6 for clock in progress['clocks']])
        equal_summary(metric['observation_intervals_ms'], [(right['monotonic_ns'] - left['monotonic_ns']) / 1e6 for left, right in zip(samples, samples[1:])])
        families = [{(member['pid'], member['started']) for member in sample['members']} for sample in samples]
        stable = all(family == families[0] for family in families)
        assert metric['stable_process_membership'] is stable
        if stable:
            delta = samples[-1]['cpu_ticks'] - samples[0]['cpu_ticks']
            bounds_first, bounds_last = samples[0]['cpu_counter_read_window_ns'], samples[-1]['cpu_counter_read_window_ns']
            assert delta >= 0
            cpu = metric['cpu_counter_normalization']
            minimum, maximum = bounds_last[0] - bounds_first[1], bounds_last[1] - bounds_first[0]
            assert cpu['counter_delta_ticks'] == delta and cpu['interval_min_ns'] == minimum > 0 and cpu['interval_max_ns'] == maximum
            assert cpu['twice_nominal_interval_ns'] == sum(bounds_last) - sum(bounds_first)
            hz = metric['cpu_clock_ticks_per_second']
            assert type(hz) is int and hz > 0
            numerator = delta * 100 * 1_000_000_000 / hz
            assert math.isclose(cpu['nominal_percent_one_core'], numerator * 2 / cpu['twice_nominal_interval_ns'])
            equal_range(cpu['read_window_normalization_percent_range'], [numerator / maximum, numerator / minimum])
            assert metric['cpu_percent_one_core'] == cpu['nominal_percent_one_core']
        else:
            assert metric['cpu_counter_normalization'] is None and metric['cpu_percent_one_core'] is None
        thread_sets = [{(member['pid'], member['started'], thread['tid'], thread['started'])
                       for member in sample['members'] for thread in member['threads']} for sample in samples]
        stable_threads = all(current == thread_sets[0] for current in thread_sets)
        assert metric['stable_thread_membership'] is stable_threads
        for sample in samples:
            assert sample['cpu_ticks'] == sum(member['cpu_ticks'] for member in sample['members'])
            assert sample['context_switches'] == sum(thread['voluntary_ctxt_switches'] + thread['nonvoluntary_ctxt_switches']
                for member in sample['members'] for thread in member['threads'])
        expected_delta = samples[-1]['context_switches'] - samples[0]['context_switches'] if stable_threads else None
        assert metric['observed_thread_context_switch_delta'] == expected_delta
        assert metric['wakeup_count'] is None
        verified[state] = metric
    assert all(item['compiler_processes'] == [] for item in lines(raw / 'host-load.jsonl'))
    assert read(raw / 'host-preflight.json')['compiler_processes'] == []
    cleanup = report['cleanup']
    assert cleanup['target'] == {'exit_code': 0, 'pidfd_exited': True, 'forced': False}
    assert cleanup['webdriver']['exit_code'] == -15 and cleanup['webdriver']['pidfd_exited'] is True and cleanup['webdriver']['forced'] is False
    assert cleanup['desktop_pidfd_exit'] is True and cleanup['wm_exit_code'] == 0 and cleanup['errors'] == []
    assert keeper['forced_cleanup'] == [] and keeper['remaining'] == []
    assert len(ss['processes']) == 2 and all(item['exit_code'] == 0 and item['stopped'] is True for item in ss['processes'])
    assert ss['helper_unchanged'] is True and report['paste_prerequisite']['exit_code'] == 0 and report['paste_prerequisite']['native_input_generated'] is False
    files = [path for path in raw.iterdir() if path.is_file() and path.name != '.native-capture-fixture']
    files += [path for path in (raw / 'functional').iterdir() if path.is_file()]
    files += [raw / 'functional/private-ss/proof.json']
    assessment = {'kind': 'phase6_count_paced_arm_assessment', 'status': 'passed', 'arm': arm,
        'source_revision': revision, 'performance_eligible': False, 'next_arm_authorized': False,
        'execution': record(config_path), 'warm_activation_proxy_ms': report['warm_activation_proxy_ms'],
        'verified_resources': verified, 'qualification_count': len(qualifications), 'actual_reply_count': len(replies),
        'cleanup': cleanup, 'keeper': keeper, 'secret_service': ss,
        'raw_evidence': [record(path) for path in sorted(files)], 'root_png_evidence': record(HERE / (arm_name + '.root-png.json')),
        'setup_copy_proof': record(HERE / (arm_name + '.setup-copy-proof.json')),
        'assessor': record(Path(__file__).resolve()),
        'limits': ['Native visible/foreground proxy, not first interactive frame.',
                   'Count-paced protocol snapshot distributions, not equal exposure/time means/independent statistical repetitions.',
                   'Original source await plus passed report proves normal disable gates; no separate Host-wire ACK or exact helper exit timestamp.',
                   'GPU/wakeups/search readiness/IME/DPI/multimonitor and whole Windows host quiet remain unverified.']}
    with (HERE / (arm_name + '.assessment.json')).open('x') as output:
        json.dump(assessment, output, indent=2)
    print(json.dumps({'status': 'passed', 'arm': arm_name, 'resources': {name: value['sample_count'] for name, value in verified.items()}}))


if __name__ == '__main__':
    assert len(sys.argv) == 2
    main(sys.argv[1])

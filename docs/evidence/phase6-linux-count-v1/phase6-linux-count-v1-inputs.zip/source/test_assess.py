import copy
import importlib.util
from pathlib import Path
import unittest

SPEC = importlib.util.spec_from_file_location('assess', Path(__file__).with_name('assess.py'))
ASSESS = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(ASSESS)


def fixture(late_index=600):
    base, interval = 2 ** 54 + 123, 250_000_000
    clocks, samples, raw = [], [], []
    previous = None
    for index in range(960):
        due = previous + interval if previous is not None else base
        actual = due + (500_000_000 if index == late_index else 0)
        clock = {'index': index + 1, 'due_ns': due, 'actual_start_ns': actual, 'late_ns': actual - due,
                 'capture_end_ns': actual + 1_000_000, 'serialization_end_ns': actual + 2_000_000,
                 'sample_write_end_ns': actual + 3_000_000, 'clock_log_end_ns': actual + 4_000_000}
        clocks.append(clock)
        raw.append({key: value for key, value in clock.items() if key != 'clock_log_end_ns'})
        samples.append({'snapshot_index': index + 1, 'monotonic_ns': actual, 'observer_cost_ns': 500_000,
            'cpu_counter_read_window_ns': [actual + 200_000, actual + 400_000],
            'sampling_clock': {key: clock[key] for key in ('index', 'due_ns', 'actual_start_ns', 'late_ns', 'capture_end_ns')}})
        previous = actual
    progress = {'kind': 'event-anchored-count-v1', 'status': 'passed', 'requested_count': 960, 'capture_calls': 960,
        'samples_written': 960, 'interval_ns': interval, 'started_ns': base, 'deadline_ns': base + 1_260_000_000_000,
        'clocks': clocks, 'tail_due_ns': previous + interval, 'tail_reached_ns': previous + interval,
        'files_flushed_ns': previous + interval + 1_000_000}
    return samples, raw, progress


class ClockAssessmentTests(unittest.TestCase):
    def test_accepts_only_the_predeclared_event_anchored_protocol_with_real_lateness(self):
        ASSESS.validate_clocks(*fixture())
        ASSESS.validate_clocks(*fixture(late_index=959))

    def test_rejects_missing_or_duplicated_observations_and_absolute_grid_catchup(self):
        for mutation in ('missing', 'duplicate', 'grid'):
            samples, raw, progress = fixture()
            if mutation == 'missing':
                samples.pop()
            elif mutation == 'duplicate':
                samples[700] = copy.deepcopy(samples[699])
            else:
                progress['clocks'][601]['due_ns'] = progress['started_ns'] + 601 * 250_000_000
            with self.subTest(mutation=mutation), self.assertRaises(AssertionError):
                ASSESS.validate_clocks(samples, raw, progress)


class ResourceBoundaryTests(unittest.TestCase):
    def sample(self):
        member = {'pid': 68, 'started': 100, 'cpu_ticks': 10,
            'memory_kib': {'Pss': 100, 'Rss': 120, 'Private_Clean': 20, 'Private_Dirty': 40},
            'threads': [{'tid': 68, 'started': 100, 'voluntary_ctxt_switches': 4, 'nonvoluntary_ctxt_switches': 1}]}
        return {'members': [member]}

    def test_requires_complete_unique_original_process_resources(self):
        identity = {'pid': 68, 'started': 100}
        ASSESS.validate_members(self.sample(), identity, identity)
        for mutation in ('empty', 'foreign', 'duplicate', 'missing-memory', 'negative', 'no-threads', 'duplicate-thread', 'bad-counter'):
            sample = self.sample()
            if mutation == 'empty': sample['members'] = []
            elif mutation == 'foreign': sample['members'][0]['pid'] = 69
            elif mutation == 'duplicate': sample['members'] *= 2
            elif mutation == 'missing-memory': del sample['members'][0]['memory_kib']['Private_Clean']
            elif mutation == 'negative': sample['members'][0]['memory_kib']['Pss'] = -1
            elif mutation == 'no-threads': sample['members'][0]['threads'] = []
            elif mutation == 'duplicate-thread': sample['members'][0]['threads'] *= 2
            else: sample['members'][0]['threads'][0]['voluntary_ctxt_switches'] = True
            with self.subTest(mutation=mutation), self.assertRaises((AssertionError, KeyError)):
                ASSESS.validate_members(sample, identity, identity)

    def test_cpu_uncertainty_range_must_be_exactly_two_finite_numbers(self):
        ASSESS.equal_range([1.0, 2.0], [1.0, 2.0])
        for value in ([], [1.0], [1.0, 2.0, 3.0], [1.0, float('nan')], [float('inf'), 2.0], [True, 2.0]):
            with self.subTest(value=value), self.assertRaises(AssertionError):
                ASSESS.equal_range(value, [1.0, 2.0])

    def test_cleanup_namespace_must_be_the_current_arm_namespace(self):
        report = {name: name + ':[100]' for name in ('user', 'mnt', 'pid', 'ipc', 'uts', 'net')}
        host = {name: name + ':[1]' for name in report}
        ASSESS.validate_namespace_binding(report, dict(report), host)
        for keeper in ({**report, 'mnt': 'mnt:[101]'}, {**report, 'pid': ''}, {key: value for key, value in report.items() if key != 'net'}):
            with self.assertRaises(AssertionError):
                ASSESS.validate_namespace_binding(report, keeper, host)

    def test_rejects_clock_log_tampering_counter_windows_and_short_tail(self):
        for mutation in ('log', 'counter', 'tail', 'float'):
            samples, raw, progress = fixture(late_index=959)
            if mutation == 'log':
                raw[10]['sample_write_end_ns'] += 1
            elif mutation == 'counter':
                samples[10]['cpu_counter_read_window_ns'][0] = samples[10]['monotonic_ns'] - 1
            elif mutation == 'tail':
                progress['tail_due_ns'] = progress['clocks'][-1]['due_ns'] + 250_000_000
            else:
                progress['deadline_ns'] = float(progress['deadline_ns'])
            with self.subTest(mutation=mutation), self.assertRaises(AssertionError):
                ASSESS.validate_clocks(samples, raw, progress)


if __name__ == '__main__':
    unittest.main()

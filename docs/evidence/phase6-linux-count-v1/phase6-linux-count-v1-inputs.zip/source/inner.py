"""One private ABBA arm. Activation latency is a proxy, never first-interactive-frame."""
import importlib.util
import hashlib
import http.client
import io
import socket
import types
import json
import math
import os
import re
from pathlib import Path
import signal
import struct
import subprocess
import sys
import time

sys.path.insert(0, str(Path(__file__).resolve().parent))
from x11_target import X11, boundary, require
from paste_prerequisite import private_pre_desktop_probe

OUT = Path('/output')


def summary(values):
    require(bool(values), 'empty metric series')
    ordered = sorted(values)
    return {'count': len(values), 'min': ordered[0], 'max': ordered[-1],
            'mean': sum(values) / len(values), 'p50': ordered[math.ceil(len(values) * .5) - 1],
            'p95': ordered[math.ceil(len(values) * .95) - 1]}


def process_stat(path):
    fields = (path / 'stat').read_text().rsplit(')', 1)[1].split()
    return {'pid': int(path.name), 'parent': int(fields[1]), 'started': int(fields[19]),
            'cpu_ticks': int(fields[11]) + int(fields[12])}


def validate_resource_windows(native, main, panel, target_xid, visible, candidate):
    mains = [window for window in native['windows'] if window['xid'] == main['xid']]
    require(len(mains) == 1 and mains[0]['pids'] == [main['pid']] and not mains[0]['viewable'],
            'original main XID/PID must remain present and hidden during resource sampling')
    panels = [window for window in native['windows'] if window['xid'] == panel['xid']]
    require(len(panels) == 1 and panels[0]['pids'] == [panel['pid']]
            and panels[0]['rect']['width'] == 480 and panels[0]['rect']['height'] == 360,
            'original resource panel XID/PID/geometry changed')
    require(panels[0]['viewable'] == visible, 'original resource panel visibility changed')
    if visible:
        require(candidate is not None and candidate['xid'] == panel['xid'] and candidate['pids'] == [panel['pid']]
                and native['active'] == panel['xid'] and panel['xid'] in native['focus_chain'],
                'visible resource sample must retain the original foreground panel')
    else:
        require(candidate is None and native['active'] == target_xid and target_xid in native['focus_chain'],
                'hidden resource sample has a replacement panel or lost target focus')


def original_resource_processes(support, desktop_ticket, panel_ticket, stage):
    identities = {}
    for name, ticket in [('main', desktop_ticket), ('panel', panel_ticket)]:
        pid = ticket['identity']['pid']
        try:
            require(not support.exited(ticket), 'original pidfd exited')
            current = support.process_identity(pid)
            require(current['started'] == ticket['identity']['started'], 'original process changed')
            identities[name] = current
        except Exception as error:
            raise RuntimeError(f'resource identity failed stage={stage} role={name} pid={pid} tid=None: {type(error).__name__}: {error}') from error
    return identities


def family_snapshot(root, remembered):
    inventory = {}
    for path in Path('/proc').iterdir():
        if path.name.isdigit():
            try:
                inventory[int(path.name)] = process_stat(path)
            except (FileNotFoundError, ProcessLookupError):
                pass
    require(root in inventory and inventory[root]['started'] == remembered[root],
            f'process sampling failed stage=desktop-inventory pid={root} tid=None: Desktop identity lost')
    included = {pid for pid, started in remembered.items() if pid in inventory and inventory[pid]['started'] == started}
    while True:
        expanded = included | {pid for pid, item in inventory.items() if item['parent'] in included}
        if expanded == included:
            break
        included = expanded
    members = []
    for pid in sorted(included):
        item = inventory[pid]
        remembered[pid] = item['started']
        path = Path('/proc') / str(pid)
        stage, tid = 'smaps-rollup', None
        try:
            memory = {line.split(':', 1)[0]: int(line.split()[1]) for line in (path / 'smaps_rollup').read_text().splitlines()
                      if ':' in line and line.split(':', 1)[0] in {'Pss', 'Rss', 'Private_Clean', 'Private_Dirty', 'Private_Hugetlb', 'Pss_Anon', 'Pss_File', 'Pss_Shmem'}}
            require({'Pss', 'Rss', 'Private_Clean', 'Private_Dirty'} <= memory.keys(), 'process memory metrics missing')
            stage = 'task-inventory'
            tasks = list((path / 'task').iterdir())
            threads = []
            for thread in tasks:
                stage, tid = 'thread-stat', int(thread.name)
                identity = process_stat(thread)
                stage = 'thread-status'
                switches = {line.split(':', 1)[0]: int(line.split()[1]) for line in (thread / 'status').read_text().splitlines()
                            if line.startswith(('voluntary_ctxt_switches:', 'nonvoluntary_ctxt_switches:'))}
                require(len(switches) == 2, 'thread context switch counters missing')
                threads.append({'tid': identity['pid'], 'started': identity['started'], **switches})
            stage, tid = 'process-identity-recheck', None
            require(process_stat(path)['started'] == item['started'], 'process identity changed while sampling')
        except Exception as error:
            raise RuntimeError(f'process sampling failed stage={stage} pid={pid} tid={tid}: {type(error).__name__}: {error}') from error
        members.append({**item, 'memory_kib': memory, 'threads': threads})
    return {'members': members, 'pss_kib': sum(item['memory_kib']['Pss'] for item in members),
            'uss_kib': sum(sum(item['memory_kib'].get(name, 0) for name in ('Private_Clean', 'Private_Dirty', 'Private_Hugetlb')) for item in members),
            'cpu_ticks': sum(item['cpu_ticks'] for item in members),
            'context_switches': sum(thread['voluntary_ctxt_switches'] + thread['nonvoluntary_ctxt_switches'] for item in members for thread in item['threads'])}


def read_only_before_deadline(driver, command, deadline, record_reply, now=time.monotonic):
    require(command in ('get_quick_paste_surface_status', 'is_quick_paste_visible'), 'qualification command is not read-only')
    require(type(driver.port) is int and 1024 <= driver.port <= 65535, 'private driver port rejected')
    require(isinstance(driver.route, str) and re.fullmatch(r'session/[A-Za-z0-9-]{1,128}', driver.route), 'original private driver route rejected')
    remaining = deadline - now()
    require(remaining > 0, 'surface ownership qualification deadline expired')
    began_ns = time.monotonic_ns()
    event = {'command': command, 'request_started_ns': began_ns, 'remaining_budget_ms': remaining * 1000}
    connection = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    response = None
    wire_bytes = 0
    wire_digest = hashlib.sha256()

    class DeadlineReply(io.RawIOBase):
        def readable(self):
            return True

        def readinto(self, buffer):
            nonlocal wire_bytes
            budget = deadline - now()
            require(budget > 0, 'surface ownership qualification deadline expired')
            connection.settimeout(budget)
            capacity = min(len(buffer), 65536 - wire_bytes)
            require(capacity > 0, 'bounded qualification wire reply exceeded')
            count = connection.recv_into(memoryview(buffer)[:capacity])
            wire_bytes += count
            wire_digest.update(memoryview(buffer)[:count])
            require(wire_bytes <= 65536, 'bounded qualification wire reply exceeded')
            return count
    try:
        # The only invoked commands are the two fixed, read-only getters above.
        # Every socket receive uses the same remaining absolute budget. This
        # cannot forcibly interrupt arbitrary UI/OS execution; late replies fail.
        payload = {'script': '''
const done=arguments[arguments.length-1];
let finished=false;
const finish=value=>{if(!finished){finished=true;done(value);}};
const timer=setTimeout(()=>finish({ok:false,error:'QualificationDeadlineExpired'}),arguments[1]);
window.__TAURI_INTERNALS__.invoke(arguments[0],{}).then(value=>{clearTimeout(timer);finish({ok:true,value});}).catch(error=>{clearTimeout(timer);finish({ok:false,error:String(error)});});
''', 'args': [command, math.floor(remaining * 1000)]}
        encoded = json.dumps(payload).encode()
        request = (f'POST /{driver.route}/execute/async HTTP/1.1\r\n'
                   f'Host: 127.0.0.1:{driver.port}\r\nConnection: close\r\n'
                   f'Content-Type: application/json\r\nContent-Length: {len(encoded)}\r\n\r\n').encode() + encoded
        connection.settimeout(deadline - now())
        connection.connect(('127.0.0.1', driver.port))
        remaining = deadline - now()
        require(remaining > 0, 'surface ownership qualification deadline expired')
        connection.settimeout(remaining)
        connection.sendall(request)
        reader = DeadlineReply()
        response = http.client.HTTPResponse(types.SimpleNamespace(makefile=lambda mode: io.BufferedReader(reader)))
        response.begin()
        event['http_status'] = response.status
        remaining = deadline - now()
        require(remaining > 0, 'surface ownership qualification deadline expired')
        body = response.read(65537)
        event['response_finished_ns'] = time.monotonic_ns()
        event['response_bytes'] = len(body)
        event['response_sha256'] = hashlib.sha256(body).hexdigest()
        event['wire_bytes'] = wire_bytes
        event['wire_sha256'] = wire_digest.hexdigest()
        require(len(body) <= 65536, 'bounded qualification reply exceeded')
        envelope = json.loads(body)
        event['actual_response'] = envelope
        require(response.status == 200 and isinstance(envelope, dict), 'private driver status response rejected')
        value = envelope.get('value')
        require(isinstance(value, dict) and value.get('ok') is True, 'read-only qualification invoke failed')
        record_reply({**event, 'reply': value.get('value')})
        event['recorded'] = True
        require(now() < deadline, 'surface ownership qualification reply arrived late')
        return value.get('value')
    except BaseException as error:
        if not event.get('recorded'):
            record_reply({**event, 'request_failed_ns': time.monotonic_ns(),
                          'wire_bytes': wire_bytes, 'wire_sha256': wire_digest.hexdigest(),
                          'error': {'type': type(error).__name__, 'message': str(error)[:1024]}})
        raise
    finally:
        if response is not None:
            response.close()
        connection.close()


def qualify_original_surface(renderer, deadline, endpoint, original_session, verify_original,
                             read_status, trace, poll_seconds, now=time.monotonic, sleep=time.sleep):
    require(renderer in ('tauri', 'mygo') and poll_seconds == .01, 'fixed qualification policy required')
    expected_session = original_session
    while True:
        require(now() < deadline, 'surface ownership qualification deadline expired')
        before = verify_original('before-status')
        state = read_status('get_quick_paste_surface_status', deadline)
        trace['status_reads'] += 1
        require(isinstance(state, dict) and set(state) == {'renderer', 'managed_pid', 'session_id', 'visible', 'last_error'}, 'surface status shape changed')
        require(state['renderer'] == renderer and type(state['visible']) is bool, 'surface renderer/status changed')
        require(state['last_error'] is None, 'surface reported an activation failure')
        visible = None
        if renderer == 'mygo':
            require(state['managed_pid'] is None or (type(state['managed_pid']) is int and state['managed_pid'] == endpoint['pid']), 'surface managed PID changed')
            require(state['managed_pid'] is not None or state['session_id'] is None, 'unowned surface session changed')
            if state['managed_pid'] is not None:
                require(isinstance(state['session_id'], str) and re.fullmatch(r'[a-f0-9]{32}', state['session_id']), 'surface session missing')
                if expected_session is None:
                    expected_session = state['session_id']
            require(expected_session is None or state['session_id'] == expected_session, 'surface session changed')
            require(not state['visible'] or state['managed_pid'] == endpoint['pid'], 'visible surface has no original managed PID')
            accepted = state['visible'] and state['managed_pid'] == endpoint['pid'] and expected_session is not None
        else:
            require(state['managed_pid'] is None and state['session_id'] is None, 'Tauri renderer retained a helper')
            visible = read_status('is_quick_paste_visible', deadline)
            require(type(visible) is bool, 'Tauri visibility reply changed type')
            accepted = visible
        after = verify_original('after-status')
        trace['observations'].append({'before_native_ns': before['native']['monotonic_ns'],
                                     'before_identities': before['identities'], 'status': state,
                                     'tauri_visible': visible, 'after_native_ns': after['native']['monotonic_ns'],
                                     'after_identities': after['identities']})
        require(now() < deadline, 'surface ownership qualification reply arrived late')
        if accepted:
            trace.update(qualified=True, final_status=state,
                         qualification_completed_ns=time.monotonic_ns(),
                         native_proxy_endpoint_ns=endpoint['native_observed_ns'],
                         native_proxy_endpoint_unchanged=True)
            return state
        remaining = deadline - now()
        require(remaining > 0, 'surface ownership qualification deadline expired')
        sleep(min(poll_seconds, remaining))


def counted_snapshots(progress, count, interval_ns, deadline_ns, clock, sleep, capture, encode, write_sample, write_clock):
    if not (type(count) is int and 0 < count <= 960 and type(interval_ns) is int and interval_ns > 0
            and type(deadline_ns) is int and deadline_ns > 0):
        raise ValueError('Invalid count-paced sampling policy')
    previous = None

    def now():
        nonlocal previous
        value = clock()
        if type(value) is not int or value < 0 or previous is not None and value < previous:
            raise RuntimeError('Sampling monotonic clock changed domain or moved backwards')
        previous = value
        if value >= deadline_ns:
            raise RuntimeError('Sampling deadline expired; retain partial observations')
        return value

    def until(due):
        value = now()
        while value < due:
            before = value
            sleep(min(due - value, deadline_ns - value) / 1_000_000_000)
            value = now()
            if value <= before:
                raise RuntimeError('Sampling clock did not advance during wait')
        return value

    progress.update(kind='event-anchored-count-v1', status='running', requested_count=count,
                    interval_ns=interval_ns, deadline_ns=deadline_ns, capture_calls=0,
                    samples_written=0, clocks=[])
    try:
        started = now()
        if deadline_ns - started > 1_260_000_000_000:
            raise RuntimeError('Sampling deadline is outside the original arm budget or clock domain')
        progress['started_ns'] = started
        due = started
        for index in range(count):
            actual = until(due)
            tick = {'index': index + 1, 'due_ns': due, 'actual_start_ns': actual, 'late_ns': actual - due}
            progress['clocks'].append(tick)
            progress['capture_calls'] += 1
            sample = capture(index + 1, actual)
            if not isinstance(sample, dict):
                raise RuntimeError('Capture did not return one complete observation')
            tick['capture_end_ns'] = now()
            sample['sampling_clock'] = dict(tick)
            encoded = encode(sample)
            tick['serialization_end_ns'] = now()
            write_sample(encoded)
            tick['sample_write_end_ns'] = now()
            progress['samples_written'] += 1
            write_clock(dict(tick))
            tick['clock_log_end_ns'] = now()
            due = actual + interval_ns
        progress['tail_due_ns'] = due
        progress['tail_reached_ns'] = until(due)
        progress['status'] = 'passed'
        return progress
    except BaseException as error:
        progress.update(status='failed', error_type=type(error).__name__, error=str(error))
        raise


def counter_rate_interval(first, last, delta_ticks, ticks_per_second):
    """Normalization uncertainty from read windows; neither a CI nor a common-time CPU bound."""
    if not (isinstance(first, (list, tuple)) and isinstance(last, (list, tuple))
            and len(first) == len(last) == 2 and all(type(value) is int and value >= 0 for value in (*first, *last))
            and first[0] <= first[1] < last[0] <= last[1]
            and last[1] - first[0] <= 1_260_000_000_000
            and type(delta_ticks) is int and delta_ticks >= 0
            and type(ticks_per_second) is int and ticks_per_second > 0):
        return None
    minimum = last[0] - first[1]
    maximum = last[1] - first[0]
    twice_midpoint_interval = (last[0] - first[0]) + (last[1] - first[1])
    numerator = delta_ticks * 100 * 1_000_000_000 / ticks_per_second
    return {'counter_delta_ticks': delta_ticks, 'interval_min_ns': minimum, 'interval_max_ns': maximum,
            'twice_nominal_interval_ns': twice_midpoint_interval,
            'nominal_percent_one_core': numerator * 2 / twice_midpoint_interval,
            'read_window_normalization_percent_range': [numerator / maximum, numerator / minimum],
            'scope': 'Read-point timing uncertainty only, not a statistical confidence interval, common-time family CPU bound, tick-quantization bound or whole-window CPU average.'}


def main():
    arm_clock_started_ns = time.monotonic_ns()
    arm_clock_deadline_ns = arm_clock_started_ns + 1_260_000_000_000
    config = json.loads(Path('/fixture-bin/runtime.json').read_text())
    private = boundary(config)
    sys.path.insert(0, '/fixture-bin/canonical')
    import credential_launcher
    spec = importlib.util.spec_from_file_location('functional_support', '/fixture-bin/functional_support.py')
    support = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(support)
    report = {'status': 'running', 'kind': 'phase6_linux_abba_arm', 'arm_index': config['arm_index'],
        'renderer': config['renderer'], 'source_revision': config['expected']['source_revision'],
        'private_namespaces': private, 'credential_boundary': credential_launcher.probe_boundary(),
        'performance_eligible': False, 'first_interactive_frame': None, 'search_ready_latency': None,
        'gpu_memory': None, 'wakeup_count': None, 'ime_dpi_multimonitor': None,
        'metric_scope': 'Whole Desktop process family; native visible+focus activation proxy. No adoption-threshold conclusion.',
        'warmup': [], 'samples': [], 'resources': {}, 'cleanup': {}, 'show_qualifications': []}
    private_bus = os.environ['DBUS_SESSION_BUS_ADDRESS']
    require(private_bus.startswith('unix:path=/q/dezirclip-private-ss-'), 'private SS bus missing')
    os.environ.update(config['product_environment'])
    os.environ['DBUS_SESSION_BUS_ADDRESS'] = private_bus
    driver = target = x = wm = None
    original_main = first = panel_ticket = None
    tickets, logs = [], []
    raw = (OUT / 'native-observations.jsonl').open('x', encoding='utf8')
    qualification_raw = (OUT / 'show-status-qualification.jsonl').open('x', encoding='utf8')
    policy = config['comparison']

    def save():
        support.save('performance.json', report)

    def observe(tag):
        retained = [item['xid'] for item in (original_main, first) if item is not None]
        value = x.observe(retained)
        raw.write(json.dumps({'tag': tag, **value}) + '\n')
        require(raw.tell() < 64 * 1024 * 1024, 'bounded native observation output exceeded')
        return value

    def focused(native, window):
        return native['active'] == window and window in native['focus_chain']

    def activate():
        window = target.request('target')['windows']['target']
        support.wait('synthetic original focus', lambda: focused(observe('target-focus'), window))

    try:
        report['paste_prerequisite'] = private_pre_desktop_probe(config)
        save()
        logs = [(OUT / 'wm.stdout.log').open('xb'), (OUT / 'wm.stderr.log').open('xb')]
        wm = subprocess.Popen(['/usr/bin/marco', '--sm-disable', '--no-composite', '--no-keybindings'], stdout=logs[0], stderr=logs[1])
        wm_ticket = support.process_ticket(wm.pid)
        tickets.append(wm_ticket)
        x = X11(config)
        support.wait('private EWMH WM', lambda: x.property(x.root, '_NET_SUPPORTING_WM_CHECK'))
        metadata = subprocess.run(['/fixture-bin/dzc-surface', '--build-info'], capture_output=True, timeout=15)
        (OUT / 'surface-build-info.stdout').write_bytes(metadata.stdout)
        (OUT / 'surface-build-info.stderr').write_bytes(metadata.stderr)
        require(metadata.returncode == 0, 'actual helper identity failed')
        info = json.loads(metadata.stdout)
        require(all(info[name] == value for name, value in config['expected'].items()), 'helper identity differs')
        require(info['mygo_version'] == 'v0.6.4' and info['mygo_source_revision'] == '6255ea40139d06e0762a7c4a32626148ba410478', 'MyGo dependency differs')
        report['surface_build_info'] = info
        driver = support.load_original_driver()(OUT, '/fixture-bin/dezirclip')
        driver.__enter__()
        report['desktop_build_info'] = driver.invoke('get_build_info')
        require(all(report['desktop_build_info'][name] == config['expected'][name] for name in ('component_version', 'source_revision', 'source_state', 'build_id', 'target')), 'Desktop identity differs')
        candidates = []
        for path in Path('/proc').iterdir():
            if path.name.isdigit():
                try:
                    if os.readlink(path / 'exe') == '/fixture-bin/dezirclip':
                        candidates.append(int(path.name))
                except OSError:
                    pass
        require(len(candidates) == 1, 'exactly one actual Desktop expected')
        desktop_pid = candidates[0]
        desktop_ticket = support.process_ticket(desktop_pid)
        tickets.append(desktop_ticket)
        require(driver.invoke('get_data_path') == '/output/profile/data/io.github.qiyuanhuakai.dezirclip', 'product data escaped private profile')
        driver.invoke('focus_clipboard_window')
        def main_window():
            native = observe('retain-original-main')
            windows = [window for window in native['windows'] if window['pids'] == [desktop_pid]
                       and window['viewable'] and focused(native, window['xid'])]
            require(len(windows) <= 1, 'multiple focused Desktop windows during main capture')
            return windows[0] if windows else None
        main = support.wait('actual original main window focus', main_window)
        original_main = {'xid': main['xid'], 'pid': desktop_pid, 'started': desktop_ticket['identity']['started']}
        report['original_main'] = original_main
        driver.invoke('set_idle_destroy_enabled', {'enabled': False})
        driver.invoke('set_persistence', {'enabled': True})
        driver.invoke('set_delete_after_paste', {'enabled': False})
        for name, value in [('app.quick_paste_hotkey', 'Ctrl+Alt+Shift+F10'), ('app.quick_paste_enabled', 'true'),
                            ('app.language', 'en'), ('app.quick_paste_renderer', config['renderer'])]:
            driver.invoke('save_setting', {'key': name, 'value': value})
        ids = [driver.invoke('add_manual_item', {'content': text, 'contentType': 'text', 'tags': [],
               'expectedPrivacyEpoch': None, 'confirmPersistence': False}) for text in config['dataset']]
        require(len(set(ids)) == 10, 'ten distinct ordinary rows required')
        owner = driver.invoke('get_clipboard_host_status')
        require(owner['mode'] == 'embedded' and owner['capture_owner'], 'one Embedded capture owner required')
        target = support.Target()
        tickets.append(target.ticket)
        driver.invoke('hide_window_cmd')
        labels = driver.invoke('plugin:window|get_all_windows')
        require(isinstance(labels, list) and all(isinstance(label, str) for label in labels), 'window inventory response differs')
        report['first_hotkey_context'] = {'application_already_started': True, 'tauri_window_precreated': 'quick-paste' in labels,
            'surface_before': driver.invoke('get_quick_paste_surface_status'), 'not_application_cold_start': True}
        first = None

        def matching(native, focused_only=True):
            matches = []
            for window in native['windows']:
                if (not window['viewable'] or window['rect']['width'] != 480 or window['rect']['height'] != 360
                        or (focused_only and not focused(native, window['xid'])) or len(window['pids']) != 1):
                    continue
                pid = window['pids'][0]
                if config['renderer'] == 'tauri':
                    valid = pid == desktop_pid
                else:
                    try:
                        valid = os.readlink(f'/proc/{pid}/exe') == '/fixture-bin/dzc-surface'
                    except OSError:
                        valid = False
                if valid:
                    matches.append(window)
            require(len(matches) <= 1, 'multiple native candidate panels')
            return matches[0] if matches else None

        def show(tag):
            nonlocal panel_ticket
            activate()
            entered = x.chord(['Control_L', 'Alt_L', 'Shift_L', 'F10'])
            deadline = time.monotonic() + 5
            polls, costs, previous_ns = [], [], None
            while True:
                start_ns = time.monotonic_ns()
                native = observe(tag)
                window = matching(native)
                end_ns = time.monotonic_ns()
                costs.append((end_ns - start_ns) / 1e6)
                if previous_ns is not None:
                    polls.append((start_ns - previous_ns) / 1e6)
                previous_ns = start_ns
                if window:
                    require(time.monotonic() <= deadline, 'native activation proxy exceeded five-second observation deadline')
                    break
                require(time.monotonic() < deadline, 'native activation proxy timed out')
                time.sleep(max(0, policy['latency_poll_seconds'] - (time.monotonic_ns() - start_ns) / 1e9))
            identity = support.process_identity(window['pids'][0])
            endpoint = {'pid': identity['pid'], 'started': identity['started'], 'xid': window['xid'],
                        'native_observed_ns': end_ns}
            if panel_ticket is None:
                panel_ticket = support.process_ticket(identity['pid'])
                tickets.append(panel_ticket)
            require(panel_ticket['identity']['pid'] == identity['pid']
                    and panel_ticket['identity']['started'] == identity['started'], 'original panel process changed')
            if first:
                require(all(endpoint[name] == first[name] for name in ('pid', 'started', 'xid')), 'warm activation replaced native process/window')
            trace = {'tag': tag, 'qualified': False, 'status_reads': 0, 'reply_records': 0, 'observations': [],
                     'original_endpoint': endpoint, 'original_deadline_monotonic': deadline}
            report['show_qualifications'].append(trace)

            def record_reply(reply):
                body = json.dumps({'tag': tag, 'original_endpoint': endpoint, **reply}) + '\n'
                require(qualification_raw.tell() + len(body.encode()) <= 16 * 1024 * 1024, 'bounded qualification log exceeded')
                qualification_raw.write(body)
                qualification_raw.flush()
                trace['reply_records'] += 1

            def verify_original(stage):
                identities = original_resource_processes(support, desktop_ticket, panel_ticket, 'qualification-' + stage)
                observed = observe('qualification-' + tag + '-' + stage)
                current_window = matching(observed)
                require(current_window is not None and current_window['xid'] == endpoint['xid']
                        and current_window['pids'] == [endpoint['pid']], 'original panel hidden, unfocused or replaced during qualification')
                require(time.monotonic() < deadline, 'surface ownership qualification deadline expired')
                return {'identities': identities, 'native': observed}

            state = qualify_original_surface(config['renderer'], deadline, endpoint,
                first['session_id'] if first else None, verify_original,
                lambda command, until: read_only_before_deadline(driver, command, until, record_reply),
                trace, policy['latency_poll_seconds'])
            value = {'input': entered, 'native_observed_ns': end_ns, 'activation_proxy_ms': (end_ns - entered['input_start_ns']) / 1e6,
                'pid': identity['pid'], 'started': identity['started'], 'xid': window['xid'], 'session_id': state['session_id'],
                'observation_cost_ms': summary(costs), 'observation_intervals_ms': summary(polls) if polls else None,
                'poll_count': len(costs), 'native': native}
            if first:
                require(all(value[name] == first[name] for name in ('pid', 'started', 'xid', 'session_id')), 'warm activation replaced native process/window/session')
            return value

        def hide():
            x.chord(['Escape'])
            def hidden():
                native = observe('hide')
                displayed = any(window['xid'] == first['xid'] and window['viewable'] for window in native['windows'])
                return native if not displayed and focused(native, target.ready['windows']['target']) else None
            support.wait('hide and original native target focus', hidden)
            require(not driver.invoke('is_quick_paste_visible'), 'product still reports visible after native hide')

        def screenshot_owned_panel(name):
            require(name in ('surface-before-warmup', 'resource-visible-query'), 'fixed owned screenshot name required')
            screenshot_window = matching(observe('screenshot-' + name))
            require(screenshot_window and screenshot_window['xid'] == first['xid'], 'screenshot target changed')
            screenshot = OUT / (name + '.png')
            with (OUT / (name + '.stdout.log')).open('xb') as stdout, (OUT / (name + '.stderr.log')).open('xb') as stderr:
                captured = subprocess.run(['/usr/bin/import-im6.q16', '-window', str(first['xid']), str(screenshot)],
                    stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr, timeout=15)
            require(captured.returncode == 0, 'private Surface screenshot failed')
            require(screenshot.stat().st_size <= 8 * 1024 * 1024, 'private screenshot size bound exceeded')
            pixels = screenshot.read_bytes()
            require(pixels[:8] == b'\x89PNG\r\n\x1a\n' and struct.unpack('>II', pixels[16:24]) == (480, 360), 'private screenshot geometry differs')
            after = matching(observe('after-screenshot-' + name))
            require(after and after['xid'] == first['xid'], 'screenshot changed actual owned focus')
            return {'path': screenshot.name, 'sha256': hashlib.sha256(pixels).hexdigest(), 'bytes': len(pixels),
                    'xid': first['xid'], 'width': 480, 'height': 360, 'scope': 'private verified Surface only; outside measurements'}

        first = show('first-hotkey')
        report['first_hotkey'] = first
        report['first_hotkey_context']['helper_new_on_first_hotkey'] = (config['renderer'] == 'mygo'
            and report['first_hotkey_context']['surface_before']['managed_pid'] is None)
        require(panel_ticket is not None and panel_ticket['identity']['started'] == first['started'], 'qualified original panel ticket missing')
        # This is outside every warm sample and precedes five discarded warmups.
        time.sleep(1)
        report['screenshot'] = screenshot_owned_panel('surface-before-warmup')
        hide()
        for name, count in [('warmup', 5), ('samples', 30)]:
            for index in range(count):
                report[name].append(show(f'{name}-{index + 1}'))
                hide()
                save()
        report['warm_activation_proxy_ms'] = summary([item['activation_proxy_ms'] for item in report['samples']])
        show('exact-paste-verification')
        x.chord(['Control_L', 'a'])
        x.text('dzcp6needle7')
        time.sleep(.7)
        x.chord(['Return'])
        def exact_paste():
            value = target.request('state')
            return value if value['text'] == config['dataset'][7] and not value['pending'] else None
        report['actual_paste'] = support.wait('single Enter full original text', exact_paste)
        support.wait('actual paste hides panel', lambda: not driver.invoke('is_quick_paste_visible'))
        require(focused(observe('paste-target-focus'), target.ready['windows']['target']), 'actual paste lost target focus')
        show('resource-visible')
        setup_started = time.monotonic_ns()
        selection_input = x.chord(['Control_L', 'a'])
        query_input = x.text(config['resource_display']['query'])
        time.sleep(config['resource_display']['setup_wait_seconds'])
        report['resource_query_setup'] = {'method': 'same-query-v3', 'query': config['resource_display']['query'],
            'stored_rows': 10, 'expected_matching_rows': 1, 'expected_content': config['dataset'][7],
            'selection_input': selection_input, 'query_input': query_input,
            'setup_wait_seconds': config['resource_display']['setup_wait_seconds'],
            'screenshot': screenshot_owned_panel('resource-visible-query'),
            'setup_elapsed_ms': (time.monotonic_ns() - setup_started) / 1e6,
            'qualification': 'pending_owned_setup_png_review', 'search_ready_latency_measured': False,
            'continuation_rule': 'Confirm visible query and the single row7 result from this PNG before the next arm.'}
        save()
        remembered = {desktop_pid: desktop_ticket['identity']['started']}

        def resources(label, visible):
            time.sleep(policy['resource_settle_seconds'])
            samples = []
            progress = {'clock_domain': 'this inner process time.monotonic_ns',
                'outer_guard_seconds': 1260, 'independent_outer_guard_unchanged': True,
                'estimand': 'Empirical snapshot distribution under the event-anchored protocol, not a fixed-duration time average or independent replicates.'}
            report.setdefault('resource_sampling_progress', {})[label] = progress
            with (OUT / f'resources-{label}.jsonl').open('x', encoding='utf8') as stream, \
                    (OUT / f'resource-clock-{label}.jsonl').open('x', encoding='utf8') as clocks:
                def capture(index, actual_start_ns):
                    identities_before = original_resource_processes(support, desktop_ticket, panel_ticket, 'before-observation')
                    native = observe('resource-' + label)
                    validate_resource_windows(native, original_main, first, target.ready['windows']['target'], visible,
                                              matching(native, focused_only=False))
                    counter_start_ns = time.monotonic_ns()
                    value = family_snapshot(desktop_pid, remembered)
                    counter_end_ns = time.monotonic_ns()
                    identities_after = original_resource_processes(support, desktop_ticket, panel_ticket, 'after-observation')
                    value.update(monotonic_ns=actual_start_ns, snapshot_index=index,
                        observer_cost_ns=time.monotonic_ns() - actual_start_ns,
                        cpu_counter_read_window_ns=[counter_start_ns, counter_end_ns],
                        original_identities_before=identities_before, original_identities_after=identities_after)
                    samples.append(value)
                    return value

                def write_sample(encoded):
                    stream.write(encoded)
                    require(stream.tell() < 96 * 1024 * 1024, 'resource output size bound exceeded')

                def write_clock(value):
                    clocks.write(json.dumps(value) + '\n')
                    require(clocks.tell() < 32 * 1024 * 1024, 'resource clock output size bound exceeded')

                counted_snapshots(progress, policy['resource_sample_count'], policy['resource_interval_ns'],
                    arm_clock_deadline_ns, time.monotonic_ns, time.sleep, capture,
                    lambda value: json.dumps(value) + '\n', write_sample, write_clock)
                stream.flush()
                os.fsync(stream.fileno())
                clocks.flush()
                os.fsync(clocks.fileno())
                progress['files_flushed_ns'] = time.monotonic_ns()
            require(len(samples) == progress['capture_calls'] == progress['samples_written'] == policy['resource_sample_count'],
                    'count-paced resource observations incomplete')
            family_ids = lambda value: {(item['pid'], item['started']) for item in value['members']}
            thread_ids = lambda value: {(item['pid'], item['started'], thread['tid'], thread['started']) for item in value['members'] for thread in item['threads']}
            stable_family = all(family_ids(value) == family_ids(samples[0]) for value in samples)
            stable_threads = all(thread_ids(value) == thread_ids(samples[0]) for value in samples)
            span_ns = samples[-1]['monotonic_ns'] - samples[0]['monotonic_ns']
            cpu_delta = samples[-1]['cpu_ticks'] - samples[0]['cpu_ticks'] if stable_family else None
            cpu = counter_rate_interval(samples[0]['cpu_counter_read_window_ns'], samples[-1]['cpu_counter_read_window_ns'],
                                        cpu_delta, os.sysconf('SC_CLK_TCK')) if stable_family else None
            intervals = [(right['monotonic_ns'] - left['monotonic_ns']) / 1e6 for left, right in zip(samples, samples[1:])]
            result = {'sampling_protocol': 'event-anchored-count-v1',
                'actual_elapsed_seconds': (progress['files_flushed_ns'] - progress['started_ns']) / 1e9,
                'sample_span_seconds': span_ns / 1e9, 'sample_count': len(samples),
                'pss_kib': summary([value['pss_kib'] for value in samples]), 'uss_kib': summary([value['uss_kib'] for value in samples]),
                'snapshot_summary_scope': '960 protocol-selected snapshots; not a time mean, equal exposure duration or 960 independent experimental repetitions.',
                'observer_cost_ms': summary([value['observer_cost_ns'] / 1e6 for value in samples]),
                'observation_intervals_ms': summary(intervals),
                'late_ms': summary([item['late_ns'] / 1e6 for item in progress['clocks']]),
                'serialization_cost_ms': summary([(item['serialization_end_ns'] - item['capture_end_ns']) / 1e6 for item in progress['clocks']]),
                'sample_write_cost_ms': summary([(item['sample_write_end_ns'] - item['serialization_end_ns']) / 1e6 for item in progress['clocks']]),
                'clock_log_cost_ms': summary([(item['clock_log_end_ns'] - item['sample_write_end_ns']) / 1e6 for item in progress['clocks']]),
                'stable_process_membership': stable_family, 'stable_thread_membership': stable_threads,
                'cpu_counter_read_windows_ns': {'first': samples[0]['cpu_counter_read_window_ns'], 'last': samples[-1]['cpu_counter_read_window_ns']},
                'cpu_clock_ticks_per_second': os.sysconf('SC_CLK_TCK'),
                'cpu_counter_normalization': cpu,
                'cpu_percent_one_core': cpu['nominal_percent_one_core'] if cpu is not None else None,
                'cpu_scope': 'Observed process-family counter delta normalized approximately to read-window midpoint separation; uncertainty range is not a common-time CPU bound, statistical CI, tick-quantization bound or whole-window average. Short-lived processes may be missed.',
                'observed_thread_context_switch_delta': samples[-1]['context_switches'] - samples[0]['context_switches'] if stable_threads else None,
                'context_switch_scope': 'Observed threads only; short-lived threads between observations may be missed. Not wakeups.',
                'cpu_or_context_counters_with_changing_membership': 'unverified; no zero substitution', 'wakeup_count': None}
            return result

        report['resources']['visible'] = resources('visible', True)
        save()
        hide()
        report['resources']['hidden'] = resources('hidden', False)
        save()
        driver.invoke('save_setting', {'key': 'app.quick_paste_enabled', 'value': 'false'})
        state = driver.invoke('get_quick_paste_surface_status')
        require(not state['visible'] and state['managed_pid'] is None, 'disabled renderer retained managed helper')
        if config['renderer'] == 'mygo':
            support.wait('helper actual pidfd exit', lambda: support.exited(panel_ticket))
        after = driver.invoke('get_clipboard_host_status')
        require(after['mode'] == 'embedded' and after['capture_owner'] and after['state']['service_instance_id'] == owner['state']['service_instance_id'], 'capture owner changed')
        history = driver.invoke('get_clipboard_history', {'limit': 150, 'offset': 0, 'contentType': None})
        require(len(history) == 10 and {item['id'] for item in history} == set(ids), 'fixture history was duplicated or removed')
        report.update(status='passed', retained_ids=ids, capture_owner=after)
    except BaseException as error:
        report.update(status='failed', first_error={'type': type(error).__name__, 'message': str(error)})
    finally:
        errors = []
        if target:
            try:
                report['cleanup']['target'] = target.close()
            except BaseException as error:
                errors.append('target: ' + str(error))
        if driver:
            try:
                original = driver.process
                require(original is not None, 'original WebKit process handle missing')
                ticket = support.process_ticket(original.pid)
                tickets.append(ticket)
                driver.close()
                report['cleanup']['webdriver'] = {'identity': ticket['identity'], 'exit_code': original.poll(),
                    'pidfd_exited': support.exited(ticket), 'forced': original.returncode == -signal.SIGKILL}
                require(original.returncode in (0, -signal.SIGTERM) and support.exited(ticket), 'WebKit cleanup failed or forced')
                if 'desktop_ticket' in locals():
                    support.wait('Desktop pidfd exit', lambda: support.exited(desktop_ticket), 8)
                    report['cleanup']['desktop_pidfd_exit'] = True
            except BaseException as error:
                errors.append('Desktop: ' + str(error))
        if wm:
            if wm.poll() is None:
                wm.terminate()
            try:
                report['cleanup']['wm_exit_code'] = wm.wait(timeout=5)
                require(wm.returncode == 0 and support.exited(wm_ticket), 'WM failed orderly exit')
            except BaseException as error:
                errors.append('WM: ' + str(error))
        if x:
            x.close()
        for ticket in tickets:
            os.close(ticket['fd'])
        for stream in logs:
            stream.close()
        raw.flush()
        os.fsync(raw.fileno())
        raw.close()
        qualification_raw.flush()
        os.fsync(qualification_raw.fileno())
        qualification_raw.close()
        report['cleanup']['errors'] = errors
        if errors:
            report['status'] = 'failed'
        save()
    require(report['status'] == 'passed', 'private ABBA arm failed; original samples retained')


if __name__ == '__main__':
    require(sys.argv[1:] == ['--inside'], 'private internal entry only')
    main()

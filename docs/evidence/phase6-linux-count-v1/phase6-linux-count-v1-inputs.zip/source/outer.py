"""One reviewed private ABBA arm: native activation proxy and process-family resources."""
import argparse
import ctypes
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import re
import select
import shutil
import signal
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
FOUNDATION = HERE.parent / 'phase6-linux-recovery-20261028'
BASE = Path('/home/qiyuaner/.cache/dezirclip-v02/phase6-performance-recovered')
NS = ('user', 'mnt', 'pid', 'ipc', 'uts', 'net')
PYTHON = '/home/qiyuaner/.cache/dezirclip-v02/python-runtime/cpython-3.13.15-linux-x86_64-gnu/bin/python3.13'
CANONICAL = {'credential_guard.py': '0d5cd12943814fcd52238db3953499869334a6360aad17c60bcb5596bd2cea2f',
             'credential_launcher.py': '496e77f826397306bc384c126d2d48d6fa4549ce5339de445e95d5f9fe368c2c',
             'credential-deny.bpf': '426b69b2f07c9bb6a71c0327d9b4f76eabc5752f2276fa11a9937d264ae739cd'}


def require(ok, message):
    if not ok:
        raise RuntimeError(message)


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(block)
    return digest.hexdigest()


def save(path, value):
    with Path(path).open('w', encoding='utf8') as stream:
        json.dump(value, stream, indent=2)
        stream.write('\n')
        stream.flush()
        os.fsync(stream.fileno())


def ns():
    return {name: os.readlink('/proc/self/ns/' + name) for name in NS}


def host_activity():
    started = time.monotonic_ns()
    compilers = []
    for path in Path('/proc').iterdir():
        if not path.name.isdigit():
            continue
        try:
            comm = (path / 'comm').read_text().strip()
            if comm in {'cargo', 'rustc', 'rustdoc', 'go', 'cc', 'cc1', 'cc1plus', 'clang', 'clang++', 'gcc', 'g++', 'ld', 'ld.lld', 'lld'}:
                compilers.append({'pid': int(path.name), 'comm': comm})
        except (FileNotFoundError, ProcessLookupError, PermissionError):
            pass
    cpu = Path('/proc/stat').read_text().splitlines()[0].split()[1:]
    memory = {line.split(':', 1)[0]: int(line.split()[1]) for line in Path('/proc/meminfo').read_text().splitlines()
              if line.startswith(('MemTotal:', 'MemAvailable:'))}
    return {'scope': 'Linux /proc in WSL; Windows host load is not measured here', 'monotonic_ns': started, 'load_average': os.getloadavg(), 'cpu_ticks': list(map(int, cpu)),
            'memory_kib': memory, 'compiler_processes': compilers, 'observer_cost_ns': time.monotonic_ns() - started}


def verified_file(record):
    path = Path(record['path'])
    require(path.is_absolute() and path.is_file() and not path.is_symlink(), 'explicit regular input required')
    require(path.stat().st_size == record['bytes'] and sha(path) == record['sha256'], 'frozen input differs: ' + str(path))
    return path


def validate(config):
    require(config.get('root_go') is True and config.get('confirmation') == 'Run one reviewed private Phase6 Linux ABBA arm', 'specific execution authorization absent')
    require(config.get('performance_eligible') is False, 'activation proxy cannot establish the adoption threshold')
    require(config['comparison'] == {'order': ['tauri', 'mygo', 'mygo', 'tauri'], 'warmup': 5, 'samples': 30, 'latency_poll_seconds': 0.01, 'resource_settle_seconds': 30, 'resource_sampling': 'event-anchored-count-v1', 'resource_sample_count': 960, 'resource_interval_ns': 250000000}, 'frozen ABBA sampling policy required')
    require(config['resource_display'] == {'query': 'dzcp6needle7', 'stored_rows': 10, 'expected_matching_rows': 1,
        'setup_wait_seconds': .7, 'qualification': 'review_owned_setup_png_before_next_arm'},
        'same query and visible-result workload required before resource sampling')
    require(config['arm_index'] in (1, 2, 3, 4) and config['renderer'] == config['comparison']['order'][config['arm_index'] - 1], 'ABBA arm identity differs')
    require(config['target_timeout_seconds'] == 1080, 'bounded private target lifetime required')
    require(re.fullmatch('[0-9a-f]{40}', config['expected']['source_revision']), 'full source revision required')
    require(config['expected']['source_state'] == 'verified_checkout' and config['expected']['target'] == 'x86_64-unknown-linux-gnu', 'clean native Linux build identity required')
    require(config['expected']['toolkit_patch_id'] == 'mygo-v0.6.4-no-startup-cleanup-v1', 'patched helper required')
    require(config['dataset'] == [f'phase6 record {index:02} dzcp6needle{index} synthetic payload' for index in range(10)], 'same ten synthetic rows required')
    require(re.fullmatch('[a-zA-Z0-9][a-zA-Z0-9_-]{0,63}', config['run_name']), 'bounded explicit run name required')
    for relative, expected in CANONICAL.items():
        require(sha(FOUNDATION / 'canonical' / relative) == expected, 'immutable credential boundary changed')
    require(sha(FOUNDATION / 'original/native_capture.py') == '17ac33fa87ded6d31e3bf285466c744881490fa5c402042c24e7247a4486576b', 'original sandbox source changed')
    require(sha(FOUNDATION / 'original/short_private_ss.py') == 'a00bb20183051c648bb17d26b652a08d6ea015d7d79ba1b19bde7384ecbdf988', 'original SS wrapper changed')
    require(sha(FOUNDATION / 'inner.py') == '8a5d3ffe10829cc5e9b78313b26de0f7c19bf2d504766082e5def973994464d2', 'reviewed functional support changed')
    expected_sources = {'outer.py', 'inner.py', 'x11_target.py', 'paste_prerequisite.py'}
    require(set(config['fixture_sources']) == expected_sources, 'reviewed fixture source set differs')
    for relative, expected in config['fixture_sources'].items():
        require(sha(HERE / relative) == expected, 'reviewed fixture source changed')
    for record in config['inputs'].values():
        verified_file(record)
    require(set(config['inputs']) == {'desktop', 'helper', 'desktop_proof', 'helper_proof', 'private_ss_helper', 'webkit_driver', 'python', 'quiet_window_note', 'screenshot_tool', 'paste_tool', 'paste_tool_proof'}, 'explicit input set differs')
    import paste_prerequisite
    paste_prerequisite.validate_host(config)
    require(config['inputs']['python']['path'] == PYTHON, 'frozen Python runtime required')
    require(config['inputs']['screenshot_tool']['path'] == '/usr/bin/import-im6.q16'
            and config['inputs']['screenshot_tool']['sha256'] == '5b55f6bdec35ab6f5ae502f93c0308bf37aba3f23324c17a713363473fad7294', 'existing reviewed screenshot tool required')
    for component in ('desktop', 'helper'):
        proof = json.loads(verified_file(config['inputs'][component + '_proof']).read_text())
        require(proof.get('source_revision', proof.get('expected', {}).get('source_revision')) == config['expected']['source_revision'], 'build proof source differs')
        if component == 'helper':
            require(proof['sha256'] == config['inputs']['helper']['sha256'] and proof['expected'] == config['expected'], 'helper proof does not bind actual input')
        else:
            require(proof.get('profile') == 'release' and proof['binary']['sha256'] == config['inputs']['desktop']['sha256'], 'Desktop release proof does not bind actual input')


def sandbox(config, stage):
    spec = importlib.util.spec_from_file_location('original_native_capture', FOUNDATION / 'original/native_capture.py')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    tools = stage / 'tool-sources'
    tools.mkdir()
    for name in ('native_capture.py', 'sqlite_history_fixture.py'):
        shutil.copyfile(FOUNDATION / 'original' / name, tools / name)
    (stage / '.native-capture-fixture').write_bytes(module.MARKER)
    plan = {'mode': 'isolation', 'python_runtime': {'prefix': str(Path(PYTHON).parent.parent), 'executable': PYTHON}}
    save(stage / 'plan.json', plan)
    arguments = module.sandbox(stage, plan, {'name': 'functional', 'directory': 'functional'}, {}, None)
    require(arguments[0] == 'bwrap', 'original bwrap entry changed')
    original_tail = ['/usr/bin/dbus-run-session', '--', PYTHON, '-s', '/fixture-bin/native_capture.py', '--inside', str(stage), 'functional']
    position = arguments.index('/usr/bin/dbus-run-session')
    require(arguments[position:] == original_tail, 'original transport tail changed')
    output = stage / 'functional'
    (output / 'q').mkdir(mode=0o700)
    mounts = ['--bind', str(output), '/output', '--bind', str(output / 'q'), '/q',
              '--ro-bind', str(stage / 'runtime.json'), '/fixture-bin/runtime.json',
              '--ro-bind', str(FOUNDATION / 'canonical'), '/fixture-bin/canonical',
              '--ro-bind', str(FOUNDATION / 'inner.py'), '/fixture-bin/functional_support.py',
              '--ro-bind', str(FOUNDATION / 'original/short_private_ss.py'), '/fixture-bin/short_private_ss.py']
    for name in ('outer.py', 'inner.py', 'x11_target.py', 'paste_prerequisite.py'):
        mounts += ['--ro-bind', str(HERE / name), '/fixture-bin/' + name]
    for key, mounted in [('desktop', 'dezirclip'), ('helper', 'dzc-surface'), ('private_ss_helper', 'private-ss-preseed'), ('webkit_driver', 'WebKitWebDriver'), ('paste_tool', 'xdotool'), ('paste_tool_proof', 'paste-tool-proof.json')]:
        mounts += ['--ro-bind', config['inputs'][key]['path'], '/fixture-bin/' + mounted]
    chdir = arguments.index('--chdir')
    # Retain the original sandbox profile and namespace arguments; add only owned files.
    arguments[chdir:chdir] = mounts
    position = arguments.index('/usr/bin/xvfb-run')
    arguments[position:] = [PYTHON, '-s', '-B', '/fixture-bin/outer.py', '--keeper']
    arguments[0] = '/usr/bin/bwrap'
    return arguments, output


def cleanup_namespace(record):
    # This is called only after keeper verifies all six private namespace identities.
    ancestors, cursor = {os.getpid()}, os.getpid()
    while cursor > 1:
        fields = Path(f'/proc/{cursor}/stat').read_text().rsplit(')', 1)[1].split()
        cursor = int(fields[1])
        ancestors.add(cursor)
    for entry in Path('/proc').iterdir():
        if entry.name.isdigit() and int(entry.name) not in ancestors:
            pid = int(entry.name)
            try:
                fd = os.pidfd_open(pid)
            except ProcessLookupError:
                continue
            try:
                if not select.select([fd], [], [], 0)[0]:
                    record['forced_cleanup'].append(pid)
                    signal.pidfd_send_signal(fd, signal.SIGTERM)
                    if not select.select([fd], [], [], 3)[0]:
                        signal.pidfd_send_signal(fd, signal.SIGKILL)
                        require(select.select([fd], [], [], 3)[0], 'owned process survived forced cleanup')
            finally:
                os.close(fd)
    deadline = time.monotonic() + 3
    while True:
        try:
            pid, _ = os.waitpid(-1, os.WNOHANG)
        except ChildProcessError:
            break
        require(time.monotonic() < deadline, 'reaping owned descendants timed out')
        if pid == 0:
            time.sleep(.02)
    remaining = []
    for entry in Path('/proc').iterdir():
        if entry.name.isdigit() and int(entry.name) not in ancestors:
            try:
                remaining.append({'pid': int(entry.name), 'state': (entry / 'stat').read_text().rsplit(')', 1)[1].split()[0]})
            except FileNotFoundError:
                pass
    record['remaining'] = remaining
    if remaining or record['forced_cleanup']:
        record['status'] = 'failed'


def keeper():
    config = json.loads(Path('/fixture-bin/runtime.json').read_text())
    actual = ns()
    require(all(actual[name] != config['host_namespaces'][name] for name in NS), 'keeper requires six new namespaces')
    sys.path.insert(0, '/fixture-bin/canonical')
    import credential_launcher
    credential_launcher.probe_boundary()
    libc = ctypes.CDLL(None, use_errno=True)
    libc.prctl.argtypes = [ctypes.c_int, ctypes.c_ulong, ctypes.c_ulong, ctypes.c_ulong, ctypes.c_ulong]
    libc.prctl.restype = ctypes.c_int
    require(libc.prctl(36, 1, 0, 0, 0) == 0, 'subreaper registration failed')
    command = ['/usr/bin/xvfb-run', '-f', '/q/phase6.xauthority', '-a', '-s', '-screen 0 1280x900x24 -noreset',
               PYTHON, '-s', '-B', '/fixture-bin/short_private_ss.py', '--helper', '/fixture-bin/private-ss-preseed',
               '--output', '/output/private-ss', '--', PYTHON, '-s', '-B', '/fixture-bin/inner.py', '--inside']
    record = {'status': 'running', 'command': command, 'private_namespaces': actual, 'forced_cleanup': []}
    with Path('/output/keeper.stdout.log').open('xb') as stdout, Path('/output/keeper.stderr.log').open('xb') as stderr:
        child = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr)
        descriptor = os.pidfd_open(child.pid)
        try:
            record['exit_code'] = child.wait(timeout=1140)
            require(record['exit_code'] == 0 and select.select([descriptor], [], [], 0)[0], 'private cohort child failed')
            proof = json.loads(Path('/output/private-ss/proof.json').read_text())
            require(proof['status'] == 'passed' and all(item['stopped'] and item['exit_code'] != -9 for item in proof['processes']), 'private SS cleanup failed')
            record['status'] = 'passed'
        except BaseException as error:
            record.update(status='failed', error=str(error))
        finally:
            os.close(descriptor)
            save('/output/keeper.json', record)
            try:
                cleanup_namespace(record)
            except BaseException as error:
                record.update(status='failed', cleanup_error=str(error))
            finally:
                save('/output/keeper.json', record)
    require(record['status'] == 'passed', 'keeper failed; original evidence retained')


def run(config_path):
    require(sys.platform == 'linux' and os.uname().machine == 'x86_64', 'native Linux x86_64 only')
    config = json.loads(config_path.read_text())
    validate(config)
    stage = BASE / config['expected']['source_revision'] / config['run_name']
    stage.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    require(all(not path.is_symlink() for path in [stage.parent, *stage.parent.parents]), 'stage parent symlink refused')
    stage.mkdir(mode=0o700)
    config['host_namespaces'] = ns()
    config['product_environment'] = {'HOME': '/home/fixture', 'XDG_DATA_HOME': '/output/profile/data',
        'XDG_CONFIG_HOME': '/output/profile/config', 'XDG_CACHE_HOME': '/output/profile/cache',
        'XDG_RUNTIME_DIR': '/run/fixture', 'PATH': '/usr/bin:/bin:/fixture-bin', 'LANG': 'C.UTF-8',
        'TZ': 'UTC', 'TAURI_WEBVIEW_AUTOMATION': 'true', 'WEBKIT_DISABLE_DMABUF_RENDERER': '1',
        'WEBKIT_DISABLE_COMPOSITING_MODE': '1', 'DEZIRCLIP_DISABLE_LINUX_SERVICES': 'window_tracker,edge_docking,mouse_hotkey'}
    save(stage / 'runtime.json', config)
    arguments, output = sandbox(config, stage)
    command = [PYTHON, '-s', '-B', str(FOUNDATION / 'canonical/credential_launcher.py'), '--proof', str(stage / 'credential-boundary.json'), '--', *arguments]
    receipt = {'status': 'running', 'kind': 'phase6_linux_abba_arm_outer', 'arm_index': config['arm_index'], 'renderer': config['renderer'],
               'source_revision': config['expected']['source_revision'], 'command': command,
               'runtime_sha256': sha(stage / 'runtime.json'), 'performance_eligible': False}
    preflight = host_activity()
    save(stage / 'host-preflight.json', preflight)
    if preflight['compiler_processes']:
        receipt.update(status='failed', product_started=False, error='known compiler active in requested quiet window')
        save(stage / 'receipt.json', receipt)
        require(False, receipt['error'])
    with (stage / 'outer.stdout.log').open('xb') as stdout, (stage / 'outer.stderr.log').open('xb') as stderr:
        child = subprocess.Popen(command, stdin=subprocess.DEVNULL, stdout=stdout, stderr=stderr, start_new_session=True)
        descriptor = os.pidfd_open(child.pid)
        try:
            deadline = time.monotonic() + 1260
            contaminated = False
            with (stage / 'host-load.jsonl').open('x', encoding='utf8') as host_log:
                while True:
                    sample = host_activity()
                    contaminated |= bool(sample['compiler_processes'])
                    host_log.write(json.dumps(sample) + '\n')
                    host_log.flush()
                    if select.select([descriptor], [], [], 1)[0]:
                        break
                    require(time.monotonic() < deadline, 'outer arm absolute timeout')
            receipt['exit_code'] = child.wait(timeout=1)
            require(receipt['exit_code'] == 0 and select.select([descriptor], [], [], 0)[0], 'outer private cohort failed')
            require(json.loads((output / 'keeper.json').read_text())['status'] == 'passed', 'keeper receipt missing or failed')
            report = json.loads((output / 'performance.json').read_text())
            require(report['status'] == 'passed' and len(report['warmup']) == 5 and len(report['samples']) == 30
                    and set(report['resources']) == {'visible', 'hidden'}, 'arm receipt missing or incomplete')
            require(not contaminated, 'compiler activity contaminated the requested quiet window; raw samples retained')
            require(report['paste_prerequisite']['exit_code'] == 0
                    and report['paste_prerequisite']['native_input_generated'] is False,
                    'pre-Desktop private paste prerequisite receipt missing')
            for value in config['inputs'].values():
                verified_file(value)
            receipt['status'] = 'passed'
        except BaseException as error:
            receipt.update(status='failed', error=str(error))
            if child.poll() is None:
                receipt['forced_outer_stop'] = True
                signal.pidfd_send_signal(descriptor, signal.SIGTERM)
                try:
                    child.wait(timeout=8)
                except subprocess.TimeoutExpired:
                    signal.pidfd_send_signal(descriptor, signal.SIGKILL)
                    child.wait(timeout=8)
        finally:
            os.close(descriptor)
            save(stage / 'receipt.json', receipt)
    print(json.dumps({'status': receipt['status'], 'evidence': str(stage)}))
    require(receipt['status'] == 'passed', 'private cohort failed; no retry performed')


if __name__ == '__main__':
    if sys.argv[1:] == ['--keeper']:
        keeper()
    else:
        parser = argparse.ArgumentParser(description=__doc__)
        parser.add_argument('--execute-config', type=Path, required=True)
        run(parser.parse_args().execute_config)

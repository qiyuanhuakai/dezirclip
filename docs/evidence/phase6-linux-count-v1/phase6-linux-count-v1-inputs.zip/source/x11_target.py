"""Private X11 fixture input, observation and synthetic paste target; never ambient UI."""
import ctypes as C
import json
import os
from pathlib import Path
import select
import sys
import time

NAMESPACES = ('user', 'mnt', 'pid', 'ipc', 'uts', 'net')


def require(value, message):
    if not value:
        raise RuntimeError(message)


def namespaces():
    return {name: os.readlink('/proc/self/ns/' + name) for name in NAMESPACES}


def boundary(config):
    require(sys.platform == 'linux' and os.uname().machine == 'x86_64', 'native Linux x86_64 only')
    actual = namespaces()
    require(all(actual[name] != config['host_namespaces'][name] for name in NAMESPACES), 'six private namespaces required')
    require(os.environ.get('XAUTHORITY') == '/q/phase6.xauthority', 'private Xauthority required')
    require(os.environ.get('DISPLAY', '').startswith(':'), 'local private X display required')
    require(Path('/q/phase6.xauthority').is_file(), 'private display authority missing')
    require('NoNewPrivs:\t1' in Path('/proc/self/status').read_text(), 'credential boundary missing')
    return actual


class Attributes(C.Structure):
    _fields_ = [('x', C.c_int), ('y', C.c_int), ('width', C.c_int), ('height', C.c_int),
                ('border_width', C.c_int), ('depth', C.c_int), ('visual', C.c_void_p),
                ('root', C.c_ulong), ('klass', C.c_int), ('bit_gravity', C.c_int),
                ('win_gravity', C.c_int), ('backing_store', C.c_int), ('backing_planes', C.c_ulong),
                ('backing_pixel', C.c_ulong), ('save_under', C.c_int), ('colormap', C.c_ulong),
                ('map_installed', C.c_int), ('map_state', C.c_int), ('all_event_masks', C.c_long),
                ('your_event_mask', C.c_long), ('do_not_propagate_mask', C.c_long),
                ('override_redirect', C.c_int), ('screen', C.c_void_p)]


class KeyEvent(C.Structure):
    _fields_ = [('type', C.c_int), ('serial', C.c_ulong), ('send_event', C.c_int),
                ('display', C.c_void_p), ('window', C.c_ulong), ('root', C.c_ulong),
                ('subwindow', C.c_ulong), ('time', C.c_ulong), ('x', C.c_int), ('y', C.c_int),
                ('x_root', C.c_int), ('y_root', C.c_int), ('state', C.c_uint),
                ('keycode', C.c_uint), ('same_screen', C.c_int)]


class SelectionEvent(C.Structure):
    _fields_ = [('type', C.c_int), ('serial', C.c_ulong), ('send_event', C.c_int),
                ('display', C.c_void_p), ('requestor', C.c_ulong), ('selection', C.c_ulong),
                ('target', C.c_ulong), ('property', C.c_ulong), ('time', C.c_ulong)]


class ClientData(C.Union):
    _fields_ = [('b', C.c_char * 20), ('s', C.c_short * 10), ('l', C.c_long * 5)]


class ClientEvent(C.Structure):
    _fields_ = [('type', C.c_int), ('serial', C.c_ulong), ('send_event', C.c_int),
                ('display', C.c_void_p), ('window', C.c_ulong), ('message_type', C.c_ulong),
                ('format', C.c_int), ('data', ClientData)]


class Event(C.Union):
    _fields_ = [('type', C.c_int), ('key', KeyEvent), ('selection', SelectionEvent),
                ('client', ClientEvent), ('pad', C.c_long * 24)]


class X11:
    def __init__(self, config):
        boundary(config)
        self.x = C.CDLL('libX11.so.6')
        self.xt = C.CDLL('libXtst.so.6')
        pointer, ulong, integer = C.c_void_p, C.c_ulong, C.c_int
        signatures = {
            'XOpenDisplay': ([C.c_char_p], pointer), 'XCloseDisplay': ([pointer], integer),
            'XDefaultRootWindow': ([pointer], ulong), 'XSync': ([pointer, integer], integer),
            'XFlush': ([pointer], integer), 'XFree': ([pointer], integer),
            'XInternAtom': ([pointer, C.c_char_p, integer], ulong),
            'XGetInputFocus': ([pointer, C.POINTER(ulong), C.POINTER(integer)], integer),
            'XQueryTree': ([pointer, ulong, C.POINTER(ulong), C.POINTER(ulong), C.POINTER(C.POINTER(ulong)), C.POINTER(C.c_uint)], integer),
            'XGetWindowAttributes': ([pointer, ulong, C.POINTER(Attributes)], integer),
            'XGetWindowProperty': ([pointer, ulong, ulong, C.c_long, C.c_long, integer, ulong, C.POINTER(ulong), C.POINTER(integer), C.POINTER(ulong), C.POINTER(ulong), C.POINTER(C.POINTER(C.c_ubyte))], integer),
            'XChangeProperty': ([pointer, ulong, ulong, ulong, integer, integer, pointer, integer], integer),
            'XCreateSimpleWindow': ([pointer, ulong, integer, integer, C.c_uint, C.c_uint, C.c_uint, ulong, ulong], ulong),
            'XStoreName': ([pointer, ulong, C.c_char_p], integer), 'XSelectInput': ([pointer, ulong, C.c_long], integer),
            'XMapWindow': ([pointer, ulong], integer), 'XRaiseWindow': ([pointer, ulong], integer),
            'XDestroyWindow': ([pointer, ulong], integer), 'XSetInputFocus': ([pointer, ulong, integer, ulong], integer),
            'XSendEvent': ([pointer, ulong, integer, C.c_long, C.POINTER(Event)], integer),
            'XPending': ([pointer], integer), 'XNextEvent': ([pointer, C.POINTER(Event)], integer),
            'XStringToKeysym': ([C.c_char_p], ulong), 'XKeysymToKeycode': ([pointer, ulong], C.c_ubyte),
            'XLookupKeysym': ([C.POINTER(KeyEvent), integer], ulong),
            'XConvertSelection': ([pointer, ulong, ulong, ulong, ulong, ulong], integer),
        }
        for name, (arguments, result) in signatures.items():
            function = getattr(self.x, name)
            function.argtypes, function.restype = arguments, result
        self.errors = []
        callback_type = C.CFUNCTYPE(integer, pointer, pointer)
        self.error_handler = callback_type(lambda _display, _event: self.errors.append(time.monotonic_ns()) or 0)
        self.x.XSetErrorHandler.argtypes, self.x.XSetErrorHandler.restype = [callback_type], pointer
        self.x.XSetErrorHandler(self.error_handler)
        self.xt.XTestFakeKeyEvent.argtypes, self.xt.XTestFakeKeyEvent.restype = [pointer, C.c_uint, integer, ulong], integer
        self.display = self.x.XOpenDisplay(None)
        require(self.display, 'private X display connection failed')
        self.root = self.x.XDefaultRootWindow(self.display)

    def atom(self, value):
        return self.x.XInternAtom(self.display, value.encode(), False)

    def property(self, window, name, maximum=16384):
        atom, fmt, count, remaining = C.c_ulong(), C.c_int(), C.c_ulong(), C.c_ulong()
        data = C.POINTER(C.c_ubyte)()
        result = self.x.XGetWindowProperty(self.display, window, self.atom(name), 0, maximum // 4, False, 0,
            C.byref(atom), C.byref(fmt), C.byref(count), C.byref(remaining), C.byref(data))
        try:
            require(result == 0 and remaining.value == 0, 'bounded X property request failed')
            if not data:
                return [] if fmt.value in (0, 32) else b''
            if fmt.value == 32:
                return list(C.cast(data, C.POINTER(C.c_ulong))[:count.value])
            require(fmt.value == 8 and count.value <= maximum, 'unsupported X property encoding')
            return C.string_at(data, count.value)
        finally:
            if data:
                self.x.XFree(data)

    def focus_chain(self):
        window, revert = C.c_ulong(), C.c_int()
        self.x.XGetInputFocus(self.display, C.byref(window), C.byref(revert))
        chain = []
        while window.value not in (0, 1, self.root) and len(chain) < 16 and window.value not in chain:
            chain.append(window.value)
            root, parent, count = C.c_ulong(), C.c_ulong(), C.c_uint()
            children = C.POINTER(C.c_ulong)()
            if not self.x.XQueryTree(self.display, window.value, C.byref(root), C.byref(parent), C.byref(children), C.byref(count)):
                break
            if children:
                self.x.XFree(children)
            window = parent
        return chain

    def observe(self, retained=()):
        windows = []
        clients = self.property(self.root, '_NET_CLIENT_LIST')
        require(len(clients) <= 100, 'unexpected private window count')
        require(len(retained) <= 2 and all(type(window) is int and window > 0 for window in retained),
                'at most two original positive window identities may be retained')
        # A withdrawn window can leave _NET_CLIENT_LIST while its original XID
        # still exists. Observe only the explicitly retained main/panel as well.
        clients = list(dict.fromkeys([*clients, *retained]))
        for window in clients:
            attributes = Attributes()
            if not self.x.XGetWindowAttributes(self.display, window, C.byref(attributes)):
                continue
            windows.append({'xid': window, 'pids': self.property(window, '_NET_WM_PID'),
                'viewable': attributes.map_state == 2,
                'rect': {name: getattr(attributes, name) for name in ('x', 'y', 'width', 'height')}})
        active = self.property(self.root, '_NET_ACTIVE_WINDOW')
        return {'monotonic_ns': time.monotonic_ns(), 'active': active[0] if active else 0,
                'focus_chain': self.focus_chain(), 'windows': windows, 'x_errors': len(self.errors)}

    def chord(self, names):
        codes = [self.x.XKeysymToKeycode(self.display, self.x.XStringToKeysym(name.encode())) for name in names]
        require(all(codes), 'X key mapping absent')
        start = time.monotonic_ns()
        for code in codes:
            require(self.xt.XTestFakeKeyEvent(self.display, code, True, 0), 'XTest key press failed')
        for code in reversed(codes):
            require(self.xt.XTestFakeKeyEvent(self.display, code, False, 0), 'XTest key release failed')
        self.x.XSync(self.display, False)
        return {'keys': names, 'input_start_ns': start, 'input_synced_ns': time.monotonic_ns()}

    def text(self, value):
        require(value and all(char.isascii() and (char.islower() or char.isdigit()) for char in value), 'fixture query must be ASCII lowercase/digits')
        for char in value:
            self.chord([char])

    def activate_fixture(self, window):
        event = Event()
        event.client.type, event.client.window = 33, window
        event.client.message_type, event.client.format = self.atom('_NET_ACTIVE_WINDOW'), 32
        event.client.data.l[0], event.client.data.l[1] = 2, 0
        require(self.x.XSendEvent(self.display, self.root, False, (1 << 20) | (1 << 19), C.byref(event)), 'fixture activation request failed')
        self.x.XRaiseWindow(self.display, window)
        self.x.XSetInputFocus(self.display, window, 1, 0)
        self.x.XSync(self.display, False)

    def close(self):
        if self.display:
            self.x.XCloseDisplay(self.display)
            self.display = None


def target(config):
    boundary(config)
    x = X11(config)
    windows, text, pending = {}, '', False
    require(config['target_timeout_seconds'] == 1080, 'bounded performance target lifetime required')
    deadline = time.monotonic() + config['target_timeout_seconds']
    try:
        for index, name in enumerate(('target', 'alternate')):
            window = x.x.XCreateSimpleWindow(x.display, x.root, 10 + index * 350, 10, 320, 120, 0, 0, 0xffffff)
            require(window, 'synthetic target window creation failed')
            windows[name] = window
            pid = C.c_ulong(os.getpid())
            x.x.XChangeProperty(x.display, window, x.atom('_NET_WM_PID'), x.atom('CARDINAL'), 32, 0, C.byref(pid), 1)
            x.x.XStoreName(x.display, window, ('DezirClip synthetic ' + name).encode())
            x.x.XSelectInput(x.display, window, 1 | (1 << 17) | (1 << 21))
            x.x.XMapWindow(x.display, window)
        x.x.XSync(x.display, False)
        print(json.dumps({'ready': True, 'pid': os.getpid(), 'windows': windows}), flush=True)
        stopping = False
        while not stopping:
            require(time.monotonic() < deadline, 'synthetic target absolute timeout')
            while x.x.XPending(x.display):
                event = Event()
                x.x.XNextEvent(x.display, C.byref(event))
                if event.type == 2 and event.key.window == windows['target']:
                    symbol = x.x.XLookupKeysym(C.byref(event.key), 0)
                    if ((event.key.state & 4 and symbol in (ord('v'), ord('V'))) or
                            (event.key.state & 1 and symbol == 0xff63)):
                        require(not pending, 'second native paste conversion refused')
                        pending = True
                        x.x.XConvertSelection(x.display, x.atom('CLIPBOARD'), x.atom('UTF8_STRING'),
                            x.atom('DZC_QA_TEXT'), windows['target'], event.key.time)
                        x.x.XFlush(x.display)
                elif event.type == 31 and event.selection.requestor == windows['target']:
                    require(pending and event.selection.property == x.atom('DZC_QA_TEXT'), 'unexpected paste selection reply')
                    value = x.property(windows['target'], 'DZC_QA_TEXT').decode('utf8')
                    require(value in config['dataset'], 'unexpected clipboard body in private target')
                    text += value
                    pending = False
            if select.select([sys.stdin], [], [], .01)[0]:
                line = sys.stdin.readline(4097)
                require(line and len(line) <= 4096, 'target control EOF/oversize')
                request = json.loads(line)
                operation = request['operation']
                if operation in ('target', 'alternate'):
                    x.activate_fixture(windows[operation])
                elif operation == 'clear':
                    require(not pending, 'cannot clear during pending native selection')
                    text = ''
                elif operation == 'stop':
                    stopping = True
                else:
                    require(operation == 'state', 'unknown target operation')
                print(json.dumps({'id': request['id'], 'text': text, 'pending': pending,
                                  'windows': windows, 'monotonic_ns': time.monotonic_ns()}), flush=True)
        for window in windows.values():
            x.x.XDestroyWindow(x.display, window)
        x.x.XSync(x.display, False)
    finally:
        x.close()


if __name__ == '__main__':
    require(len(sys.argv) == 2 and sys.argv[1] == '--target', 'internal private target only')
    target(json.loads(Path('/fixture-bin/runtime.json').read_text()))

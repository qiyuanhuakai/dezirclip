"""Describe all four completed new count arms; never run native code or pass Phase 6."""
import hashlib
import json
import math
from pathlib import Path

HERE = Path(__file__).resolve().parent
REVISION = '5d6af007b0b000ed78a22e7fc6e1413c92f28d42'
RAW = Path('/home/qiyuaner/.cache/dezirclip-v02/phase6-performance-recovered') / REVISION
ARMS = [
    ('count-v1-5d6af007-1-tauri', 'tauri', 'fc39f882ddf28aff6a5227484c61ec73f4a1740444098d7cff6066fc16badce4',
     'count-v1-5d6af007-1-tauri.independent-raw-review-case2-20261031.json', '5ee9f301b802ffeedc360650f8a097905caa8d727fea5865fa2beb2e13e5c50d'),
    ('count-v1-5d6af007-2-mygo', 'mygo', 'a2675263a0516d02be905e6faf22a36bca2c94d1a38ccd7ed3a12f65715d8a84',
     'count-v1-5d6af007-2-mygo.independent-raw-review-case2-20261031.json', '24c2df957031688fa039ca2a8ae862fad7a5e54f9b955b59fbd3fadd05e96af6'),
    ('count-v1-5d6af007-3-mygo', 'mygo', 'ef5ed8b061abf5b3d97a6ba5197db66b7d26b091577e53f0a298e20a13bf0741',
     'count-v1-5d6af007-3-mygo.independent-raw-review-case2-20261031.json', 'b82aa431f3f6c152a35981b9acc9e8b8003a17d29b16eb27471c327310b0ba58'),
    ('count-v1-5d6af007-4-tauri', 'tauri', 'f01dbe27d80b51aa3ceeba647857c883381d0f06eb8434edacbc7d9f06561c97',
     'count-v1-5d6af007-4-tauri.independent-raw-review-case2-20261031-v2.json', '4f2225beb5b88b195c878feef2363d71ab7c2d3264f158e8f89e162591c904fd'),
]


def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def record(path):
    assert path.is_absolute() and path.is_file() and not path.is_symlink()
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(chunk)
    return {'path': str(path), 'bytes': path.stat().st_size, 'sha256': digest.hexdigest()}


def verify(item):
    assert record(Path(item['path'])) == item


def summary(values):
    values = sorted(values)
    assert values and all(type(value) in (int, float) and math.isfinite(value) for value in values)
    return {'count': len(values), 'min': values[0], 'max': values[-1], 'mean': sum(values) / len(values),
            'p50': values[math.ceil(len(values) * .5) - 1], 'p95': values[math.ceil(len(values) * .95) - 1]}


def check_summary(actual, values):
    expected = summary(values)
    assert set(actual) == set(expected)
    assert all(math.isclose(actual[key], expected[key], rel_tol=1e-12, abs_tol=1e-9) for key in expected)


def weighted_cpu(metrics):
    assert all(metric['stable_process_membership'] is True for metric in metrics)
    hz = {metric['cpu_clock_ticks_per_second'] for metric in metrics}
    assert len(hz) == 1
    hz = hz.pop()
    assert type(hz) is int and hz > 0
    clocks = [metric['cpu_counter_normalization'] for metric in metrics]
    ticks = sum(clock['counter_delta_ticks'] for clock in clocks)
    twice_interval = sum(clock['twice_nominal_interval_ns'] for clock in clocks)
    minimum = sum(clock['interval_min_ns'] for clock in clocks)
    maximum = sum(clock['interval_max_ns'] for clock in clocks)
    assert 0 < minimum <= twice_interval / 2 <= maximum and ticks >= 0
    return {'counter_delta_ticks': ticks, 'ticks_per_second': hz,
            'sum_twice_nominal_intervals_ns': twice_interval,
            'nominal_percent_one_core': ticks * 2e11 / (hz * twice_interval),
            'read_window_normalization_percent_range': [ticks * 1e11 / (hz * maximum), ticks * 1e11 / (hz * minimum)],
            'scope': 'Duration-weighted disjoint first/last counter-read intervals. Not elapsed-window/tail CPU, a common-time family bound, tick-quantization bound or statistical confidence interval.'}


def main():
    freeze = record(HERE / 'source-freeze-v2.json')
    assert freeze['sha256'] == '63303598ff00a400651c1f8d3907c43917bec7739201445dc22baa4df7706a5b'
    frozen = read(Path(freeze['path']))
    for item in [*frozen['runtime'], frozen['plan'], frozen['assessor'], frozen['assessor_tests'], frozen['qa']['log']]:
        verify(item)
    plan = read(Path(frozen['plan']['path']))
    groups = {name: {'latencies': [], 'states': {state: {'pss': [], 'uss': [], 'metrics': []} for state in ('visible', 'hidden')}} for name in ('tauri', 'mygo')}
    arms, inputs = [], None
    for name, renderer, assessment_sha, review_name, review_sha in ARMS:
        assessment_record, review_record = record(HERE / (name + '.assessment.json')), record(HERE / review_name)
        assert assessment_record['sha256'] == assessment_sha and review_record['sha256'] == review_sha
        assessment, review = read(Path(assessment_record['path'])), read(Path(review_record['path']))
        assert assessment['status'] == 'passed' and review['status'].startswith('passed_limited_')
        expected_arm = [arm for arm in plan['arms'] if arm['run_name'] == name]
        assert len(expected_arm) == 1 and assessment['arm'] == expected_arm[0]
        assert expected_arm[0]['renderer'] == renderer and expected_arm[0]['arm_index'] == len(arms) + 1
        assert review['arm'] == name
        for value in (assessment, review):
            assert value['source_revision'] == REVISION
            assert value['performance_eligible'] is False and value['next_arm_authorized'] is False
        assert review['root_assessment'] == assessment_record and review['whole_ABBA_complete'] is False
        verify(assessment['execution'])
        execution = read(Path(assessment['execution']['path']))
        assert execution['renderer'] == renderer
        if inputs is None:
            inputs = execution['inputs']
            for item in inputs.values():
                verify(item)
        assert inputs == execution['inputs']
        for item in assessment['raw_evidence']:
            verify(item)
        report = read(RAW / name / 'functional/performance.json')
        assert report['status'] == 'passed' and report['renderer'] == renderer
        assert len(report['warmup']) == 5 and len(report['samples']) == 30
        values = [sample['activation_proxy_ms'] for sample in report['samples']]
        check_summary(assessment['warm_activation_proxy_ms'], values)
        groups[renderer]['latencies'].extend(values)
        for state in ('visible', 'hidden'):
            rows = [json.loads(line) for line in (RAW / name / ('functional/resources-' + state + '.jsonl')).read_text().splitlines()]
            assert len(rows) == 960
            metric = assessment['verified_resources'][state]
            check_summary(metric['pss_kib'], [row['pss_kib'] for row in rows])
            check_summary(metric['uss_kib'], [row['uss_kib'] for row in rows])
            target = groups[renderer]['states'][state]
            target['pss'].extend(row['pss_kib'] for row in rows)
            target['uss'].extend(row['uss_kib'] for row in rows)
            target['metrics'].append(metric)
        arms.append({'arm': name, 'renderer': renderer, 'assessment': assessment_record, 'independent_raw_review': review_record,
                     'warm_activation_proxy_ms': assessment['warm_activation_proxy_ms'], 'resources': assessment['verified_resources'],
                     'qualification_count': assessment['qualification_count'], 'actual_reply_count': assessment['actual_reply_count'],
                     'raw_evidence': assessment['raw_evidence']})
    variants = {}
    for renderer, group in groups.items():
        assert len(group['latencies']) == 60
        variants[renderer] = {'warm_activation_proxy_ms': summary(group['latencies']), 'resources': {}}
        for state, values in group['states'].items():
            assert len(values['pss']) == len(values['uss']) == 1920 and len(values['metrics']) == 2
            variants[renderer]['resources'][state] = {'empirical_snapshot_pss_kib': summary(values['pss']),
                'empirical_snapshot_uss_kib': summary(values['uss']), 'cpu_counter_interval': weighted_cpu(values['metrics'])}
    output = {'kind': 'complete_new_count_v1_descriptive_comparison', 'status': 'completed_with_explicit_metric_limits',
              'source_revision': REVISION, 'performance_eligible': False, 'phase6_passed': False, 'phase7_authorized': False,
              'source_freeze': freeze, 'summarizer': record(Path(__file__).resolve()), 'inputs': inputs,
              'arms_in_execution_order': arms, 'variants': variants,
              'limits': ['Only all four fresh count-v1 arms; original v6 958/2 failed quality remains failed, excluded rather than relabelled or spliced.',
                         'Descriptive post-collection aggregation, not a preregistered new adoption gate, inference or significance test. Two arms per renderer; 1920 snapshots are correlated, not independent repetitions.',
                         'Nearest-rank p50/p95. Each renderer latency pools its two original 30-sample formal vectors; warmups excluded. Memory pools genuine capture snapshots, not fixed240s/equal-time weighted means.',
                         'CPU normalizes summed disjoint counter deltas by summed read-window midpoint intervals; intervals exclude settle, warmups and final tail.',
                         'Cold-start/first-interactive-frame/search-ready/GPU/wakeup/IME/DPI/multimonitor and whole-host idle remain unverified. Context-switch counts are not wakeups.',
                         'These Linux controlled native-visible/foreground proxies do not prove Windows performance, production adoption eligibility or Phase6/Phase7 acceptance.']}
    path = HERE / 'comparison-count-v1.descriptive.json'
    with path.open('x', encoding='utf-8') as stream:
        json.dump(output, stream, indent=2)
        stream.write('\n')
    print(json.dumps({'output': record(path), 'variants': variants}))


if __name__ == '__main__':
    main()
